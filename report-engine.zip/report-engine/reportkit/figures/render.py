"""Deterministic chart rendering from a ChartSpec (matplotlib, Agg backend).

The LLM never writes plotting code: it fills a narrow ChartSpec, the engine
computes the data, and this module draws it with a fixed style. PNG metadata
is stripped so the same data renders to the same bytes, which keeps figure
hashes in the run manifest stable across reruns.

Colours: fixed categorical order (validated for colour-vision deficiency on
adjacent pairs); scatter/hist overlays are capped at three groups because
only the first three slots stay distinguishable when every pair can touch.
"""

from __future__ import annotations

import io
import math
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter, MaxNLocator  # noqa: E402

from reportkit.models.compute import ChartSpec  # noqa: E402

CATEGORICAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
ALL_PAIRS_CAP = 3  # scatter / hist overlays
TEXT_PRIMARY = "#0b0b0b"
TEXT_SECONDARY = "#52514e"
GRID = "#e4e3df"
AXIS = "#b9b8b2"
SURFACE = "#ffffff"  # Word page

STYLE = {
    "font.family": "DejaVu Sans",  # ships with matplotlib: identical glyphs on every machine
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.titleweight": "regular",
    "axes.titlelocation": "left",
    "axes.titlecolor": TEXT_PRIMARY,
    "axes.labelcolor": TEXT_SECONDARY,
    "axes.edgecolor": AXIS,
    "axes.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "axes.grid.axis": "y",
    "axes.axisbelow": True,
    "grid.color": GRID,
    "grid.linewidth": 0.6,
    "xtick.color": TEXT_SECONDARY,
    "ytick.color": TEXT_SECONDARY,
    "xtick.major.size": 0,
    "ytick.major.size": 0,
    "legend.frameon": False,
    "legend.fontsize": 8.5,
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "svg.hashsalt": "reportkit",
    "path.simplify": False,
}


class ColorRegistry:
    """Colour follows the entity across every figure in one report: the first
    chart that shows 'Placebo' fixes its colour for the rest of the job."""

    def __init__(self) -> None:
        self._map: dict[str, str] = {}

    def color(self, key: Any) -> str:
        k = str(key)
        if k not in self._map:
            if len(self._map) >= len(CATEGORICAL):
                raise ValueError("more than 8 series in one report: fold small groups into 'Other' or facet")
            self._map[k] = CATEGORICAL[len(self._map)]
        return self._map[k]


class ChartError(ValueError):
    pass


def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _fmt_tick(v: float, _pos=None) -> str:
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    return f"{v:g}"


def _c(colors: "ColorRegistry", g: Any) -> str:
    """Single-series charts use slot 1 without claiming an entity colour."""
    return CATEGORICAL[0] if g is None else colors.color(g)


def _groups(rows: list[dict]) -> list[Any]:
    return sorted({r.get("_g") for r in rows}, key=lambda v: (v is None, str(v)))


def render_chart(spec: ChartSpec, rows: list[dict], colors: ColorRegistry | None = None,
                 width_in: float = 6.3, height_in: float = 3.6, dpi: int = 300, show_title: bool = False) -> bytes:
    """PNG bytes. The title is normally carried by the document caption, not the image."""
    if not rows:
        raise ChartError(f"no data for figure {spec.figure_id}")
    colors = colors or ColorRegistry()
    with plt.rc_context(STYLE):
        fig, ax = plt.subplots(figsize=(width_in, height_in), dpi=dpi)
        try:
            {"bar": _bar, "line": _line, "scatter": _scatter, "box": _box, "hist": _hist}[spec.chart](
                ax, spec, rows, colors)
            if show_title:
                ax.set_title(spec.title, pad=10)
            if spec.x_label is not None or spec.chart != "box":
                ax.set_xlabel(spec.x_label if spec.x_label is not None else spec.data.x)
            ax.set_ylabel(spec.y_label if spec.y_label is not None else (spec.data.y or spec.data.agg or ""))
            ax.yaxis.set_major_formatter(FuncFormatter(_fmt_tick))
            fig.tight_layout()
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=dpi, metadata={"Software": None})
            return buf.getvalue()
        finally:
            plt.close(fig)


def _legend(ax, n_series: int) -> None:
    if n_series >= 2:
        ax.legend(loc="upper left", bbox_to_anchor=(0, 1.0), ncol=min(n_series, 4), handlelength=1.2,
                  borderaxespad=0.2)


def _bar(ax, spec: ChartSpec, rows: list[dict], colors: ColorRegistry) -> None:
    xs = sorted({r["_x"] for r in rows}, key=lambda v: (v is None, v if _num(v) else str(v)))
    groups = _groups(rows) if spec.data.group else [None]
    lookup: dict[tuple, float] = {}
    for r in rows:
        key = (r["_x"], r.get("_g"))
        if key in lookup:
            raise ChartError("bar chart has several values per bar; set `agg`")
        lookup[key] = r.get("_y") or 0
    n = len(groups)
    width = 0.8 / n
    for gi, g in enumerate(groups):
        pos = [i - 0.4 + width * (gi + 0.5) for i in range(len(xs))]
        vals = [lookup.get((x, g), 0) for x in xs]
        color = _c(colors, g)
        bars = ax.bar(pos, vals, width=width * 0.92, color=color, label=str(g) if g is not None else None,
                      edgecolor=SURFACE, linewidth=1.0, zorder=2)
        if len(xs) * n <= 12:  # selective direct labels, never on dense charts
            ax.bar_label(bars, labels=[_fmt_tick(v) for v in vals], padding=2, fontsize=8, color=TEXT_SECONDARY)
    ax.set_xticks(range(len(xs)), [str(x) for x in xs], rotation=0 if len(xs) <= 8 else 45,
                  ha="center" if len(xs) <= 8 else "right")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    _legend(ax, n if spec.data.group else 1)


def _line(ax, spec: ChartSpec, rows: list[dict], colors: ColorRegistry) -> None:
    groups = _groups(rows) if spec.data.group else [None]
    categorical = not all(_num(r["_x"]) for r in rows)
    cats = sorted({str(r["_x"]) for r in rows}) if categorical else []
    for g in groups:
        pts = sorted(((r["_x"], r.get("_y")) for r in rows if r.get("_g") == g),
                     key=lambda p: str(p[0]) if categorical else p[0])
        xs = [cats.index(str(p[0])) for p in pts] if categorical else [p[0] for p in pts]
        ys = [p[1] for p in pts]
        color = _c(colors, g)
        ax.plot(xs, ys, color=color, linewidth=2, marker="o", markersize=4.5,
                markeredgecolor=SURFACE, markeredgewidth=1.0, label=str(g) if g is not None else None, zorder=3)
        if len(groups) <= 4 and g is not None and pts:  # direct end label
            ax.annotate(str(g), (xs[-1], ys[-1]), xytext=(6, 0), textcoords="offset points", va="center",
                        fontsize=8, color=TEXT_PRIMARY)
    if categorical:
        ax.set_xticks(range(len(cats)), cats)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.margins(x=0.08)
    _legend(ax, len(groups) if spec.data.group else 1)


def _scatter(ax, spec: ChartSpec, rows: list[dict], colors: ColorRegistry) -> None:
    groups = _groups(rows) if spec.data.group else [None]
    if len(groups) > ALL_PAIRS_CAP:
        raise ChartError(f"scatter supports at most {ALL_PAIRS_CAP} groups; facet or fold into 'Other'")
    for g in groups:
        pts = [(r["_x"], r["_y"]) for r in rows if r.get("_g") == g and r["_x"] is not None and r["_y"] is not None]
        color = _c(colors, g)
        ax.scatter([p[0] for p in pts], [p[1] for p in pts], s=22, color=color, edgecolors=SURFACE,
                   linewidths=0.8, alpha=0.9, label=str(g) if g is not None else None, zorder=3)
    ax.grid(axis="both")
    _legend(ax, len(groups) if spec.data.group else 1)


def _box(ax, spec: ChartSpec, rows: list[dict], colors: ColorRegistry) -> None:
    cats = sorted({r["_x"] for r in rows}, key=lambda v: (v is None, str(v)))
    data = [[r["_y"] for r in rows if r["_x"] == c and r["_y"] is not None] for c in cats]
    bp = ax.boxplot(data, patch_artist=True, widths=0.5, medianprops={"color": TEXT_PRIMARY, "linewidth": 1.5},
                    whiskerprops={"color": AXIS}, capprops={"color": AXIS},
                    flierprops={"marker": "o", "markersize": 3, "markerfacecolor": AXIS, "markeredgecolor": AXIS})
    for patch, c in zip(bp["boxes"], cats):
        patch.set_facecolor(colors.color(c))
        patch.set_alpha(0.85)
        patch.set_edgecolor(SURFACE)
    ax.set_xticks(range(1, len(cats) + 1), [str(c) for c in cats])


def _hist(ax, spec: ChartSpec, rows: list[dict], colors: ColorRegistry) -> None:
    groups = _groups(rows) if spec.data.group else [None]
    if len(groups) > ALL_PAIRS_CAP:
        raise ChartError(f"histogram overlays support at most {ALL_PAIRS_CAP} groups")
    values = [r["_x"] for r in rows if _num(r["_x"])]
    if not values:
        raise ChartError("histogram needs a numeric x")
    bins = max(5, min(30, int(math.sqrt(len(values)))))
    lo, hi = min(values), max(values)
    edges = [lo + (hi - lo) * i / bins for i in range(bins + 1)] if hi > lo else bins
    for g in groups:
        vals = [r["_x"] for r in rows if r.get("_g") == g and _num(r["_x"])]
        ax.hist(vals, bins=edges, color=_c(colors, g), alpha=0.7 if g is not None else 0.9,
                edgecolor=SURFACE, linewidth=1.0, label=str(g) if g is not None else None, zorder=2)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
    _legend(ax, len(groups) if spec.data.group else 1)
