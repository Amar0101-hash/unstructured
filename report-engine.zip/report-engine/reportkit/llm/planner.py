"""LLM planner: for each template slot, decide WHAT to compute or reuse.

Output is a SlotBinding (specs + element ids). The binding is checked by real
code before it is accepted: datasets and columns must exist, every spec must
compile, and DuckDB must be able to bind the SQL (EXPLAIN). Errors go back to
the model inside the same retry loop.
"""

from __future__ import annotations

import json

from reportkit.compute.compiler import CompileError, SpecCompiler
from reportkit.compute.session import ComputeSession, QueryError
from reportkit.compute.sql_guard import SqlRejected
from reportkit.llm.client import LLMClient
from reportkit.llm.retrieval import KeywordRetriever, RetrievalResult, Retriever
from reportkit.models.catalog import Catalog
from reportkit.models.compute import SlotBinding, SqlSpec, TableSpec
from reportkit.models.inventory import InventoryElement
from reportkit.models.plan import Slot

SYSTEM = """You plan the content of one slot in a regulated (GxP) report.
You do NOT compute numbers and you do NOT write prose. You decide which values to compute
and which source material to use, as JSON matching the given schema.

Rules:
- Use only datasets and columns listed in the catalog, spelled exactly.
- Filter values must be values that exist in the data (see listed sample values).
- Prefer declarative specs: `facts` (MetricSpec), `table` (TableSpec), `figure` (ChartSpec).
  Use a SqlSpec only when a TableSpec cannot express the result.
- Percentages of subjects: set `distinct_on` to the subject id column, and set a `denominator`
  on the subject-level dataset when the numerator dataset is event-level (e.g. adverse events).
- If the inputs already contain the exact table or figure the slot asks for, set `copy_element_id`
  to that element instead of recomputing it.
- narrative slots: list every value the text will need in `facts`, and the source material the writer
  should draw on: whole sections as `source_node_ids` (node ids shown in the INVENTORY), or single
  elements as `source_element_ids`.
- fact slots: exactly one entry in `facts`.
- verbatim slots: what to copy, in order: `source_node_ids` for whole sections, `source_element_ids`
  for single elements.
- ids (fact_id, table_id, figure_id, output_id) are lowercase snake_case, unique in the report.
- Return one JSON object and nothing else."""


def _schema_text() -> str:
    return json.dumps(SlotBinding.model_json_schema(), separators=(",", ":"))


class Planner:
    def __init__(self, llm: LLMClient, retriever: Retriever | None = None, top_k: int = 40):
        self.llm = llm
        self.retriever = retriever or KeywordRetriever()
        self.top_k = top_k
        self.traces: dict[str, dict] = {}  # slot_id -> retrieval trace, for the manifest

    @staticmethod
    def _inventory_text(res: RetrievalResult) -> str:
        def line(e: InventoryElement) -> str:
            return f"- {e.id} [{e.type}] {' > '.join(e.provenance.heading_path) or '(no heading)'} :: {e.preview()}"

        if not res.nodes:
            return "\n".join(line(e) for e in res.elements)
        by_id = {e.id: e for e in res.elements}
        blocks = []
        for n in res.nodes:
            body = "\n".join(line(by_id[i]) for i in n.element_ids if i in by_id)
            blocks.append(f"## section {n.node_id}: {' > '.join(n.path)}\n{body or '(no text)'}")
        return "\n\n".join(blocks)

    def plan_slot(self, slot: Slot, *, catalog: Catalog, elements: list[InventoryElement],
                  session: ComputeSession, used_ids: set[str], instructions: str | None = None,
                  memory: str = "", procedure: str = "") -> SlotBinding:
        res = self.retriever.retrieve(slot, elements, self.top_k)
        self.traces[slot.id] = res.trace
        element_index = {e.id: e for e in elements}
        node_ids = {n.node_id for n in res.nodes}
        inventory = self._inventory_text(res)
        user = "\n\n".join(filter(None, [
            f"SLOT id={slot.id} type={slot.type}",
            f"Heading: {' > '.join(slot.heading_path) or slot.heading or '(none)'}",
            f"Instruction from the template:\n{slot.instruction}",
            f"Style example from a previous report (structure only - do not copy its numbers):\n{slot.style_example[:2500]}"
            if slot.style_example else None,
            f"Global instructions:\n{instructions}" if instructions else None,
            f"MEMORY (approved rules and the current session - follow them)\n{memory}" if memory else None,
            f"PREVIOUS ACCEPTED PLAN for this slot (reuse it when the instruction and data still fit; "
            f"re-check every dataset and column against the catalog)\n{procedure}" if procedure else None,
            f"CATALOG\n{catalog.describe_for_llm() or '(no datasets)'}",
            f"INVENTORY (relevant elements from the input documents)\n{inventory or '(none)'}",
            f"Already used ids (do not reuse): {', '.join(sorted(used_ids)) or '(none)'}",
            f"JSON schema for your answer:\n{_schema_text()}",
            f'Set "slot_id" to "{slot.id}".',
        ]))

        compiler = SpecCompiler(catalog)

        def check(obj) -> list[str]:
            b: SlotBinding = obj
            errs: list[str] = []
            if b.slot_id != slot.id:
                errs.append(f'slot_id must be "{slot.id}"')
            errs += self._shape_errors(slot, b, element_index)
            ids = b.spec_ids()
            dupes = {i for i in ids if ids.count(i) > 1} | (set(ids) & used_ids)
            if dupes:
                errs.append(f"ids already used: {sorted(dupes)}")
            for eid in [*b.source_element_ids, *([b.copy_element_id] if b.copy_element_id else [])]:
                if eid not in element_index:
                    errs.append(f"unknown element id {eid}")
            for nid in b.source_node_ids:
                if nid not in node_ids:
                    errs.append(f"unknown section node id {nid}; use one of {sorted(node_ids) or 'none'}")
            errs += self._compile_errors(b, compiler, session)
            return errs

        return self.llm.complete_json(system=SYSTEM, user=user, schema=SlotBinding,
                                      purpose=f"plan:{slot.id}", check=check)

    @staticmethod
    def _shape_errors(slot: Slot, b: SlotBinding, elements: dict[str, InventoryElement]) -> list[str]:
        errs = []
        copied = elements.get(b.copy_element_id) if b.copy_element_id else None
        if slot.type == "table":
            if b.table is None and not (copied and copied.type == "table"):
                errs.append("table slot needs `table` or `copy_element_id` of a table element")
        elif slot.type == "figure":
            if b.figure is None and not (copied and copied.type == "figure"):
                errs.append("figure slot needs `figure` or `copy_element_id` of a figure element")
        elif slot.type == "fact":
            if len(b.facts) != 1:
                errs.append("fact slot needs exactly one entry in `facts`")
        elif slot.type == "verbatim":
            if not b.source_element_ids and not b.source_node_ids:
                errs.append("verbatim slot needs `source_node_ids` or `source_element_ids`")
        return errs

    @staticmethod
    def _compile_errors(b: SlotBinding, compiler: SpecCompiler, session: ComputeSession) -> list[str]:
        errs: list[str] = []
        queries = []
        try:
            queries += [(f.fact_id, compiler.metric(f)) for f in b.facts]
            if isinstance(b.table, TableSpec):
                queries += [(b.table.table_id, compiler.table_row(b.table, r, by_column=bool(b.table.col_by)))
                            for r in b.table.rows]
            elif isinstance(b.table, SqlSpec):
                queries.append((b.table.output_id, compiler.raw_sql(b.table)))
            if b.figure:
                queries.append((b.figure.figure_id, compiler.chart(b.figure, session.settings.max_chart_points)))
        except (CompileError, SqlRejected, KeyError) as e:
            return [str(e)]
        for spec_id, cq in queries:
            try:
                session.check(cq)
            except QueryError as e:
                errs.append(f"{spec_id}: {e}")
        return errs
