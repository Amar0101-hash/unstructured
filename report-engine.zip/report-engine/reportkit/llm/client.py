"""LLM access through the corporate LiteLLM hub (OpenAI-compatible API).

``complete_json`` asks for JSON matching a Pydantic model, validates it, and
on failure sends the validation error back for a bounded number of retries.
Callers can add their own semantic checks (``check``) - e.g. "that column
does not exist" - which feed into the same retry loop.

Every call is recorded (purpose, model, prompt/response hashes, tokens) for
the run manifest; prompts themselves are not stored there.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Callable, Protocol, TypeVar

from pydantic import BaseModel, ValidationError

from reportkit.settings import Settings

log = logging.getLogger(__name__)
M = TypeVar("M", bound=BaseModel)
Check = Callable[[BaseModel], list[str]]


@dataclass
class LLMCallRecord:
    purpose: str
    model: str
    prompt_sha256: str
    response_sha256: str
    attempt: int
    ok: bool
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    latency_ms: int = 0
    errors: list[str] = field(default_factory=list)


class LLMError(RuntimeError):
    pass


class LLMClient(Protocol):
    calls: list[LLMCallRecord]
    model: str

    def complete_json(self, *, system: str, user: str, schema: type[M], purpose: str,
                      check: Check | None = None) -> M: ...


_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.S)


def extract_json(text: str) -> dict:
    text = _FENCE.sub("", text.strip())
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("no JSON object in response")
    return json.loads(text[start:end + 1])


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


class _RetryingJsonMixin:
    max_retries: int
    calls: list[LLMCallRecord]
    model: str

    def _chat(self, messages: list[dict], schema: type[BaseModel], purpose: str) -> tuple[str, dict]:
        raise NotImplementedError

    def complete_json(self, *, system: str, user: str, schema: type[M], purpose: str,
                      check: Check | None = None) -> M:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        last_errors: list[str] = []
        for attempt in range(1, self.max_retries + 2):
            t0 = time.monotonic()
            text, usage = self._chat(messages, schema, purpose)
            rec = LLMCallRecord(purpose=purpose, model=self.model, prompt_sha256=_sha(json.dumps(messages)),
                                response_sha256=_sha(text), attempt=attempt, ok=False,
                                prompt_tokens=usage.get("prompt_tokens"),
                                completion_tokens=usage.get("completion_tokens"),
                                latency_ms=int((time.monotonic() - t0) * 1000))
            try:
                obj = schema.model_validate(extract_json(text))
                errors = check(obj) if check else []
            except (ValueError, ValidationError) as e:
                obj, errors = None, [str(e)[:2000]]
            rec.ok, rec.errors = not errors, errors
            self.calls.append(rec)
            if not errors:
                return obj  # type: ignore[return-value]
            last_errors = errors
            log.info("%s attempt %d rejected: %s", purpose, attempt, errors[:3])
            messages += [
                {"role": "assistant", "content": text},
                {"role": "user", "content": "Your answer was rejected:\n- " + "\n- ".join(errors[:20]) +
                 "\nReturn the corrected JSON object only."},
            ]
        raise LLMError(f"{purpose}: no valid answer after {self.max_retries + 1} attempts: {last_errors[:5]}")


class LiteLLMClient(_RetryingJsonMixin):
    def __init__(self, settings: Settings):
        from openai import BadRequestError, OpenAI  # noqa: PLC0415

        self._bad_request = BadRequestError
        self.client = OpenAI(base_url=settings.llm_base_url, api_key=settings.llm_api_key,
                             timeout=settings.llm_timeout_s, max_retries=3)
        self.model = settings.llm_model
        self.temperature = settings.llm_temperature
        self.max_retries = settings.llm_max_validation_retries
        self.calls: list[LLMCallRecord] = []

    def _chat(self, messages, schema, purpose):
        kwargs = dict(model=self.model, messages=messages, temperature=self.temperature, max_tokens=8000)
        try:
            resp = self.client.chat.completions.create(
                **kwargs,
                response_format={"type": "json_schema",
                                 "json_schema": {"name": schema.__name__, "schema": schema.model_json_schema()}},
            )
        except self._bad_request as e:  # some LiteLLM/Bedrock routes reject json_schema; the prompt still asks for JSON
            log.warning("json_schema response_format rejected (%s); retrying without it", type(e).__name__)
            resp = self.client.chat.completions.create(**kwargs)
        usage = resp.usage.model_dump() if resp.usage else {}
        return resp.choices[0].message.content or "", usage


class ScriptedLLM(_RetryingJsonMixin):
    """Deterministic stand-in for tests and local dev without the hub.
    ``responder(purpose, messages) -> dict`` returns the JSON to send back."""

    def __init__(self, responder: Callable[[str, list[dict]], dict], max_retries: int = 2):
        self.responder = responder
        self.model = "scripted"
        self.max_retries = max_retries
        self.calls: list[LLMCallRecord] = []

    def _chat(self, messages, schema, purpose):
        return json.dumps(self.responder(purpose, messages)), {}
