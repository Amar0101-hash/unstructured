"""Pick the inventory elements worth showing the planner for one slot.

``TreeRetriever`` (reportkit/tree/retriever.py) is the default: the LLM
navigates each document's section tree. ``KeywordRetriever`` is the
dependency-free fallback used when tree navigation is off or fails.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Protocol

from reportkit.models.inventory import InventoryElement
from reportkit.models.plan import Slot

_TOKEN = re.compile(r"[a-z0-9]{3,}")
_STOP = {"the", "and", "for", "with", "this", "that", "from", "are", "was", "were", "will", "shall", "into",
         "section", "table", "figure", "summary", "describe", "provide", "report", "include", "including"}


def tokens(text: str) -> list[str]:
    return [t for t in _TOKEN.findall(text.lower()) if t not in _STOP]


@dataclass
class NodeRef:
    node_id: str
    path: list[str]
    element_ids: list[str]


@dataclass
class RetrievalResult:
    elements: list[InventoryElement]
    nodes: list[NodeRef] = field(default_factory=list)  # empty for keyword retrieval
    trace: dict[str, Any] = field(default_factory=dict)  # recorded in the run manifest


class Retriever(Protocol):
    def retrieve(self, slot: Slot, elements: list[InventoryElement], k: int) -> RetrievalResult: ...


class KeywordRetriever:
    def top(self, slot: Slot, elements: list[InventoryElement], k: int = 40) -> list[InventoryElement]:
        if len(elements) <= k:
            return list(elements)
        docs = [tokens(" ".join([*e.provenance.heading_path, e.full_text()])) for e in elements]
        df = Counter(t for d in docs for t in set(d))
        n = len(docs)
        query = Counter(tokens(" ".join([slot.instruction, slot.heading or "", *slot.heading_path])))

        def score(i: int) -> float:
            tf = Counter(docs[i])
            s = sum(q * (tf[t] / (1 + len(docs[i]) ** 0.5)) * math.log(1 + n / (1 + df[t]))
                    for t, q in query.items() if t in tf)
            if elements[i].type in ("table", "figure"):
                s *= 1.3
            return s

        ranked = sorted(range(n), key=lambda i: (-score(i), i))[:k]
        return [elements[i] for i in sorted(ranked)]  # keep document order

    def retrieve(self, slot: Slot, elements: list[InventoryElement], k: int = 40) -> RetrievalResult:
        top = self.top(slot, elements, k)
        return RetrievalResult(elements=top, trace={"slot_id": slot.id, "method": "keyword",
                                                    "element_ids": [e.id for e in top]})
