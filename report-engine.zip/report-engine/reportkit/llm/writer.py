"""LLM writer: prose for narrative slots, with numbers only as fact placeholders."""

from __future__ import annotations

from pydantic import BaseModel, Field

from reportkit.assembly.numbers import placeholder_ids, unbacked_numbers
from reportkit.llm.client import LLMClient
from reportkit.models.inventory import InventoryElement
from reportkit.models.plan import Slot
from reportkit.models.results import Fact

SYSTEM = """You write one section of a regulated (GxP) clinical/scientific report.

Hard rules:
- Every computed value MUST be written as a placeholder {{fact:<id>}} using the ids listed under FACTS.
  Never type a computed number yourself, never round, never derive new numbers (no differences, no
  ratios) - if a value you need is not in FACTS, describe it qualitatively.
- Digits are allowed only when they appear verbatim in the SOURCE material (study ids, visit names,
  protocol section numbers).
- Write in the register and structure of the style example if one is given, but use only the facts
  and sources provided here. Never copy facts or numbers from the style example.
- Plain text paragraphs, no markdown, no headings (the template already has the heading).
- Return JSON: {"paragraphs": ["...", "..."]}"""


class WriterOutput(BaseModel):
    paragraphs: list[str] = Field(min_length=1)


class Writer:
    def __init__(self, llm: LLMClient, source_char_budget: int = 24_000):
        self.llm = llm
        self.budget = source_char_budget

    def write(self, slot: Slot, *, facts: list[Fact], sources: list[InventoryElement],
              instructions: str | None = None, vocabulary: str = "", memory: str = "") -> WriterOutput:
        """``vocabulary``: data-backed terms that may contain digits (e.g. arm names
        like "Drug 10 mg" from the catalog's distinct values)."""
        fact_lines = "\n".join(f"- {{{{fact:{f.id}}}}} = {f.label}: {f.display}" for f in facts)
        src_parts, used = [], 0
        for e in sources:
            txt = e.full_text()
            if used + len(txt) > self.budget:
                break
            src_parts.append(f"[{e.id} | {' > '.join(e.provenance.heading_path)}]\n{txt}")
            used += len(txt)
        source_text = "\n\n".join(src_parts)
        user = "\n\n".join(filter(None, [
            f"SECTION heading: {' > '.join(slot.heading_path) or slot.heading or '(none)'}",
            f"Instruction from the template:\n{slot.instruction}",
            f"Style example (structure and tone only):\n{slot.style_example[:3000]}" if slot.style_example else None,
            f"Global instructions:\n{instructions}" if instructions else None,
            f"MEMORY (house rules, preferences and the current session - follow them)\n{memory}" if memory else None,
            f"FACTS (use only as placeholders)\n{fact_lines or '(none)'}",
            f"SOURCE material\n{source_text or '(none)'}",
        ]))
        known = {f.id for f in facts}
        allowed = "\n".join([source_text, vocabulary, slot.instruction, slot.heading or "", *slot.heading_path])

        def check(obj) -> list[str]:
            out: WriterOutput = obj
            errs = []
            for i, p in enumerate(out.paragraphs, 1):
                bad = [fid for fid in placeholder_ids(p) if fid not in known]
                if bad:
                    errs.append(f"paragraph {i}: unknown fact ids {bad}; available: {sorted(known)}")
                nums = unbacked_numbers(p, allowed)
                if nums:
                    errs.append(f"paragraph {i}: numbers {nums} are not facts and not in the sources; "
                                f"use {{{{fact:<id>}}}} placeholders or remove them")
            return errs

        return self.llm.complete_json(system=SYSTEM, user=user, schema=WriterOutput,
                                      purpose=f"write:{slot.id}", check=check)
