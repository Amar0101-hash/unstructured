"""Compile a Word template into a ReportPlan.

Slots are content controls (SDTs) whose tag is ``rk:<type>:<slot_id>``:

    rk:narrative:efficacy_summary   block-level: generated prose
    rk:table:demographics           block-level: summary table
    rk:figure:age_by_arm            block-level: chart
    rk:fact:n_randomized            inline (inside a sentence) or block: one value
    rk:verbatim:inclusion_criteria  block-level: copied from the inputs

The placeholder text inside the control is the instruction for that slot.
Authors add controls from Word's Developer tab > Plain/Rich Text Content
Control > Properties > Tag. The example report supplies style per section
(matched by heading), never data.
"""

from __future__ import annotations

import difflib
import io
import re

import docx
from docx.text.paragraph import Paragraph
from lxml import etree

from reportkit.models.inventory import InventoryElement
from reportkit.models.plan import ReportPlan, Slot

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
TAG_RE = re.compile(r"^rk:(narrative|table|figure|fact|verbatim):([a-z][a-z0-9_]{0,39})$")
_HEADING = re.compile(r"^(heading|titre|überschrift)\s*(\d)", re.I)
_NUMBERING = re.compile(r"^\s*(\d+(\.\d+)*\.?|[A-Z]\.|appendix\s+\w+[:.]?)\s+", re.I)

XP_SDT_DESC = etree.XPath(".//w:sdt", namespaces=NS)
XP_TAG = etree.XPath("./w:sdtPr/w:tag/@w:val", namespaces=NS)
XP_TEXT = etree.XPath("./w:sdtContent//w:t/text()", namespaces=NS)


class TemplateError(ValueError):
    pass


def _q(tag: str) -> str:
    return f"{{{W}}}{tag}"


def heading_level(p: Paragraph) -> int | None:
    name = (p.style.name if p.style is not None else "") or ""
    m = _HEADING.match(name)
    if m:
        return int(m.group(2))
    if name.lower() == "title":
        return 1
    return None


def iter_slots(doc: docx.document.Document):
    """Yield (sdt_element, slot_type, slot_id, inline, heading_path) in document order."""
    path: list[str] = []
    for child in doc.element.body.iterchildren():
        if child.tag == _q("p"):
            p = Paragraph(child, doc)
            lvl = heading_level(p)
            if lvl and p.text.strip():
                path = path[: lvl - 1] + [p.text.strip()]
        candidates = [child] if child.tag == _q("sdt") else []
        candidates += XP_SDT_DESC(child)
        for sdt in candidates:
            tags = XP_TAG(sdt)
            if not tags:
                continue
            m = TAG_RE.match(tags[0])
            if not m:
                continue
            inline = sdt.getparent() is not None and sdt.getparent().tag == _q("p")
            yield sdt, m.group(1), m.group(2), inline, list(path)


def compile_template(data: bytes, template_file_id: str) -> ReportPlan:
    doc = docx.Document(io.BytesIO(data))
    slots: list[Slot] = []
    seen: set[str] = set()
    for order, (sdt, stype, sid, inline, path) in enumerate(iter_slots(doc)):
        if sid in seen:
            raise TemplateError(f"duplicate slot id {sid!r} in template")
        seen.add(sid)
        if inline and stype not in ("fact",):
            raise TemplateError(f"slot {sid!r}: only fact slots may sit inside a paragraph")
        instruction = " ".join("".join(XP_TEXT(sdt)).split())
        slots.append(Slot(id=sid, type=stype, instruction=instruction or f"Fill the {stype} '{sid}'.",
                          heading=path[-1] if path else None, heading_path=path, inline=inline, order=order))
    if not slots:
        raise TemplateError("template has no content controls tagged rk:<type>:<id>")
    return ReportPlan(template_file_id=template_file_id, slots=slots)


def _norm_heading(h: str) -> str:
    return " ".join(_NUMBERING.sub("", h).lower().split())


def attach_style_examples(plan: ReportPlan, example_elements: list[InventoryElement], max_chars: int = 4000) -> None:
    """For each slot, find the example report's section with the closest heading."""
    sections: dict[str, list[str]] = {}
    for e in example_elements:
        if e.type == "heading" or not e.provenance.heading_path:
            continue
        key = _norm_heading(e.provenance.heading_path[-1])
        sections.setdefault(key, []).append(e.full_text())
    if not sections:
        return
    keys = list(sections)
    for slot in plan.slots:
        if not slot.heading:
            continue
        match = difflib.get_close_matches(_norm_heading(slot.heading), keys, n=1, cutoff=0.75)
        if match:
            slot.style_example = "\n\n".join(sections[match[0]])[:max_chars]
