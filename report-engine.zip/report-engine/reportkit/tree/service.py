"""Build-once, reuse-everywhere tree cache in the blob store (S3 in prod).

Key: trees/<file sha256>/<parser version>/<summarizer>.json - the same
document uploaded in another job (or by another user) reuses the tree and
its summaries with no LLM calls.
"""

from __future__ import annotations

import logging
import re

from reportkit.llm.client import LLMClient
from reportkit.models.inventory import InventoryElement
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore
from reportkit.storage.repository import Repository
from reportkit.tree.builder import EXTRACTIVE, build_tree, summarize_tree
from reportkit.tree.models import DocumentTree

log = logging.getLogger(__name__)


def _safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)


class TreeService:
    def __init__(self, settings: Settings, repo: Repository, blob: BlobStore):
        self.settings, self.repo, self.blob = settings, repo, blob

    def summarizer_id(self, llm: LLMClient | None) -> str:
        if self.settings.tree_summaries == "llm" and llm is not None:
            return f"llm-1:{llm.model}"
        return EXTRACTIVE

    def key(self, sha256: str, parser_version: str, summarizer: str) -> str:
        return f"trees/{sha256}/{_safe(parser_version)}/{_safe(summarizer)}.json"

    def load(self, file_id: str, parser_version: str, llm: LLMClient | None) -> DocumentTree | None:
        row = self.repo.get_file(file_id)
        uri = self.blob.uri_for(self.key(row.sha256, parser_version, self.summarizer_id(llm)))
        if self.blob.exists(uri):
            return DocumentTree.model_validate_json(self.blob.get_bytes(uri))
        return None

    def ensure_tree(self, file_id: str, elements: list[InventoryElement], parser_version: str,
                    llm: LLMClient | None) -> DocumentTree:
        cached = self.load(file_id, parser_version, llm)
        if cached is not None:
            return cached
        row = self.repo.get_file(file_id)
        tree = build_tree(elements, file_id=file_id, filename=row.filename, sha256=row.sha256,
                          parser_version=parser_version)
        use_llm = llm if self.settings.tree_summaries == "llm" else None
        summarize_tree(tree, elements, use_llm, min_chars_for_llm=self.settings.tree_summary_min_chars,
                       concurrency=self.settings.llm_concurrency)
        key = self.key(row.sha256, parser_version, tree.summarizer)
        self.blob.put_bytes(key, tree.model_dump_json(indent=1).encode(), "application/json")
        log.info("built tree for %s: %d nodes (%s)", row.filename, sum(1 for _ in tree.nodes()), tree.summarizer)
        return tree
