"""Index over all document trees in a job: lookups, outlines, expansion."""

from __future__ import annotations

from reportkit.tree.models import DocumentTree, TreeNode


class DocumentForest:
    def __init__(self, trees: list[DocumentTree]):
        self.trees = trees
        self.nodes: dict[str, TreeNode] = {}
        self.parent: dict[str, str | None] = {}
        self.tree_of: dict[str, DocumentTree] = {}
        for t in trees:
            stack: list[tuple[TreeNode, str | None]] = [(t.root, None)]
            while stack:
                n, p = stack.pop()
                self.nodes[n.node_id] = n
                self.parent[n.node_id] = p
                self.tree_of[n.node_id] = t
                stack += [(c, n.node_id) for c in n.children]

    def path(self, node_id: str) -> list[str]:
        out, cur = [], node_id
        while cur is not None:
            out.append(self.nodes[cur].title)
            cur = self.parent[cur]
        return list(reversed(out))

    def subtree_element_ids(self, node_id: str) -> list[str]:
        """All content elements under a node, in document order."""
        out: list[str] = []

        def visit(n: TreeNode) -> None:
            out.extend(n.element_ids)
            for c in n.children:
                visit(c)

        visit(self.nodes[node_id])
        return out

    def expand(self, node_ids: list[str]) -> list[str]:
        seen: set[str] = set()
        out: list[str] = []
        for nid in node_ids:
            if nid not in self.nodes:
                continue
            for eid in self.subtree_element_ids(nid):
                if eid not in seen:
                    seen.add(eid)
                    out.append(eid)
        return out

    def outline(self, frontier: dict[str, int], max_chars: int) -> tuple[str, list[str]]:
        """Render the tree for the navigator. ``frontier`` maps node ids to how
        many levels below them to show. Returns (text, shown node ids)."""
        lines: list[str] = []
        shown: list[str] = []
        size = 0

        def line(n: TreeNode, depth: int) -> str:
            kids = f", {len(n.children)} subsections" if n.children else ""
            pages = f", p.{n.pages[0]}-{n.pages[1]}" if n.pages else ""
            return (f"{'  ' * depth}{n.node_id} [{n.kind}] {n.title} — {n.summary[:220]} "
                    f"({n.subtree_chars()} chars{pages}{kids})")

        def visit(n: TreeNode, depth: int, budget: int) -> None:
            nonlocal size
            txt = line(n, depth)
            if size + len(txt) > max_chars:
                return
            lines.append(txt)
            shown.append(n.node_id)
            size += len(txt) + 1
            extra = frontier.get(n.node_id, 0)
            left = max(budget - 1, extra)
            if left > 0:
                for c in n.children:
                    visit(c, depth + 1, left)

        for t in self.trees:
            visit(t.root, 0, frontier.get(t.root.node_id, 2))
        return "\n".join(lines), shown
