"""Inventory -> DocumentTree, plus node summaries.

Structure comes from headings. Documents without usable headings (scanned
PDFs, exports) fall back to one node per page, or fixed-size parts; very
long sections are split into parts so a selection never drags in 50 pages.
Tables and figures become their own leaf nodes so the navigator can pick
them directly (e.g. to copy a schedule-of-assessments table).
"""

from __future__ import annotations

import hashlib
import logging
from concurrent.futures import ThreadPoolExecutor

from pydantic import BaseModel

from reportkit.llm.client import LLMClient, LLMError
from reportkit.models.inventory import InventoryElement
from reportkit.tree.models import DocumentTree, TreeNode

log = logging.getLogger(__name__)

EXTRACTIVE = "extractive-1"
MAX_SECTION_CHARS = 12_000  # split bigger sections into parts
PART_CHARS = 6_000
FLAT_DOC_MIN_ELEMENTS = 8  # a doc with no headings and more elements than this gets synthetic nodes


def _node_id(file_id: str, idx: int) -> str:
    short = hashlib.sha256(file_id.encode()).hexdigest()[:6]
    return f"{short}.{idx}"


def _pages(els: list[InventoryElement]) -> tuple[int, int] | None:
    pages = [e.provenance.page for e in els if e.provenance.page is not None]
    return (min(pages), max(pages)) if pages else None


def _leaf_title(el: InventoryElement, prev_caption: str | None) -> str:
    if prev_caption:
        return prev_caption
    if el.type == "figure" and el.figure and el.figure.caption:
        return el.figure.caption
    if el.type == "table" and el.table:
        return "Table: " + ", ".join(el.table.columns[:6])
    return el.type.title()


def build_tree(elements: list[InventoryElement], *, file_id: str, filename: str, sha256: str,
               parser_version: str) -> DocumentTree:
    counter = iter(range(1_000_000))
    by_id = {e.id: e for e in elements}
    root = TreeNode(node_id=_node_id(file_id, next(counter)), title=filename, kind="document", level=0)
    stack = [root]
    pending_caption: str | None = None

    for el in elements:
        if el.type == "heading" and el.text:
            lvl = max(1, el.level or 1)
            while stack[-1].level >= lvl:
                stack.pop()
            node = TreeNode(node_id=_node_id(file_id, next(counter)), title=el.text, kind="section", level=lvl,
                            heading_element_id=el.id)
            stack[-1].children.append(node)
            stack.append(node)
            pending_caption = None
        elif el.type in ("table", "figure"):
            parent = stack[-1]
            parent.children.append(TreeNode(node_id=_node_id(file_id, next(counter)), kind=el.type,
                                            title=_leaf_title(el, pending_caption), level=parent.level + 1,
                                            element_ids=[el.id], pages=_pages([el]),
                                            n_chars=len(el.full_text())))
            pending_caption = None
        else:
            stack[-1].element_ids.append(el.id)
            stack[-1].n_chars += len(el.full_text())
            pending_caption = el.text if el.type == "caption" else None

    if not any(c.kind == "section" for c in root.children) and len(root.element_ids) > FLAT_DOC_MIN_ELEMENTS:
        _synthesize_sections(root, by_id, file_id, counter)
    for node in list(root.walk()):
        if node.kind == "section" and node.n_chars > MAX_SECTION_CHARS:
            _split_parts(node, by_id, file_id, counter)
    for node in root.walk():
        if node.pages is None:
            node.pages = _pages([by_id[i] for n in node.walk() for i in n.element_ids if i in by_id])
    return DocumentTree(file_id=file_id, filename=filename, sha256=sha256, parser_version=parser_version,
                        summarizer=EXTRACTIVE, root=root)


def _synthesize_sections(root: TreeNode, by_id, file_id: str, counter) -> None:
    """No headings: group by page when pages are known, else fixed-size parts."""
    els = [by_id[i] for i in root.element_ids]
    groups: list[tuple[str, list[InventoryElement]]] = []
    if all(e.provenance.page is not None for e in els):
        for e in els:
            title = f"Page {e.provenance.page}"
            if not groups or groups[-1][0] != title:
                groups.append((title, []))
            groups[-1][1].append(e)
    else:
        size = 0
        for e in els:
            if not groups or size > PART_CHARS:
                groups.append((f"Part {len(groups) + 1}", []))
                size = 0
            groups[-1][1].append(e)
            size += len(e.full_text())
    root.element_ids, root.n_chars = [], 0
    synthetic = [TreeNode(node_id=_node_id(file_id, next(counter)), title=t, kind="part", level=1,
                          element_ids=[e.id for e in g], n_chars=sum(len(e.full_text()) for e in g))
                 for t, g in groups]
    root.children = synthetic + root.children


def _split_parts(node: TreeNode, by_id, file_id: str, counter) -> None:
    parts: list[list[str]] = [[]]
    size = 0
    for i in node.element_ids:
        n = len(by_id[i].full_text()) if i in by_id else 0
        if size + n > PART_CHARS and parts[-1]:
            parts.append([])
            size = 0
        parts[-1].append(i)
        size += n
    if len(parts) < 2:
        return
    kids = [TreeNode(node_id=_node_id(file_id, next(counter)), title=f"{node.title} (part {k + 1})", kind="part",
                     level=node.level + 1, element_ids=ids,
                     n_chars=sum(len(by_id[i].full_text()) for i in ids if i in by_id))
            for k, ids in enumerate(parts)]
    node.element_ids, node.n_chars = [], 0
    node.children = kids + node.children


# ---- summaries ----------------------------------------------------------------

class NodeSummary(BaseModel):
    summary: str


SUMMARY_SYSTEM = """You write navigation summaries for sections of a document.
A summary tells a reader WHETHER this section contains what they are looking for.
1-2 sentences, at most 60 words. Name the concrete topics, populations, endpoints,
tables or criteria covered. Do not include numeric results. Return {"summary": "..."}."""


def _own_text(node: TreeNode, by_id, limit: int = 8000) -> str:
    return "\n".join(by_id[i].full_text() for i in node.element_ids if i in by_id)[:limit]


def _extractive(node: TreeNode, by_id) -> str:
    txt = " ".join(_own_text(node, by_id, 600).split())
    if node.kind in ("table", "figure"):
        return txt[:240] or node.title
    if not txt and node.children:
        return "Contains: " + "; ".join(c.title for c in node.children[:8])
    return txt[:240]


def summarize_tree(tree: DocumentTree, elements: list[InventoryElement], llm: LLMClient | None,
                   min_chars_for_llm: int = 500, concurrency: int = 4) -> DocumentTree:
    """Bottom-up. Short nodes get extractive summaries (no LLM call); long ones
    and parents of many children get an LLM summary. Failures fall back to
    extractive, so a summarizer outage never blocks report generation."""
    by_id = {e.id: e for e in elements}
    nodes = list(tree.nodes())
    for n in nodes:
        n.summary = _extractive(n, by_id)
    if llm is None:
        tree.summarizer = EXTRACTIVE
        return tree

    def needs_llm(n: TreeNode) -> bool:
        return n.n_chars >= min_chars_for_llm or (n.kind in ("document", "section") and len(n.children) >= 3)

    def run(n: TreeNode) -> None:
        kids = "\n".join(f"- {c.title}: {c.summary}" for c in n.children)
        user = f"Section title: {n.title}\n\nSection text:\n{_own_text(n, by_id) or '(none)'}" + \
               (f"\n\nSubsections:\n{kids}" if kids else "")
        try:
            n.summary = llm.complete_json(system=SUMMARY_SYSTEM, user=user, schema=NodeSummary,
                                          purpose=f"summarize:{n.node_id}").summary.strip()[:600]
        except LLMError as e:
            log.warning("summary for %s failed, keeping extractive: %s", n.node_id, e)

    # Leaves first, then each level upward, so parents see their children's summaries.
    by_depth: dict[int, list[TreeNode]] = {}
    for n in nodes:
        by_depth.setdefault(n.level, []).append(n)
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        for depth in sorted(by_depth, reverse=True):
            list(pool.map(run, [n for n in by_depth[depth] if needs_llm(n)]))
    tree.summarizer = f"llm-1:{llm.model}"
    return tree
