"""Vectorless retrieval: the LLM reads the section outline and chooses.

For each slot the navigator sees an outline (node id, kind, title, summary,
size) of every input document. It selects the nodes the slot needs and may
ask to expand nodes whose summary is too coarse to judge; after at most
``tree_nav_rounds`` it must commit. Selected nodes are expanded to their
inventory elements in document order, capped at ``tree_context_chars``.

The full reasoning path (what was shown, what was chosen and why) goes into
the run manifest, so a reviewer can see why a source passage was used.
"""

from __future__ import annotations

import logging

from pydantic import BaseModel, Field

from reportkit.llm.client import LLMClient, LLMError
from reportkit.llm.retrieval import KeywordRetriever, NodeRef, RetrievalResult
from reportkit.models.inventory import InventoryElement
from reportkit.models.plan import Slot
from reportkit.settings import Settings
from reportkit.tree.forest import DocumentForest

log = logging.getLogger(__name__)

NAV_SYSTEM = """You choose which sections of the input documents are needed to fill one slot of a report.

- Select the smallest set of nodes whose content the slot actually needs.
- Select a parent node only when most of its subsections are needed; otherwise select the subsections.
- Tables and figures are their own nodes; select them when the slot reuses or describes them.
- If the slot is computed entirely from datasets and needs no document text, select nothing.
- If a node's summary is too coarse to judge, put it in "expand" (only nodes that have subsections)
  and you will be shown its subsections.
Return JSON: {"reasoning": "<one or two sentences>", "select": [node ids], "expand": [node ids]}"""


class NavigateOutput(BaseModel):
    reasoning: str = ""
    select: list[str] = Field(default_factory=list)
    expand: list[str] = Field(default_factory=list)


class TreeRetriever:
    def __init__(self, forest: DocumentForest, llm: LLMClient, settings: Settings,
                 fallback: KeywordRetriever | None = None):
        self.forest, self.llm, self.settings = forest, llm, settings
        self.fallback = fallback or KeywordRetriever()

    def retrieve(self, slot: Slot, elements: list[InventoryElement], k: int = 40) -> RetrievalResult:
        if not self.forest.trees:
            return RetrievalResult(elements=[], trace={"slot_id": slot.id, "method": "tree", "note": "no documents"})
        try:
            return self._navigate(slot, elements)
        except LLMError as e:
            log.warning("tree navigation failed for %s, using keyword fallback: %s", slot.id, e)
            res = self.fallback.retrieve(slot, elements, k)
            res.trace.update(method="keyword_fallback", error=str(e)[:500])
            return res

    def _navigate(self, slot: Slot, elements: list[InventoryElement]) -> RetrievalResult:
        f, s = self.forest, self.settings
        roots = [t.root.node_id for t in f.trees]
        _, shown_all = f.outline({r: 99 for r in roots}, s.tree_outline_chars)
        # Small enough: show the whole tree in one go. Otherwise start shallow.
        frontier = {r: 99 for r in roots} if len(shown_all) == len(f.nodes) else {r: 2 for r in roots}

        selected: list[str] = []
        rounds: list[dict] = []
        for r in range(s.tree_nav_rounds):
            outline, shown = f.outline(frontier, s.tree_outline_chars)
            shown_set = set(shown)
            last = r == s.tree_nav_rounds - 1
            hidden = len(f.nodes) - len(shown)
            user = "\n\n".join(filter(None, [
                f"SLOT {slot.id} ({slot.type})",
                f"Heading: {' > '.join(slot.heading_path) or slot.heading or '(none)'}",
                f"Instruction:\n{slot.instruction}",
                f"Already selected: {', '.join(selected)}" if selected else None,
                f"DOCUMENT OUTLINE (node_id [kind] title — summary (size))\n{outline}",
                f"{hidden} deeper nodes are not shown; expand a node to see them." if hidden and not last else None,
                "This is the final round: do not expand, only select." if last else None,
            ]))

            def check(obj, shown_set=shown_set, last=last) -> list[str]:
                o: NavigateOutput = obj
                errs = [f"unknown node id {n}" for n in o.select + o.expand if n not in f.nodes]
                errs += [f"node {n} was not in the outline" for n in o.select + o.expand
                         if n in f.nodes and n not in shown_set]
                errs += [f"node {n} has no subsections to expand" for n in o.expand
                         if n in f.nodes and not f.nodes[n].children]
                if last and o.expand:
                    errs.append("final round: select only")
                return errs

            out = self.llm.complete_json(system=NAV_SYSTEM, user=user, schema=NavigateOutput,
                                         purpose=f"navigate:{slot.id}", check=check)
            selected += [n for n in out.select if n not in selected]
            rounds.append({"round": r + 1, "nodes_shown": len(shown), "select": out.select,
                           "expand": out.expand, "reasoning": out.reasoning})
            if not out.expand:
                break
            for n in out.expand:
                frontier[n] = 2

        # Drop nodes already covered by a selected ancestor.
        def covered(n: str) -> bool:
            p = f.parent.get(n)
            while p is not None:
                if p in selected:
                    return True
                p = f.parent.get(p)
            return False

        selected = [n for n in selected if not covered(n)]
        index = {e.id: e for e in elements}
        picked: list[InventoryElement] = []
        nodes: list[NodeRef] = []
        used, truncated = 0, False
        for nid in selected:
            ids = [i for i in f.subtree_element_ids(nid) if i in index]
            kept = []
            for i in ids:
                n = len(index[i].full_text())
                if used + n > s.tree_context_chars and picked:
                    truncated = True
                    break
                picked.append(index[i])
                kept.append(i)
                used += n
            nodes.append(NodeRef(node_id=nid, path=f.path(nid), element_ids=kept))
            if truncated:
                break
        return RetrievalResult(elements=picked, nodes=nodes, trace={
            "slot_id": slot.id, "method": "tree", "rounds": rounds, "selected": selected,
            "selected_paths": [" > ".join(f.path(n)) for n in selected], "n_elements": len(picked),
            "n_chars": used, "truncated": truncated})
