"""Document tree: the vectorless index over parsed documents.

One tree per input file, built from the inventory's heading hierarchy. Each
node carries a short summary used only for navigation (never as report
content) and the inventory element ids it owns. Trees are stored as JSON in
the blob store, keyed by the file's content hash, parser version and
summarizer, so they are built once and reused by every job.
"""

from __future__ import annotations

from typing import Iterator, Literal

from pydantic import BaseModel, Field

NodeKind = Literal["document", "section", "part", "table", "figure"]


class TreeNode(BaseModel):
    node_id: str
    title: str
    kind: NodeKind
    level: int
    summary: str = ""
    element_ids: list[str] = Field(default_factory=list)  # content owned directly by this node
    heading_element_id: str | None = None
    pages: tuple[int, int] | None = None
    n_chars: int = 0  # own text size
    children: list["TreeNode"] = Field(default_factory=list)

    def walk(self) -> Iterator["TreeNode"]:
        yield self
        for c in self.children:
            yield from c.walk()

    def subtree_chars(self) -> int:
        return sum(n.n_chars for n in self.walk())


class DocumentTree(BaseModel):
    file_id: str
    filename: str
    sha256: str
    parser_version: str
    summarizer: str  # "extractive-1" or "llm-1:<model>"
    root: TreeNode

    def nodes(self) -> Iterator[TreeNode]:
        return self.root.walk()


TreeNode.model_rebuild()
