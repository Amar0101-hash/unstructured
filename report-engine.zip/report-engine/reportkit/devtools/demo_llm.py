"""A scripted stand-in for the LLM that knows the sample template.

Used by the tests and by ``RK_LLM_BACKEND=demo`` for local runs without the
GenAI hub. It deliberately makes one planning mistake and one writing mistake
on the first attempt, so the validation-retry loop is exercised every run.
"""

from __future__ import annotations

import re

from reportkit.llm.client import ScriptedLLM

_EL = re.compile(r"^- (el_[0-9a-f]+) \[(\w+)\] (.*?) :: (.*)$", re.M)
_NODE = re.compile(r"^\s*(\S+) \[(section|part|table|figure|document)\] (.*?) — ", re.M)
_SECTION = re.compile(r"^## section (\S+): (.*)$", re.M)
_EVENT = re.compile(r"^\[e(\d+) (user|assistant|system) (\w+)\] (.*)$", re.M)
_DEMO_STOP = {"study", "protocol", "synopsis", "subjects", "treatment", "copy", "reproduce", "from", "per"}
_FACT = re.compile(r"^- \{\{fact:([a-z0-9_]+)\}\} = (.*?): (.*)$", re.M)


def _elements(text: str) -> list[tuple[str, str, str, str]]:
    return _EL.findall(text)


def _find(text: str, type_: str, heading_contains: str) -> str | None:
    for eid, t, path, _prev in _elements(text):
        if t == type_ and heading_contains.lower() in path.lower():
            return eid
    return None


SAF = [{"col": "saffl", "op": "=", "value": "Y"}]
SAF_DEN = {"dataset": "adsl", "filters": SAF, "distinct_on": "usubjid", "col_by": "trt01a"}
ARMS = ["Drug 10 mg", "Placebo"]


def _plan(slot: str, prompt: str, retry: bool) -> dict:
    if slot == "n_randomized":
        return {"slot_id": slot, "facts": [{"fact_id": "n_randomized", "label": "Subjects randomized",
                                            "dataset": "adsl", "metric": "count", "distinct_on": "usubjid"}]}
    if slot == "study_population":
        facts = [{"fact_id": "n_rand_total", "label": "Subjects randomized", "dataset": "adsl", "metric": "count",
                  "distinct_on": "usubjid"},
                 {"fact_id": "compl_total", "label": "Completed the study (all subjects)", "dataset": "adsl",
                  "metric": "n_pct", "distinct_on": "usubjid",
                  "numerator": [{"col": "complfl", "op": "=", "value": "Y"}]}]
        for i, arm in enumerate(ARMS, 1):
            pop = [{"col": "trt01a", "op": "=", "value": arm}]
            facts.append({"fact_id": f"n_rand_arm{i}", "label": f"Randomized to {arm}", "dataset": "adsl",
                          "metric": "count", "distinct_on": "usubjid", "filters": pop})
            facts.append({"fact_id": f"compl_arm{i}", "label": f"Completed, {arm}", "dataset": "adsl",
                          "metric": "n_pct", "distinct_on": "usubjid", "filters": pop,
                          "numerator": [{"col": "complfl", "op": "=", "value": "Y"}]})
        design = _find(prompt, "paragraph", "study design")
        return {"slot_id": slot, "facts": facts, "source_element_ids": [design] if design else []}
    if slot == "demographics":
        # First attempt uses a column that does not exist -> rejected by the compiler check.
        col_by = "trt01a" if retry else "arm"
        return {"slot_id": slot, "table": {
            "kind": "table", "table_id": "demographics", "title": "Table 1 Demographics (safety population)",
            "dataset": "adsl", "filters": SAF, "col_by": col_by, "col_order": ARMS, "include_total": True,
            "header_n": {"dataset": "adsl", "filters": SAF, "distinct_on": "usubjid"}, "stub_header": "Characteristic",
            "rows": [
                {"label": "Age (years), mean (SD)", "metric": "mean_sd", "column": "age"},
                {"label": "Age (years), median", "metric": "median", "column": "age"},
                {"label": "Sex, n (%)", "metric": "n_pct", "row_by": "sex", "distinct_on": "usubjid",
                 "format": {"decimals": 1}},
                {"label": "Race, n (%)", "metric": "n_pct", "row_by": "race", "distinct_on": "usubjid"},
            ]}}
    if slot == "age_by_arm":
        return {"slot_id": slot, "figure": {
            "kind": "chart", "figure_id": "age_by_arm", "title": "Figure 1 Age by treatment arm", "chart": "box",
            "data": {"dataset": "adsl", "filters": SAF, "x": "trt01a", "y": "age"},
            "x_label": "", "y_label": "Age (years)"}}
    if slot == "ae_by_term":
        return {"slot_id": slot, "table": {
            "kind": "table", "table_id": "ae_by_term", "title": "Table 2 TEAEs by preferred term",
            "dataset": "adae", "filters": [{"col": "trtemfl", "op": "=", "value": "Y"}], "col_by": "trta",
            "col_order": ARMS, "include_total": True, "header_n": SAF_DEN, "stub_header": "Preferred term",
            "sort_expanded": "count_desc",
            "footnote": "Subjects are counted once per preferred term. Percentages use N per arm.",
            "rows": [
                {"label": "Any TEAE", "metric": "n_pct", "distinct_on": "usubjid",
                 "numerator": [{"col": "trtemfl", "op": "=", "value": "Y"}], "denominator": SAF_DEN},
                {"label": "By preferred term", "metric": "n_pct", "row_by": "aedecod", "distinct_on": "usubjid",
                 "denominator": SAF_DEN},
            ]}}
    if slot == "ae_summary":
        facts = []
        for i, arm in enumerate(ARMS, 1):
            facts.append({"fact_id": f"teae_arm{i}", "label": f"Subjects with any TEAE, {arm}", "dataset": "adae",
                          "metric": "n_pct", "distinct_on": "usubjid",
                          "filters": [{"col": "trta", "op": "=", "value": arm}],
                          "numerator": [{"col": "trtemfl", "op": "=", "value": "Y"}],
                          "denominator": {"dataset": "adsl", "distinct_on": "usubjid",
                                          "filters": [*SAF, {"col": "trt01a", "op": "=", "value": arm}]}})
        facts.append({"fact_id": "sae_any", "label": "Subjects with any serious AE", "dataset": "adae",
                      "metric": "n_pct", "distinct_on": "usubjid",
                      "numerator": [{"col": "aeser", "op": "=", "value": "Y"}],
                      "denominator": {"dataset": "adsl", "distinct_on": "usubjid", "filters": SAF}})
        return {"slot_id": slot, "facts": facts}
    if slot == "inclusion_criteria":
        node = next((nid for nid, path in _SECTION.findall(prompt) if "inclusion" in path.lower()), None)
        if node:  # tree retrieval: hand over the whole section
            return {"slot_id": slot, "source_node_ids": [node]}
        el = _find(prompt, "list", "inclusion")
        return {"slot_id": slot, "source_element_ids": [el] if el else []}
    if slot == "visit_schedule":
        return {"slot_id": slot, "copy_element_id": _find(prompt, "table", "schedule")}
    return {"slot_id": slot}


def _write(slot: str, prompt: str, retry: bool) -> dict:
    out = _write_raw(slot, prompt, retry)
    memory = prompt.split("MEMORY (", 1)[1].split("FACTS (", 1)[0] if "MEMORY (" in prompt else ""
    if re.search(r"participants", memory, re.I):  # follow a house rule from memory
        out["paragraphs"] = [p.replace("subjects", "participants") for p in out["paragraphs"]]
    return out


def _write_raw(slot: str, prompt: str, retry: bool) -> dict:
    facts = _FACT.findall(prompt)
    if slot == "ae_summary":
        a1 = next((f for f in facts if f[0].startswith("teae_arm1")), None)
        a2 = next((f for f in facts if f[0].startswith("teae_arm2")), None)
        sae = next((f for f in facts if f[0].startswith("sae_any")), None)
        lead = "Treatment-emergent adverse events were reported"
        if not retry:  # typed number -> rejected by the number check
            return {"paragraphs": [f"{lead} in about 30% of subjects."]}
        parts = [f"{lead} in {{{{fact:{a1[0]}}}}} subjects receiving Drug 10 mg and "
                 f"{{{{fact:{a2[0]}}}}} receiving placebo."] if a1 and a2 else [lead + "."]
        if sae:
            parts.append(f"Serious adverse events occurred in {{{{fact:{sae[0]}}}}} subjects overall.")
        return {"paragraphs": [" ".join(parts)]}
    if slot == "study_population":
        f = {fid: (label, disp) for fid, label, disp in facts}
        ids = list(f)
        tot = next((i for i in ids if i.startswith("n_rand_total")), None)
        comp = next((i for i in ids if i.startswith("compl_total")), None)
        a = [i for i in ids if i.startswith("n_rand_arm")]
        c = [i for i in ids if i.startswith("compl_arm")]
        p1 = (f"Of the {{{{fact:{tot}}}}} subjects randomized, {{{{fact:{a[0]}}}}} received Drug 10 mg and "
              f"{{{{fact:{a[1]}}}}} received placebo.") if tot and len(a) == 2 else "Subjects were randomized."
        p2 = (f"Overall, {{{{fact:{comp}}}}} subjects completed the study (Drug 10 mg {{{{fact:{c[0]}}}}}; "
              f"placebo {{{{fact:{c[1]}}}}}).") if comp and len(c) == 2 else ""
        return {"paragraphs": [p for p in (p1, p2) if p]}
    return {"paragraphs": ["Content to be completed."]}


def _summarize(prompt: str) -> dict:
    text = prompt.split("Section text:", 1)[-1]
    words = [w for w in text.split() if w != "(none)"]
    title = prompt.split("\n", 1)[0].removeprefix("Section title: ")
    return {"summary": " ".join(words[:30]) or f"Overview of {title}."}


def _navigate(prompt: str) -> dict:
    """Pick section/table nodes whose titles share words with the slot heading
    and instruction - a stand-in for the model's judgement."""
    from reportkit.llm.retrieval import tokens  # noqa: PLC0415

    head = prompt.split("DOCUMENT OUTLINE", 1)[0]
    want = {t for t in tokens(head) if t not in _DEMO_STOP and not t.isdigit()}
    picks = [nid for nid, kind, title in _NODE.findall(prompt)
             if kind != "document" and want & set(tokens(title))]
    return {"reasoning": f"titles matching {sorted(want)[:6]}" if picks else "computed from datasets only",
            "select": picks, "expand": []}


def _compact(prompt: str) -> dict:
    new = prompt.split("NEW EVENTS", 1)[-1]
    events = _EVENT.findall(new)
    user_msgs = [(int(i), c) for i, role, kind, c in events if role == "user"]
    return {"goals": [user_msgs[0][1][:200]] if user_msgs else [],
            "decisions": [{"text": c[:200], "event_ids": [i]} for i, c in user_msgs if "instead" in c or "always" in c],
            "constraints": [], "open_items": [],
            "summary": f"Session with {len(events)} new events."}


def _consolidate(prompt: str) -> dict:
    events = _EVENT.findall(prompt.split("EXISTING MEMORIES", 1)[0])
    scopes = prompt.rsplit("Available scopes:", 1)[-1]
    scope = "project" if "project" in scopes else "user"
    items = [{"kind": "style_rule", "scope_type": scope, "content": " ".join(c.split())[:300],
              "event_ids": [int(i)], "confidence": 0.9}
             for i, role, kind, c in events if role == "user" and kind == "feedback"
             and re.search(r"\b(instead of|always|never|prefer)\b", c, re.I)]
    return {"items": items}


def demo_responder(purpose: str, messages: list[dict]) -> dict:
    kind, _, slot = purpose.partition(":")
    prompt = messages[1]["content"]
    retry = messages[-1]["content"].startswith("Your answer was rejected")
    if kind == "summarize":
        return _summarize(prompt)
    if kind == "navigate":
        return _navigate(prompt)
    if kind == "compact":
        return _compact(prompt)
    if kind == "consolidate":
        return _consolidate(prompt)
    return _plan(slot, prompt, retry) if kind == "plan" else _write(slot, prompt, retry)


def demo_llm() -> ScriptedLLM:
    return ScriptedLLM(demo_responder)
