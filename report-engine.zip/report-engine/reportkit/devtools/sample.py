"""Sample inputs for local runs and tests.

    python -m reportkit.devtools.sample ./sample

writes template.docx (with rk: content controls), example_report.docx,
protocol_synopsis.docx, adsl.csv and adae.csv.
"""

from __future__ import annotations

import csv
import random
import sys
from pathlib import Path

import docx
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

ARMS = ["Drug 10 mg", "Placebo"]
TERMS = ["Headache", "Eye irritation", "Nausea", "Blurred vision", "Dry eye"]


def _block_sdt(doc, tag: str, instruction: str) -> None:
    p = doc.add_paragraph()
    sdt = parse_xml(
        f'<w:sdt {nsdecls("w")}><w:sdtPr><w:tag w:val="{tag}"/><w:showingPlcHdr/></w:sdtPr>'
        f'<w:sdtContent><w:p><w:r><w:t xml:space="preserve">{instruction}</w:t></w:r></w:p></w:sdtContent></w:sdt>')
    p._p.addnext(sdt)
    p._p.getparent().remove(p._p)


def _inline_sdt_paragraph(doc, before: str, tag: str, placeholder: str, after: str) -> None:
    p = doc.add_paragraph(before)
    p._p.append(parse_xml(
        f'<w:sdt {nsdecls("w")}><w:sdtPr><w:tag w:val="{tag}"/></w:sdtPr>'
        f'<w:sdtContent><w:r><w:t xml:space="preserve">{placeholder}</w:t></w:r></w:sdtContent></w:sdt>'))
    p.add_run(after)


def make_template(path: Path) -> None:
    doc = docx.Document()
    doc.add_heading("Clinical Study Report - Synopsis", level=0)
    doc.add_heading("1 Study Population", level=1)
    _inline_sdt_paragraph(doc, "A total of ", "rk:fact:n_randomized", "[number randomized]",
                          " subjects were randomized.")
    _block_sdt(doc, "rk:narrative:study_population",
               "Summarise subject disposition: subjects randomized per treatment arm and the proportion who "
               "completed the study, overall and by arm.")
    doc.add_heading("2 Demographics", level=1)
    _block_sdt(doc, "rk:table:demographics",
               "Demographics table by treatment arm with a total column: age mean (SD), age median, "
               "sex n (%), race n (%). Column headers show N per arm.")
    _block_sdt(doc, "rk:figure:age_by_arm", "Box plot of age by treatment arm.")
    doc.add_heading("3 Adverse Events", level=1)
    _block_sdt(doc, "rk:table:ae_by_term",
               "Subjects with treatment-emergent adverse events by preferred term and arm, n (%), "
               "percentages based on the safety population per arm, most frequent first.")
    _block_sdt(doc, "rk:narrative:ae_summary",
               "Summarise the adverse event profile: proportion of subjects with any TEAE per arm and any "
               "serious AE.")
    doc.add_heading("4 Inclusion Criteria", level=1)
    _block_sdt(doc, "rk:verbatim:inclusion_criteria", "Copy the inclusion criteria from the protocol synopsis.")
    doc.add_heading("5 Schedule of Assessments", level=1)
    _block_sdt(doc, "rk:table:visit_schedule", "Reproduce the visit schedule table from the protocol synopsis.")
    doc.save(str(path))


def make_example_report(path: Path) -> None:
    doc = docx.Document()
    doc.add_heading("Clinical Study Report - Synopsis (study ABC-17)", level=0)
    doc.add_heading("1 Study Population", level=1)
    doc.add_paragraph("Of the 312 subjects randomized, 156 were assigned to active treatment and 156 to "
                      "vehicle. Overall, 89.1% of subjects completed the study (active 90.4%, vehicle 87.8%).")
    doc.add_heading("3 Adverse Events", level=1)
    doc.add_paragraph("Treatment-emergent adverse events were reported in 34.6% of subjects in the active "
                      "group and 28.2% in the vehicle group. Serious adverse events were rare (1.3%).")
    doc.save(str(path))


def make_protocol(path: Path) -> None:
    doc = docx.Document()
    doc.add_heading("Protocol Synopsis - Study RK-001", level=0)
    doc.add_heading("Study Design", level=1)
    doc.add_paragraph("Randomized, double-masked, placebo-controlled study of Drug 10 mg in adults with "
                      "dry eye disease over 12 weeks.")
    doc.add_heading("Inclusion Criteria", level=1)
    for item in ["Age 18 years or older", "Diagnosis of dry eye disease for at least 6 months",
                 "Willing to discontinue artificial tears during the study"]:
        doc.add_paragraph(item, style="List Number")
    doc.add_heading("Schedule of Assessments", level=1)
    t = doc.add_table(rows=4, cols=3)
    for r, row in enumerate([["Visit", "Week", "Assessments"], ["Screening", "-2", "Eligibility, slit lamp"],
                             ["Baseline", "0", "Randomization, Schirmer test"],
                             ["End of study", "12", "Schirmer test, safety"]]):
        for ci, v in enumerate(row):
            t.cell(r, ci).text = v
    doc.save(str(path))


def make_data(adsl: Path, adae: Path, n: int = 240, seed: int = 7) -> None:
    rnd = random.Random(seed)
    subjects = []
    with adsl.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["USUBJID", "TRT01A", "AGE", "SEX", "RACE", "COMPLFL", "SAFFL"])
        for i in range(n):
            arm = ARMS[i % 2]
            row = [f"RK001-{i + 1:04d}", arm, rnd.randint(19, 84), rnd.choice(["F", "F", "M"]),
                   rnd.choice(["White", "White", "Asian", "Black or African American"]),
                   "Y" if rnd.random() < (0.9 if arm == ARMS[0] else 0.86) else "N", "Y"]
            subjects.append(row)
            w.writerow(row)
    with adae.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["USUBJID", "TRTA", "AEDECOD", "AESEV", "AESER", "TRTEMFL"])
        for s in subjects:
            p = 0.35 if s[1] == ARMS[0] else 0.25
            for _ in range(rnd.choice([0, 0, 1, 1, 2])):
                if rnd.random() < p * 2:
                    w.writerow([s[0], s[1], rnd.choice(TERMS), rnd.choice(["MILD", "MILD", "MODERATE", "SEVERE"]),
                                "Y" if rnd.random() < 0.03 else "N", "Y"])


def make_all(out: Path) -> dict[str, Path]:
    out.mkdir(parents=True, exist_ok=True)
    paths = {k: out / v for k, v in {"template": "template.docx", "example": "example_report.docx",
                                     "protocol": "protocol_synopsis.docx", "adsl": "adsl.csv",
                                     "adae": "adae.csv"}.items()}
    make_template(paths["template"])
    make_example_report(paths["example"])
    make_protocol(paths["protocol"])
    make_data(paths["adsl"], paths["adae"])
    return paths


if __name__ == "__main__":
    for k, p in make_all(Path(sys.argv[1] if len(sys.argv) > 1 else "sample")).items():
        print(f"{k:9s} {p}")
