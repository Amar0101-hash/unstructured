"""Parser contract plus a reference implementation.

Plug in your own parsing engine by implementing ``DocumentParser``: return
inventory elements, and for every table element hand back its header and
rows so ``reportkit.ingest.tabular`` can turn it into a Parquet dataset.

The reference ``BasicParser`` covers DOCX (headings, paragraphs, lists,
tables, images), XLSX (one table per sheet, streamed), CSV (straight to
DuckDB) and PDF (text per page plus pdfplumber tables). It is deliberately
simple - swap it for your robust engine.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Iterator, Protocol

from reportkit.models.inventory import (
    FigurePayload,
    InventoryElement,
    Provenance,
    TablePayload,
    content_hash,
    element_id,
)


@dataclass
class ParsedTable:
    element_id: str
    headers: list[str]
    rows: Iterable[list[object]]
    name_hint: str


@dataclass
class ParsedFigure:
    element_id: str
    data: bytes
    mime: str


@dataclass
class ParsedFile:
    elements: list[InventoryElement]
    tables: list[ParsedTable] = field(default_factory=list)
    figures: list[ParsedFigure] = field(default_factory=list)
    csv_path: Path | None = None  # CSV uploads go straight to DuckDB


class DocumentParser(Protocol):
    version: str

    def parse(self, path: Path, filename: str, file_id: str) -> ParsedFile: ...


_HEADING_STYLE = re.compile(r"^(heading|titre|überschrift)\s*(\d)", re.I)


class _Builder:
    def __init__(self, file_id: str, filename: str):
        self.file_id, self.filename = file_id, filename
        self.elements: list[InventoryElement] = []
        self.path: list[str] = []

    def add(self, type_: str, *, text: str | None = None, level: int | None = None,
            items: list[str] | None = None, page: int | None = None, sheet: str | None = None,
            **extra) -> InventoryElement:
        order = len(self.elements)
        if type_ == "heading" and level:
            self.path = self.path[: level - 1] + [text or ""]
        el = InventoryElement(
            id=element_id(self.file_id, order), file_id=self.file_id, type=type_, order=order, text=text,
            level=level, items=items,
            provenance=Provenance(file_id=self.file_id, filename=self.filename, page=page, sheet=sheet,
                                  heading_path=list(self.path)),
            content_hash=content_hash(type_, text, *(items or [])), **extra)
        self.elements.append(el)
        return el


class BasicParser:
    version = "basic-1"

    def parse(self, path: Path, filename: str, file_id: str) -> ParsedFile:
        ext = Path(filename).suffix.lower()
        if ext == ".docx":
            return self._docx(path, filename, file_id)
        if ext in (".xlsx", ".xlsm"):
            return self._xlsx(path, filename, file_id)
        if ext == ".csv":
            return self._csv(path, filename, file_id)
        if ext == ".pdf":
            return self._pdf(path, filename, file_id)
        raise ValueError(f"unsupported file type: {ext}")

    # ---- DOCX -------------------------------------------------------------
    def _docx(self, path: Path, filename: str, file_id: str) -> ParsedFile:
        import docx  # noqa: PLC0415
        from docx.table import Table  # noqa: PLC0415
        from docx.text.paragraph import Paragraph  # noqa: PLC0415

        doc = docx.Document(str(path))
        b = _Builder(file_id, filename)
        out = ParsedFile(elements=b.elements)
        stem = Path(filename).stem
        pending_list: list[str] = []

        def flush_list() -> None:
            if pending_list:
                b.add("list", items=list(pending_list))
                pending_list.clear()

        for child in doc.element.body.iterchildren():
            tag = child.tag.rsplit("}", 1)[-1]
            if tag == "p":
                p = Paragraph(child, doc)
                text = p.text.strip()
                style = (p.style.name if p.style is not None else "") or ""
                blips = child.findall(".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip")
                for blip in blips:
                    rid = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                    part = doc.part.related_parts.get(rid) if rid else None
                    if part is not None:
                        flush_list()
                        el = b.add("figure", text=text or None,
                                   figure=FigurePayload(blob_uri="", mime=part.content_type, caption=text or None))
                        out.figures.append(ParsedFigure(el.id, part.blob, part.content_type))
                if not text:
                    continue
                m = _HEADING_STYLE.match(style)
                if m or style.lower() == "title":
                    flush_list()
                    b.add("heading", text=text, level=int(m.group(2)) if m else 1)
                elif "list" in style.lower() or child.find(
                        ".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}numPr") is not None:
                    pending_list.append(text)
                elif style.lower().startswith("caption"):
                    flush_list()
                    b.add("caption", text=text)
                else:
                    flush_list()
                    b.add("paragraph", text=text)
            elif tag == "tbl":
                flush_list()
                t = Table(child, doc)
                grid = [[c.text.strip() for c in row.cells] for row in t.rows]
                grid = [r for r in grid if any(r)]
                if not grid:
                    continue
                headers, rows = grid[0], grid[1:]
                idx = sum(1 for e in b.elements if e.type == "table")
                el = b.add("table", text=None, table=TablePayload(columns=headers, n_rows=len(rows)))
                out.tables.append(ParsedTable(el.id, headers, rows, f"{stem}_t{idx + 1}"))
        flush_list()
        return out

    # ---- XLSX -------------------------------------------------------------
    def _xlsx(self, path: Path, filename: str, file_id: str) -> ParsedFile:
        import openpyxl  # noqa: PLC0415


        b = _Builder(file_id, filename)
        out = ParsedFile(elements=b.elements)
        stem = Path(filename).stem
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
        sheets = wb.sheetnames
        for name in sheets:
            ws = wb[name]
            it = ws.iter_rows(values_only=True)
            header: list[str] | None = None
            for row in it:  # first non-empty row is the header
                if row and any(v not in (None, "") for v in row):
                    header = [str(v) if v is not None else "" for v in row]
                    break
            if header is None:
                continue
            while header and header[-1] == "":
                header.pop()
            width = len(header)

            def rows(it=it, width=width) -> Iterator[list[object]]:
                for r in it:
                    vals = list(r[:width])
                    if any(v not in (None, "") for v in vals):
                        yield vals

            b.add("heading", text=name, level=1, sheet=name)
            el = b.add("table", sheet=name, table=TablePayload(columns=header, n_rows=-1))
            hint = stem if len(sheets) == 1 else f"{stem}_{name}"
            out.tables.append(ParsedTable(el.id, header, rows(), hint))
        return out

    # ---- CSV --------------------------------------------------------------
    def _csv(self, path: Path, filename: str, file_id: str) -> ParsedFile:

        import csv  # noqa: PLC0415

        b = _Builder(file_id, filename)

        with path.open(newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        b.add("table", table=TablePayload(columns=header, n_rows=-1))
        return ParsedFile(elements=b.elements, csv_path=path)

    # ---- PDF --------------------------------------------------------------
    def _pdf(self, path: Path, filename: str, file_id: str) -> ParsedFile:
        import pdfplumber  # noqa: PLC0415


        b = _Builder(file_id, filename)
        out = ParsedFile(elements=b.elements)
        stem = Path(filename).stem
        with pdfplumber.open(str(path)) as pdf:
            for pno, page in enumerate(pdf.pages, start=1):
                tables = page.find_tables()
                bboxes = [t.bbox for t in tables]

                def outside(obj, bboxes=bboxes) -> bool:
                    x0, top = obj.get("x0", 0), obj.get("top", 0)
                    return not any(bx0 <= x0 <= bx1 and btop <= top <= bbot for bx0, btop, bx1, bbot in bboxes)

                text = page.filter(outside).extract_text() or ""
                for block in re.split(r"\n\s*\n", text):
                    block = " ".join(block.split())
                    if block:
                        b.add("paragraph", text=block, page=pno)
                for t in tables:
                    grid = [[(c or "").strip() for c in row] for row in t.extract()]
                    grid = [r for r in grid if any(r)]
                    if len(grid) < 2:
                        continue
                    idx = sum(1 for e in b.elements if e.type == "table")
                    el = b.add("table", page=pno, table=TablePayload(columns=grid[0], n_rows=len(grid) - 1),
                               )
                    el.provenance.bbox = tuple(t.bbox)  # type: ignore[assignment]
                    out.tables.append(ParsedTable(el.id, grid[0], grid[1:], f"{stem}_p{pno}_t{idx + 1}"))
        return out

