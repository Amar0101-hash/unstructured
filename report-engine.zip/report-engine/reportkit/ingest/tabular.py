"""Tables from any source -> typed Parquet datasets.

Rows are streamed to a CSV in scratch and DuckDB does the type sniffing and
the Parquet conversion, so a 2 GB spreadsheet never has to fit in memory and
every source gets the same typing rules. The original cell strings are kept
as a raw CSV for verbatim copies into the report.
"""

from __future__ import annotations

import csv
import hashlib
import re
import uuid
from pathlib import Path
from typing import Iterable

from reportkit.compute.duck import describe, new_connection, sql_str
from reportkit.models.catalog import Dataset, FileSource
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore

_SNAKE = re.compile(r"[^a-z0-9]+")


def sanitize_identifiers(headers: list[str]) -> list[str]:
    out: list[str] = []
    seen: dict[str, int] = {}
    for i, h in enumerate(headers):
        base = _SNAKE.sub("_", str(h or "").strip().lower()).strip("_") or f"col_{i + 1}"
        if base[0].isdigit():
            base = f"c_{base}"
        base = base[:60]
        name = base
        if name in seen:
            seen[base] += 1
            name = f"{base}_{seen[base]}"
        seen.setdefault(name, 1)
        out.append(name)
    return out


def dataset_name(stem: str, index: int | None = None) -> str:
    base = _SNAKE.sub("_", stem.lower()).strip("_") or "table"
    if base[0].isdigit():
        base = f"t_{base}"
    base = base[:48]
    return f"{base}_t{index}" if index is not None else base


def _cell(v: object) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def table_to_dataset(*, settings: Settings, blob: BlobStore, file_id: str, element_id: str | None,
                     base_name: str, headers: list[str], rows: Iterable[list[object]],
                     description: str | None = None) -> tuple[Dataset, str]:
    """Returns the dataset (Parquet) and the URI of the raw CSV copy."""
    names = sanitize_identifiers(headers)
    labels = dict(zip(names, [str(h) for h in headers]))
    work = settings.scratch_subdir("ingest")
    tmp = work / f"{uuid.uuid4().hex}.csv"
    pq_path = work / f"{uuid.uuid4().hex}.parquet"
    try:
        with tmp.open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(names)
            for r in rows:
                vals = [_cell(v) for v in r][: len(names)]
                vals += [""] * (len(names) - len(vals))
                w.writerow(vals)
        raw_uri = blob.put_path(f"files/{file_id}/tables/{base_name}.raw.csv", tmp, "text/csv")
        return _csv_to_dataset(settings, blob, tmp, pq_path, file_id, element_id, base_name, labels,
                               description), raw_uri
    finally:
        tmp.unlink(missing_ok=True)
        pq_path.unlink(missing_ok=True)


def csv_file_to_dataset(*, settings: Settings, blob: BlobStore, local_csv: Path, file_id: str,
                        element_id: str | None, base_name: str) -> Dataset:
    """A CSV upload: DuckDB reads it directly, then we rename columns to safe identifiers."""
    work = settings.scratch_subdir("ingest")
    pq_path = work / f"{uuid.uuid4().hex}.parquet"
    try:
        return _csv_to_dataset(settings, blob, local_csv, pq_path, file_id, element_id, base_name,
                               None, None, rename=True)
    finally:
        pq_path.unlink(missing_ok=True)


def _csv_to_dataset(settings: Settings, blob: BlobStore, csv_path: Path, pq_path: Path, file_id: str,
                    element_id: str | None, base_name: str, labels: dict[str, str] | None,
                    description: str | None, rename: bool = False) -> Dataset:
    con = new_connection(settings)
    try:
        src = f"read_csv({sql_str(str(csv_path))}, header=true, sample_size=-1, all_varchar=false)"
        if rename:
            cols = [r[0] for r in con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()]
            safe = sanitize_identifiers(cols)
            labels = dict(zip(safe, cols))
            proj = ", ".join(f'"{c.replace(chr(34), chr(34) * 2)}" AS "{s}"' for c, s in zip(cols, safe))
            src = f"(SELECT {proj} FROM {src})"
        con.execute(f"COPY (SELECT * FROM {src}) TO {sql_str(str(pq_path))} (FORMAT parquet, COMPRESSION zstd)")
        rel = f"read_parquet({sql_str(str(pq_path))})"
        columns, n = describe(con, rel, labels=labels, sample_values=settings.catalog_sample_values,
                              max_cardinality=settings.catalog_sample_max_cardinality)
    finally:
        con.close()
    data = pq_path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    uri = blob.put_bytes(f"files/{file_id}/tables/{base_name}.parquet", data, "application/vnd.apache.parquet")
    ds_id = "ds_" + hashlib.sha256(f"{file_id}:{base_name}:{sha}".encode()).hexdigest()[:24]
    return Dataset(id=ds_id, base_name=base_name, description=description,
                   source=FileSource(uri=uri, format="parquet"), columns=columns, row_count=n,
                   fingerprint=sha, origin_file_id=file_id, origin_element_id=element_id)
