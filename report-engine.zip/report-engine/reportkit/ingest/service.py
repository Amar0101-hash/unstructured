"""Parse a stored file into inventory + datasets, once per (file, parser version).

Files are keyed by content hash, so re-uploading the same bytes reuses the
existing inventory and datasets across jobs.
"""

from __future__ import annotations

import logging
import shutil
import uuid
from pathlib import Path

from reportkit.ingest.parser import DocumentParser
from reportkit.ingest.tabular import csv_file_to_dataset, dataset_name, table_to_dataset
from reportkit.models.catalog import Dataset
from reportkit.models.inventory import InventoryElement
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore, sha256_bytes
from reportkit.storage.repository import Repository

log = logging.getLogger(__name__)


class IngestService:
    def __init__(self, settings: Settings, repo: Repository, blob: BlobStore, parser: DocumentParser):
        self.settings, self.repo, self.blob, self.parser = settings, repo, blob, parser

    def _local_copy(self, uri: str, filename: str) -> tuple[Path, bool]:
        local = self.blob.local_path(uri)
        if local is not None:
            return local, False
        tmp = self.settings.scratch_subdir("ingest") / f"{uuid.uuid4().hex}{Path(filename).suffix}"
        tmp.write_bytes(self.blob.get_bytes(uri))  # inputs are documents; big data goes via connectors
        return tmp, True

    def ensure_parsed(self, file_id: str) -> tuple[list[InventoryElement], list[Dataset]]:
        row = self.repo.get_file(file_id)
        if row is None:
            raise KeyError(f"unknown file {file_id}")
        if row.parsed_at and row.parser_version == self.parser.version:
            return self.repo.inventory(file_id), self.repo.datasets_for_file(file_id)

        path, is_temp = self._local_copy(row.uri, row.filename)
        try:
            parsed = self.parser.parse(path, row.filename, file_id)
            datasets: list[Dataset] = []
            by_id = {e.id: e for e in parsed.elements}

            for fig in parsed.figures:
                ext = fig.mime.split("/")[-1].replace("jpeg", "jpg")
                uri = self.blob.put_bytes(f"files/{file_id}/figures/{fig.element_id}.{ext}", fig.data, fig.mime)
                el = by_id[fig.element_id]
                if el.figure:
                    el.figure.blob_uri = uri
                el.content_hash = sha256_bytes(fig.data)

            for t in parsed.tables:
                ds, raw_uri = table_to_dataset(
                    settings=self.settings, blob=self.blob, file_id=file_id, element_id=t.element_id,
                    base_name=dataset_name(t.name_hint), headers=t.headers, rows=t.rows,
                    description=f"table from {row.filename}")
                el = by_id[t.element_id]
                if el.table:
                    el.table.dataset_id, el.table.raw_uri, el.table.n_rows = ds.id, raw_uri, ds.row_count or 0
                datasets.append(ds)

            if parsed.csv_path is not None:
                el = next(e for e in parsed.elements if e.type == "table")
                ds = csv_file_to_dataset(settings=self.settings, blob=self.blob, local_csv=parsed.csv_path,
                                         file_id=file_id, element_id=el.id,
                                         base_name=dataset_name(Path(row.filename).stem))
                ds.description = f"uploaded CSV {row.filename}"
                if el.table:
                    el.table.dataset_id, el.table.n_rows = ds.id, ds.row_count or 0
                    el.table.raw_uri = row.uri
                datasets.append(ds)

            self.repo.replace_inventory(file_id, parsed.elements)
            for ds in datasets:
                self.repo.upsert_dataset(ds)
            self.repo.mark_parsed(file_id, self.parser.version)
            log.info("parsed %s: %d elements, %d datasets", row.filename, len(parsed.elements), len(datasets))
            return parsed.elements, datasets
        finally:
            if is_temp:
                path.unlink(missing_ok=True)
            shutil.rmtree(self.settings.scratch_subdir("ingest") / file_id, ignore_errors=True)
