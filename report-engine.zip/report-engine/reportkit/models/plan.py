"""Report plan: the template compiled into typed slots."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

SlotType = Literal["narrative", "table", "figure", "fact", "verbatim"]


class Slot(BaseModel):
    id: str
    type: SlotType
    instruction: str  # placeholder text inside the content control
    heading: str | None = None  # nearest heading above the slot in the template
    heading_path: list[str] = Field(default_factory=list)
    inline: bool = False  # run-level content control (inside a paragraph)
    style_example: str | None = None  # matching section of the example report
    order: int = 0


class ReportPlan(BaseModel):
    template_file_id: str
    slots: list[Slot]

    def slot(self, slot_id: str) -> Slot:
        return next(s for s in self.slots if s.id == slot_id)
