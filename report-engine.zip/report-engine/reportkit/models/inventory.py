"""Document inventory: the canonical output of parsing.

Every parser (the reference one here, or your own engine) must emit these
models. Everything downstream - catalog, planner, writer, renderer - only
reads the inventory, never the raw file.
"""

from __future__ import annotations

import hashlib
from typing import Literal

from pydantic import BaseModel, Field

ElementType = Literal["heading", "paragraph", "list", "table", "figure", "caption"]


class Provenance(BaseModel):
    file_id: str
    filename: str
    page: int | None = None
    sheet: str | None = None
    cell_range: str | None = None
    bbox: tuple[float, float, float, float] | None = None
    heading_path: list[str] = Field(default_factory=list)


class TablePayload(BaseModel):
    columns: list[str]  # original header labels
    n_rows: int
    dataset_id: str | None = None  # the Parquet dataset built from this table
    raw_uri: str | None = None  # original cell strings as CSV, for verbatim copies


class FigurePayload(BaseModel):
    blob_uri: str
    mime: str = "image/png"
    caption: str | None = None


class InventoryElement(BaseModel):
    id: str
    file_id: str
    type: ElementType
    order: int
    text: str | None = None
    level: int | None = None  # heading level
    items: list[str] | None = None  # list items
    table: TablePayload | None = None
    figure: FigurePayload | None = None
    provenance: Provenance
    content_hash: str = ""

    def preview(self, n: int = 160) -> str:
        if self.type == "table" and self.table:
            cols = ", ".join(self.table.columns[:12])
            return f"[table {self.table.n_rows} rows] columns: {cols}"
        if self.type == "figure":
            return f"[figure] {(self.figure.caption if self.figure else '') or ''}"[:n]
        if self.type == "list" and self.items:
            return ("; ".join(self.items))[:n]
        return (self.text or "")[:n]

    def full_text(self) -> str:
        if self.type == "list" and self.items:
            return "\n".join(f"- {i}" for i in self.items)
        if self.type == "figure" and self.figure:
            return self.figure.caption or ""
        if self.type == "table" and self.table:
            return " | ".join(self.table.columns)
        return self.text or ""


def element_id(file_id: str, order: int) -> str:
    """Deterministic: same file bytes always yield the same element ids."""
    return f"el_{hashlib.sha256(f'{file_id}:{order}'.encode()).hexdigest()[:16]}"


def content_hash(*parts: str | None) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update((p or "").encode())
        h.update(b"\x00")
    return h.hexdigest()
