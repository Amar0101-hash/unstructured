"""Declarative compute specs.

The LLM planner fills these through structured output. They are compiled to
SQL by our own code (reportkit.compute.compiler), so the LLM never writes SQL
for the common cases and never produces a number.
"""

from __future__ import annotations

from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, Field, model_validator

ID_PATTERN = r"^[a-z][a-z0-9_]{0,39}$"

Op = Literal["=", "!=", "<", "<=", ">", ">=", "in", "not_in", "is_null", "not_null", "between", "like"]
Scalar = Union[str, int, float, bool]


class Filter(BaseModel):
    col: str
    op: Op
    value: Scalar | list[Scalar] | None = None

    @model_validator(mode="after")
    def _check_value(self) -> "Filter":
        if self.op in ("is_null", "not_null"):
            self.value = None
        elif self.op in ("in", "not_in"):
            if not isinstance(self.value, list) or not self.value:
                raise ValueError(f"op {self.op} needs a non-empty list value")
        elif self.op == "between":
            if not isinstance(self.value, list) or len(self.value) != 2:
                raise ValueError("op between needs [low, high]")
        elif self.value is None or isinstance(self.value, list):
            raise ValueError(f"op {self.op} needs a single value")
        return self


MetricName = Literal[
    "count",  # rows, or distinct `distinct_on`
    "count_distinct",  # distinct values of `column`
    "sum",
    "mean",
    "median",
    "min",
    "max",
    "std",  # sample standard deviation
    "pct",  # % of denominator rows/subjects matching `numerator`
    "n_pct",  # n (%) - CSR style
    "mean_sd",  # mean (SD) - CSR style
]

NEEDS_COLUMN = {"count_distinct", "sum", "mean", "median", "min", "max", "std", "mean_sd"}
PCT_METRICS = {"pct", "n_pct"}


class FactFormat(BaseModel):
    decimals: int = Field(1, ge=0, le=6)
    unit: str | None = None
    thousands: bool = True


class Denominator(BaseModel):
    """Where a percentage's denominator comes from. Defaults to the same dataset
    and population filters. For AE tables use the subject-level dataset (ADSL)."""

    dataset: str
    filters: list[Filter] = Field(default_factory=list)
    distinct_on: str | None = None
    col_by: str | None = None  # column-group column in this dataset if named differently (TRT01A vs TRTA)


class MetricSpec(BaseModel):
    kind: Literal["metric"] = "metric"
    fact_id: Annotated[str, Field(pattern=ID_PATTERN)]
    label: str
    dataset: str
    metric: MetricName
    column: str | None = None
    distinct_on: str | None = None  # e.g. subject id, so events are counted per subject
    filters: list[Filter] = Field(default_factory=list)  # population
    numerator: list[Filter] = Field(default_factory=list)  # for pct / n_pct
    denominator: Denominator | None = None
    format: FactFormat = Field(default_factory=FactFormat)

    @model_validator(mode="after")
    def _check(self) -> "MetricSpec":
        if self.metric in NEEDS_COLUMN and not self.column:
            raise ValueError(f"metric {self.metric} needs `column`")
        if self.metric in PCT_METRICS and not self.numerator:
            raise ValueError(f"metric {self.metric} needs `numerator` filters")
        return self


class RowSpec(BaseModel):
    """One logical row of a summary table. With `row_by`, it expands into one
    row per distinct value (e.g. one row per AE preferred term)."""

    label: str
    metric: MetricName
    column: str | None = None
    distinct_on: str | None = None
    row_by: str | None = None
    filters: list[Filter] = Field(default_factory=list)
    numerator: list[Filter] = Field(default_factory=list)
    denominator: Denominator | None = None
    format: FactFormat = Field(default_factory=FactFormat)

    @model_validator(mode="after")
    def _check(self) -> "RowSpec":
        if self.metric in NEEDS_COLUMN and not self.column:
            raise ValueError(f"metric {self.metric} needs `column`")
        if self.metric in PCT_METRICS and not self.numerator and not self.row_by:
            raise ValueError(f"metric {self.metric} needs `numerator` or `row_by`")
        return self


class TableSpec(BaseModel):
    kind: Literal["table"] = "table"
    table_id: Annotated[str, Field(pattern=ID_PATTERN)]
    title: str
    dataset: str
    filters: list[Filter] = Field(default_factory=list)
    col_by: str | None = None  # e.g. treatment arm
    col_order: list[str] | None = None  # explicit column order; default sorted
    header_n: Denominator | None = None  # adds "(N=xx)" to each column header
    include_total: bool = False
    stub_header: str = ""
    rows: list[RowSpec] = Field(min_length=1)
    sort_expanded: Literal["label", "count_desc"] = "label"
    footnote: str | None = None


class SqlSpec(BaseModel):
    """Fallback when the declarative specs can't express it. Validated by
    reportkit.compute.sql_guard before it runs."""

    kind: Literal["sql"] = "sql"
    output_id: Annotated[str, Field(pattern=ID_PATTERN)]
    title: str
    datasets: list[str] = Field(min_length=1)
    sql: str
    output: Literal["table", "fact"] = "table"
    format: FactFormat = Field(default_factory=FactFormat)


ChartType = Literal["bar", "line", "scatter", "box", "hist"]
ChartAgg = Literal["count", "sum", "mean", "median"]


class ChartData(BaseModel):
    dataset: str
    filters: list[Filter] = Field(default_factory=list)
    x: str
    y: str | None = None
    group: str | None = None
    agg: ChartAgg | None = None  # bar/line: aggregate y per x (and group)
    distinct_on: str | None = None  # agg=count of distinct subjects


class ChartSpec(BaseModel):
    kind: Literal["chart"] = "chart"
    figure_id: Annotated[str, Field(pattern=ID_PATTERN)]
    title: str
    chart: ChartType
    data: ChartData
    x_label: str | None = None
    y_label: str | None = None
    caption: str | None = None

    @model_validator(mode="after")
    def _check(self) -> "ChartSpec":
        d = self.data
        if self.chart in ("bar", "line"):
            if d.agg is None and d.y is None:
                raise ValueError("bar/line charts need `y` or `agg`")
            if d.agg in ("sum", "mean", "median") and not d.y:
                raise ValueError(f"agg {d.agg} needs `y`")
        if self.chart in ("scatter", "box") and not d.y:
            raise ValueError(f"{self.chart} charts need `y`")
        return self


TableLike = Annotated[Union[TableSpec, SqlSpec], Field(discriminator="kind")]


class SlotBinding(BaseModel):
    """The planner's decision for one template slot."""

    slot_id: str
    facts: list[MetricSpec] = Field(default_factory=list)
    table: TableLike | None = None
    figure: ChartSpec | None = None
    copy_element_id: str | None = None  # reuse a table/figure from the inputs verbatim
    source_element_ids: list[str] = Field(default_factory=list)  # context for the writer
    source_node_ids: list[str] = Field(default_factory=list)  # whole document sections for the writer
    notes: str | None = None

    def spec_ids(self) -> list[str]:
        ids = [f.fact_id for f in self.facts]
        if self.table is not None:
            ids.append(self.table.table_id if isinstance(self.table, TableSpec) else self.table.output_id)
        if self.figure is not None:
            ids.append(self.figure.figure_id)
        return ids


def spec_payload(spec: BaseModel) -> dict[str, Any]:
    return spec.model_dump(mode="json")
