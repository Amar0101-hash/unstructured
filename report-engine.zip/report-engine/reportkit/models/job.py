from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    queued = "queued"
    running = "running"
    succeeded = "succeeded"
    succeeded_with_issues = "succeeded_with_issues"
    failed = "failed"

    @property
    def terminal(self) -> bool:
        return self in (JobStatus.succeeded, JobStatus.succeeded_with_issues, JobStatus.failed)


class JobRequest(BaseModel):
    template_file_id: str
    input_file_ids: list[str] = Field(default_factory=list)
    example_file_ids: list[str] = Field(default_factory=list)
    dataset_ids: list[str] = Field(default_factory=list)  # registered external datasets
    instructions: str | None = None  # global guidance for planner and writer
    title: str | None = None
    session_id: str | None = None  # working memory + feedback for this job
    project_id: str | None = None  # scope for project memories and episodes
    template_key: str | None = None  # stable name for the template; default: its content hash


class JobResult(BaseModel):
    docx_artifact_id: str | None = None
    manifest_artifact_id: str | None = None
    n_slots: int = 0
    n_facts: int = 0
    n_errors: int = 0
    n_warnings: int = 0
