"""Outputs of the deterministic compute engine, each with full lineage."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

EngineName = Literal["duckdb", "athena", "rds"]


class DatasetRef(BaseModel):
    name: str
    dataset_id: str
    fingerprint: str | None = None


class Lineage(BaseModel):
    spec_kind: str
    spec_hash: str  # sha256 of the canonical spec JSON
    sql: str
    params: list[Any] = Field(default_factory=list)
    engine: EngineName
    engine_version: str
    datasets: list[DatasetRef]
    result_uri: str  # Parquet snapshot of the exact result rows
    result_sha256: str  # hash of the snapshot file
    result_digest: str  # hash of canonical row values (stable across library versions)
    computed_at: datetime


class Fact(BaseModel):
    id: str
    label: str
    value: float | int | None
    components: dict[str, float | int | None] = Field(default_factory=dict)
    display: str
    unit: str | None = None
    lineage: Lineage


class TableResult(BaseModel):
    id: str
    title: str
    header: list[str]
    rows: list[list[str]]
    footnote: str | None = None
    lineage: list[Lineage] = Field(default_factory=list)
    source_element_id: str | None = None  # set when copied verbatim from an input


class FigureResult(BaseModel):
    id: str
    title: str
    caption: str | None = None
    image_uri: str
    image_sha256: str
    spec: dict[str, Any] | None = None
    lineage: Lineage | None = None
    source_element_id: str | None = None


class ValidationIssue(BaseModel):
    slot_id: str | None = None
    severity: Literal["error", "warning"]
    code: str
    message: str
