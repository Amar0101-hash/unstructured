"""Resolved content blocks handed to the document renderer.

This is the JSON contract between the pipeline and docx assembly. Your
docx_engine can consume it directly (see assembly/docx_engine_adapter.py).
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field


class Run(BaseModel):
    text: str
    fact_id: str | None = None  # set when the run is a computed value


class ParagraphBlock(BaseModel):
    type: Literal["paragraph"] = "paragraph"
    runs: list[Run]

    @property
    def text(self) -> str:
        return "".join(r.text for r in self.runs)


class TableBlock(BaseModel):
    type: Literal["table"] = "table"
    table_id: str
    title: str
    header: list[str]
    rows: list[list[str]]
    footnote: str | None = None


class FigureBlock(BaseModel):
    type: Literal["figure"] = "figure"
    figure_id: str
    title: str
    caption: str | None = None
    image_uri: str
    image_sha256: str


class FlagBlock(BaseModel):
    """Visible marker for a slot that could not be filled. Never silently empty."""

    type: Literal["flag"] = "flag"
    message: str


Block = Annotated[Union[ParagraphBlock, TableBlock, FigureBlock, FlagBlock], Field(discriminator="type")]


class SlotContent(BaseModel):
    slot_id: str
    slot_type: str
    inline: bool = False
    blocks: list[Block] = Field(default_factory=list)
    fact_ids: list[str] = Field(default_factory=list)
    source_element_ids: list[str] = Field(default_factory=list)
