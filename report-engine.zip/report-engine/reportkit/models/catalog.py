"""Dataset catalog: everything tabular the compute engine can query."""

from __future__ import annotations

import re
from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, field_validator

IDENT_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")


class ColumnInfo(BaseModel):
    name: str  # SQL-safe identifier
    type: str  # DuckDB type name
    label: str | None = None  # original header text
    sample_values: list[str] = Field(default_factory=list)


class FileSource(BaseModel):
    """Parquet or CSV in the blob store (uploads, parsed tables) or any s3:// URI."""

    kind: Literal["file"] = "file"
    uri: str
    format: Literal["parquet", "csv"] = "parquet"


class AthenaSource(BaseModel):
    """A Glue table (or a SELECT) queried through Athena.

    pushdown: exact aggregates run in Athena, only the result comes back.
    materialize: the needed columns are UNLOADed to Parquet once, then queried locally.
    """

    kind: Literal["athena"] = "athena"
    database: str
    table: str | None = None
    query: str | None = None
    mode: Literal["pushdown", "materialize"] = "pushdown"


class RdsSource(BaseModel):
    """A Postgres table or query. ``connection`` names an env var RK_RDS_<NAME>_URL
    (inject it from Secrets Manager in the task definition), never raw creds."""

    kind: Literal["rds"] = "rds"
    connection: str
    db_schema: str = "public"
    table: str | None = None
    query: str | None = None
    mode: Literal["pushdown", "materialize"] = "materialize"


Source = Annotated[Union[FileSource, AthenaSource, RdsSource], Field(discriminator="kind")]


class Dataset(BaseModel):
    id: str
    base_name: str  # preferred SQL name; the per-job catalog makes it unique
    description: str | None = None
    source: Source
    columns: list[ColumnInfo] = Field(default_factory=list)
    row_count: int | None = None
    fingerprint: str | None = None  # content hash, ETag or snapshot id - recorded in lineage
    origin_file_id: str | None = None
    origin_element_id: str | None = None

    @field_validator("base_name")
    @classmethod
    def _ident(cls, v: str) -> str:
        if not IDENT_RE.match(v):
            raise ValueError(f"dataset name must match {IDENT_RE.pattern}: {v!r}")
        return v

    def column(self, name: str) -> ColumnInfo | None:
        return next((c for c in self.columns if c.name == name), None)


class CatalogEntry(BaseModel):
    name: str  # unique within the job, used in SQL
    dataset: Dataset


class Catalog(BaseModel):
    entries: dict[str, CatalogEntry] = Field(default_factory=dict)

    def add(self, ds: Dataset) -> str:
        name = ds.base_name
        i = 2
        while name in self.entries:
            name = f"{ds.base_name}_{i}"
            i += 1
        self.entries[name] = CatalogEntry(name=name, dataset=ds)
        return name

    def get(self, name: str) -> Dataset:
        if name not in self.entries:
            raise KeyError(f"unknown dataset {name!r}; known: {sorted(self.entries)}")
        return self.entries[name].dataset

    def names(self) -> set[str]:
        return set(self.entries)

    def describe_for_llm(self) -> str:
        lines = []
        for name, e in sorted(self.entries.items()):
            ds = e.dataset
            head = f"dataset `{name}`"
            if ds.row_count is not None:
                head += f" ({ds.row_count} rows)"
            if ds.description:
                head += f" - {ds.description}"
            lines.append(head)
            for c in ds.columns:
                line = f"  - {c.name}: {c.type}"
                if c.label and c.label != c.name:
                    line += f' (header "{c.label}")'
                if c.sample_values:
                    line += f" values: {', '.join(c.sample_values)}"
                lines.append(line)
        return "\n".join(lines)
