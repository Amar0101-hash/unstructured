"""Turns specs into facts, tables and chart data - deterministically, with lineage.

Every query result is snapshotted to Parquet in the blob store and hashed,
so a reviewer can trace any number in the report back to the exact rows,
SQL, parameters, engine version and dataset fingerprints that produced it.
"""

from __future__ import annotations

import hashlib
import io
import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq

from reportkit.compute.compiler import CompiledQuery, SpecCompiler
from reportkit.compute.formatting import display, fmt_int, fmt_number
from reportkit.compute.session import ComputeSession, QueryResult
from reportkit.models.compute import (
    PCT_METRICS,
    ChartSpec,
    Denominator,
    FactFormat,
    MetricSpec,
    RowSpec,
    SqlSpec,
    TableSpec,
)
from reportkit.models.results import DatasetRef, Fact, Lineage, TableResult
from reportkit.storage.blobstore import BlobStore

COUNT_LIKE = {"count", "count_distinct", "pct", "n_pct"}


def spec_hash(spec: Any) -> str:
    payload = spec.model_dump(mode="json") if hasattr(spec, "model_dump") else spec
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _py(v: Any) -> Any:
    if isinstance(v, Decimal):
        return float(v)
    return v


def _rows(table: pa.Table) -> list[dict[str, Any]]:
    return [{k: _py(v) for k, v in r.items()} for r in table.to_pylist()]


def _components(metric: str, row: dict[str, Any]) -> dict[str, float | int | None]:
    if metric in PCT_METRICS:
        return {"n": row.get("n") or 0, "d": row.get("d"), "pct": row.get("pct")}
    if metric == "mean_sd":
        return {"n": row.get("n"), "mean": row.get("mean"), "sd": row.get("sd")}
    return {"value": row.get("value")}


def _primary(metric: str, comp: dict[str, Any]) -> float | int | None:
    return {"pct": comp.get("pct"), "n_pct": comp.get("n"), "mean_sd": comp.get("mean")}.get(metric, comp.get("value"))


class ComputeEngine:
    def __init__(self, session: ComputeSession, blob: BlobStore, job_id: str):
        self.session = session
        self.compiler = SpecCompiler(session.catalog)
        self.blob = blob
        self.job_id = job_id
        self._snap = 0

    # ---- lineage ----------------------------------------------------------
    def _lineage(self, spec: Any, cq: CompiledQuery, qr: QueryResult) -> Lineage:
        h = spec_hash(spec)
        buf = io.BytesIO()
        pq.write_table(qr.table, buf, compression="zstd")
        data = buf.getvalue()
        self._snap += 1
        key = f"jobs/{self.job_id}/snapshots/{h[:16]}_{self._snap:03d}.parquet"
        uri = self.blob.put_bytes(key, data, "application/vnd.apache.parquet")
        digest = hashlib.sha256(json.dumps(_rows(qr.table), sort_keys=True, default=str).encode()).hexdigest()
        cat = self.session.catalog
        return Lineage(
            spec_kind=getattr(spec, "kind", "unknown"), spec_hash=h, sql=qr.executed_sql,
            params=[_py(p) for p in cq.params], engine=qr.engine, engine_version=qr.engine_version,
            datasets=[DatasetRef(name=n, dataset_id=cat.get(n).id, fingerprint=cat.get(n).fingerprint)
                      for n in cq.datasets],
            result_uri=uri, result_sha256=hashlib.sha256(data).hexdigest(), result_digest=digest,
            computed_at=datetime.now(timezone.utc),
        )

    def _run(self, spec: Any, cq: CompiledQuery, max_rows: int | None = None) -> tuple[list[dict], Lineage]:
        qr = self.session.run(cq, max_rows=max_rows)
        return _rows(qr.table), self._lineage(spec, cq, qr)

    # ---- compile everything up front (for routing/materialisation) ----------
    def compile_all(self, facts: list[MetricSpec], tables: list[TableSpec | SqlSpec],
                    charts: list[ChartSpec]) -> list[CompiledQuery]:
        out = [self.compiler.metric(f) for f in facts]
        for t in tables:
            if isinstance(t, SqlSpec):
                out.append(self.compiler.raw_sql(t))
                continue
            for r in t.rows:
                out.append(self.compiler.table_row(t, r, by_column=bool(t.col_by)))
        out += [self.compiler.chart(c, self.session.settings.max_chart_points) for c in charts]
        return out

    # ---- scalar facts -------------------------------------------------------
    def fact(self, spec: MetricSpec) -> Fact:
        cq = self.compiler.metric(spec)
        rows, lineage = self._run(spec, cq, max_rows=1)
        row = rows[0] if rows else {}
        comp = _components(spec.metric, row)
        return Fact(id=spec.fact_id, label=spec.label, value=_primary(spec.metric, comp), components=comp,
                    display=display(spec.metric, comp, spec.format), unit=spec.format.unit, lineage=lineage)

    # ---- summary tables -----------------------------------------------------
    def _header_n(self, table: TableSpec, den: Denominator) -> tuple[dict[Any, int], int, list[Lineage]]:
        """N per column (and overall) for "Placebo (N=120)" headers."""
        col = den.col_by or table.col_by
        lineages = []
        per_col: dict[Any, int] = {}
        if col:
            spec = MetricSpec(fact_id="header_n", label="N", dataset=den.dataset, metric="count",
                              distinct_on=den.distinct_on, filters=den.filters)
            b_sql, b_params = self._grouped_count(den.dataset, col, den)
            cq = CompiledQuery(b_sql, b_params, [den.dataset], {den.dataset: {col}})
            rows, lin = self._run(spec, cq)
            per_col = {r["_col"]: int(r["n"]) for r in rows}
            lineages.append(lin)
        total_spec = MetricSpec(fact_id="header_n_total", label="N", dataset=den.dataset, metric="count",
                                distinct_on=den.distinct_on, filters=den.filters)
        cq = self.compiler.metric(total_spec)
        rows, lin = self._run(total_spec, cq, max_rows=1)
        lineages.append(lin)
        return per_col, int(rows[0]["value"]) if rows else 0, lineages

    def _grouped_count(self, ds: str, col: str, den: Denominator) -> tuple[str, list]:
        from reportkit.compute.compiler import _Builder  # noqa: PLC0415

        b = _Builder(self.session.catalog)
        t = b.ds(ds)
        c = b.col(ds, col)
        where = b.where(ds, den.filters)
        return (f"SELECT {c} AS _col, {b.count_expr(ds, den.distinct_on)} AS n FROM {t} "
                f"WHERE {where} GROUP BY {c}"), b.params

    def table(self, spec: TableSpec) -> TableResult:
        lineages: list[Lineage] = []
        cells: dict[tuple, dict[Any, dict]] = {}  # (row_idx, row_value) -> {col_value: row}
        col_values: set[Any] = set()
        TOTAL = object()

        for i, r in enumerate(spec.rows):
            cq = self.compiler.table_row(spec, r, by_column=bool(spec.col_by))
            rows, lin = self._run(spec, cq)
            lineages.append(lin)
            for row in rows:
                col = row.get("_col", TOTAL) if spec.col_by else TOTAL
                if spec.col_by:
                    col_values.add(col)
                cells.setdefault((i, row.get("_row")), {})[col] = row
            if spec.col_by and spec.include_total:
                cq_t = self.compiler.table_row(spec, r, by_column=False)
                rows_t, lin_t = self._run(spec, cq_t)
                lineages.append(lin_t)
                for row in rows_t:
                    cells.setdefault((i, row.get("_row")), {})[TOTAL] = row

        per_col_n: dict[Any, int] = {}
        total_n: int | None = None
        if spec.header_n:
            per_col_n, total_n, lin_n = self._header_n(spec, spec.header_n)
            lineages += lin_n
            col_values |= set(per_col_n)  # an arm with zero events must still get a column

        if spec.col_by:
            present = sorted(col_values, key=lambda v: (v is None, str(v)))
            if spec.col_order:
                ordered = [v for v in spec.col_order if v in col_values] + \
                          [v for v in present if v not in spec.col_order]
            else:
                ordered = present
            columns: list[Any] = ordered + ([TOTAL] if spec.include_total else [])
        else:
            columns = [TOTAL]

        def header_label(c: Any) -> str:
            base = "Total" if c is TOTAL else str(c)
            if not spec.header_n:
                return base if spec.col_by else "Value"
            n = total_n if c is TOTAL else per_col_n.get(c, 0)
            return f"{base} (N={fmt_int(n)})" if spec.col_by or c is not TOTAL else f"N={fmt_int(n)}"

        header = [spec.stub_header] + [header_label(c) for c in columns]
        out_rows: list[list[str]] = []
        for i, r in enumerate(spec.rows):
            keys = [k for k in cells if k[0] == i]
            if r.row_by:
                out_rows.append([r.label] + [""] * len(columns))
                keys = self._sort_expanded(keys, cells, spec, r, columns)
                for k in keys:
                    label = "Missing" if k[1] is None else str(k[1])
                    out_rows.append([f"    {label}"] + [self._cell(r, cells[k].get(c)) for c in columns])
            else:
                k = (i, None)
                out_rows.append([r.label] + [self._cell(r, cells.get(k, {}).get(c)) for c in columns])

        return TableResult(id=spec.table_id, title=spec.title, header=header, rows=out_rows,
                           footnote=spec.footnote, lineage=lineages)

    @staticmethod
    def _sort_expanded(keys, cells, spec: TableSpec, r: RowSpec, columns) -> list:
        if spec.sort_expanded == "count_desc":
            def weight(k):
                vals = cells[k].values()
                return -sum(float(v.get("n") or v.get("value") or 0) for v in vals), str(k[1])
            return sorted(keys, key=weight)
        return sorted(keys, key=lambda k: (k[1] is None, str(k[1])))

    @staticmethod
    def _cell(r: RowSpec, row: dict | None) -> str:
        if row is None:
            return "0" if r.metric in COUNT_LIKE else "NE"
        return display(r.metric, _components(r.metric, row), r.format)

    # ---- LLM-written SQL ----------------------------------------------------
    def sql(self, spec: SqlSpec) -> TableResult | Fact:
        cq = self.compiler.raw_sql(spec)
        rows, lineage = self._run(spec, cq)
        if spec.output == "fact":
            if len(rows) != 1:
                raise ValueError(f"fact SQL must return exactly one row, got {len(rows)}")
            value = next((v for v in rows[0].values() if isinstance(v, (int, float))), None)
            disp = fmt_int(value) if isinstance(value, int) else fmt_number(value, spec.format.decimals)
            if spec.format.unit and disp != "NE":
                disp = f"{disp} {spec.format.unit}"
            return Fact(id=spec.output_id, label=spec.title, value=value, components={"value": value},
                        display=disp, unit=spec.format.unit, lineage=lineage)
        header = list(rows[0].keys()) if rows else []
        body = [[self._fmt_any(v, spec.format) for v in r.values()] for r in rows]
        return TableResult(id=spec.output_id, title=spec.title, header=header, rows=body, lineage=[lineage])

    @staticmethod
    def _fmt_any(v: Any, fmt: FactFormat) -> str:
        if v is None:
            return ""
        if isinstance(v, bool):
            return str(v)
        if isinstance(v, int):
            return fmt_int(v, fmt.thousands)
        if isinstance(v, float):
            return fmt_number(v, fmt.decimals, fmt.thousands)
        return str(v)

    # ---- chart data ---------------------------------------------------------
    def chart_data(self, spec: ChartSpec) -> tuple[list[dict], Lineage]:
        cq = self.compiler.chart(spec, self.session.settings.max_chart_points)
        return self._run(spec, cq, max_rows=self.session.settings.max_chart_points)
