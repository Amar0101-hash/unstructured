"""Validation for SQL that did not come from our compiler (LLM fallback).

Rules: exactly one statement, a query (SELECT/UNION/CTE) only, every table
must be a catalog dataset or a CTE, and no file/system functions. Combined
with ``SET lock_configuration=true`` on the DuckDB connection, a bad query
can at worst return wrong rows - which the row cap and review catch.
"""

from __future__ import annotations

import sqlglot
from sqlglot import exp

BLOCKED_FUNCTION_PREFIXES = ("read_", "glob", "sniff_", "parquet_", "duckdb_", "pragma_", "query_table")
BLOCKED_FUNCTIONS = {"query", "getenv", "current_setting", "load_extension", "postgres_query",
                     "postgres_scan", "sqlite_scan", "iceberg_scan", "delta_scan", "http_get"}


class SqlRejected(ValueError):
    pass


def _function_name(f: exp.Func) -> str:
    if isinstance(f, exp.Anonymous):
        return str(f.name).lower()
    return f.sql_name().lower()


def validate_select(sql: str, allowed_tables: set[str], dialect: str = "duckdb") -> str:
    try:
        statements = [s for s in sqlglot.parse(sql, read=dialect) if s is not None]
    except sqlglot.errors.ParseError as e:
        raise SqlRejected(f"SQL does not parse: {e}") from e
    if len(statements) != 1:
        raise SqlRejected("exactly one statement is allowed")
    tree = statements[0]
    if not isinstance(tree, exp.Query):
        raise SqlRejected(f"only SELECT queries are allowed, got {type(tree).__name__}")

    ctes = {c.alias for c in tree.find_all(exp.CTE)}
    for t in tree.find_all(exp.Table):
        name = t.name
        if not name:
            raise SqlRejected(f"table functions are not allowed: {t.sql(dialect=dialect)}")
        if t.args.get("db") or t.args.get("catalog"):
            raise SqlRejected(f"qualified table names are not allowed: {t.sql(dialect=dialect)}")
        if name not in allowed_tables | ctes:
            raise SqlRejected(f"unknown table {name!r}; allowed: {sorted(allowed_tables)}")

    for f in tree.find_all(exp.Func):
        fname = _function_name(f)
        if fname in BLOCKED_FUNCTIONS or fname.startswith(BLOCKED_FUNCTION_PREFIXES):
            raise SqlRejected(f"function {fname!r} is not allowed")

    return tree.sql(dialect=dialect)


def tables_in(sql: str, dialect: str = "duckdb") -> set[str]:
    tree = sqlglot.parse_one(sql, read=dialect)
    ctes = {c.alias for c in tree.find_all(exp.CTE)}
    return {t.name for t in tree.find_all(exp.Table) if t.name and t.name not in ctes}


def inline_params(sql: str, params: list, dialect_in: str = "duckdb") -> exp.Expression:
    """Replace ``?`` placeholders with properly escaped literals (for engines
    where we transpile instead of binding, e.g. Athena)."""
    tree = sqlglot.parse_one(sql, read=dialect_in)
    values = iter(params)

    def _sub(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Placeholder):
            return exp.convert(next(values))
        return node

    out = tree.transform(_sub)
    sentinel = object()
    if next(values, sentinel) is not sentinel:
        raise ValueError("more params than placeholders")
    return out


def transpile(sql: str, params: list, write: str) -> str:
    return inline_params(sql, params).sql(dialect=write)
