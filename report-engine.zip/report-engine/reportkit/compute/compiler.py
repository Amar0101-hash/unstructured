"""Compile declarative specs into parameterised SQL (DuckDB dialect).

Identifiers are checked against the catalog and quoted; values only ever
travel as ``?`` parameters. Output column names are fixed (``_row``, ``_col``,
``value``, ``n``, ``d``, ``pct``, ``mean``, ``sd``) so the engine can read
results without knowing which spec produced them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from reportkit.compute.sql_guard import tables_in, validate_select
from reportkit.models.catalog import Catalog
from reportkit.models.compute import (
    PCT_METRICS,
    ChartSpec,
    Denominator,
    Filter,
    MetricName,
    MetricSpec,
    RowSpec,
    SqlSpec,
    TableSpec,
)

PUSHDOWN_UNSAFE = {"median"}  # Athena/Trino has no exact median; such specs run locally


class CompileError(ValueError):
    pass


@dataclass
class CompiledQuery:
    sql: str
    params: list[Any]
    datasets: list[str]
    columns_used: dict[str, set[str]] = field(default_factory=dict)
    pushdown_safe: bool = True
    shape: Literal["scalar", "rows"] = "rows"


def q(ident: str) -> str:
    return '"' + ident.replace('"', '""') + '"'


class _Builder:
    def __init__(self, catalog: Catalog):
        self.catalog = catalog
        self.params: list[Any] = []
        self.used: dict[str, set[str]] = {}

    def ds(self, name: str) -> str:
        self.catalog.get(name)  # raises on unknown
        self.used.setdefault(name, set())
        return q(name)

    def col(self, ds_name: str, col: str) -> str:
        ds = self.catalog.get(ds_name)
        if ds.columns and ds.column(col) is None:
            known = ", ".join(c.name for c in ds.columns)
            raise CompileError(f"unknown column {col!r} in dataset {ds_name!r}; columns: {known}")
        self.used.setdefault(ds_name, set()).add(col)
        return q(col)

    def where(self, ds_name: str, *groups: list[Filter]) -> str:
        parts = []
        for flt in (f for g in groups for f in g):
            c = self.col(ds_name, flt.col)
            if flt.op in ("is_null", "not_null"):
                parts.append(f"{c} IS {'NOT ' if flt.op == 'not_null' else ''}NULL")
            elif flt.op in ("in", "not_in"):
                marks = ", ".join("?" for _ in flt.value)  # type: ignore[union-attr]
                parts.append(f"{c} {'NOT ' if flt.op == 'not_in' else ''}IN ({marks})")
                self.params.extend(flt.value)  # type: ignore[arg-type]
            elif flt.op == "between":
                parts.append(f"{c} BETWEEN ? AND ?")
                self.params.extend(flt.value)  # type: ignore[arg-type]
            elif flt.op == "like":
                parts.append(f"{c} LIKE ?")
                self.params.append(flt.value)
            else:
                parts.append(f"{c} {flt.op} ?")
                self.params.append(flt.value)
        return " AND ".join(parts) if parts else "TRUE"

    def count_expr(self, ds_name: str, distinct_on: str | None) -> str:
        return f"COUNT(DISTINCT {self.col(ds_name, distinct_on)})" if distinct_on else "COUNT(*)"

    def aggregates(self, ds_name: str, metric: MetricName, column: str | None,
                   distinct_on: str | None) -> list[str]:
        if metric == "count":
            return [f"{self.count_expr(ds_name, distinct_on)} AS value"]
        c = self.col(ds_name, column)  # type: ignore[arg-type]
        return {
            "count_distinct": [f"COUNT(DISTINCT {c}) AS value"],
            "sum": [f"SUM({c}) AS value"],
            "mean": [f"AVG({c}) AS value"],
            "median": [f"MEDIAN({c}) AS value"],
            "min": [f"MIN({c}) AS value"],
            "max": [f"MAX({c}) AS value"],
            "std": [f"STDDEV_SAMP({c}) AS value"],
            "mean_sd": [f"COUNT({c}) AS n", f"AVG({c}) AS mean", f"STDDEV_SAMP({c}) AS sd"],
        }[metric]


class SpecCompiler:
    def __init__(self, catalog: Catalog):
        self.catalog = catalog

    # ---- scalar fact ------------------------------------------------------
    def metric(self, spec: MetricSpec) -> CompiledQuery:
        b = _Builder(self.catalog)
        if spec.metric in PCT_METRICS:
            sql = self._pct_sql(b, spec.dataset, spec.filters, spec.numerator, spec.distinct_on,
                                spec.denominator, row_key=None, col_key=None)
        else:
            t = b.ds(spec.dataset)
            aggs = b.aggregates(spec.dataset, spec.metric, spec.column, spec.distinct_on)
            where = b.where(spec.dataset, spec.filters)
            sql = f"SELECT {', '.join(aggs)} FROM {t} WHERE {where}"
        return CompiledQuery(sql, b.params, sorted(b.used), b.used,
                             pushdown_safe=spec.metric not in PUSHDOWN_UNSAFE, shape="scalar")

    # ---- one row-spec of a summary table ------------------------------------
    def table_row(self, table: TableSpec, row: RowSpec, by_column: bool) -> CompiledQuery:
        b = _Builder(self.catalog)
        col_key = table.col_by if by_column else None
        pop = [*table.filters, *row.filters]
        if row.metric in PCT_METRICS:
            sql = self._pct_sql(b, table.dataset, pop, row.numerator, row.distinct_on, row.denominator,
                                row_key=row.row_by, col_key=col_key)
        else:
            t = b.ds(table.dataset)
            keys, group = self._keys(b, table.dataset, row.row_by, col_key)
            aggs = b.aggregates(table.dataset, row.metric, row.column, row.distinct_on)
            where = b.where(table.dataset, pop)
            sql = f"SELECT {', '.join([*keys, *aggs])} FROM {t} WHERE {where}"
            if group:
                sql += f" GROUP BY {', '.join(group)}"
        return CompiledQuery(sql, b.params, sorted(b.used), b.used,
                             pushdown_safe=row.metric not in PUSHDOWN_UNSAFE)

    def _keys(self, b: _Builder, ds: str, row_by: str | None, col_by: str | None) -> tuple[list[str], list[str]]:
        keys, group = [], []
        if row_by:
            c = b.col(ds, row_by)
            keys.append(f"{c} AS _row")
            group.append(c)
        if col_by:
            c = b.col(ds, col_by)
            keys.append(f"{c} AS _col")
            group.append(c)
        return keys, group

    def _pct_sql(self, b: _Builder, ds: str, population: list[Filter], numerator: list[Filter],
                 distinct_on: str | None, denominator: Denominator | None,
                 row_key: str | None, col_key: str | None) -> str:
        t = b.ds(ds)
        keys, group = self._keys(b, ds, row_key, col_key)
        num_where = b.where(ds, population, numerator)
        num = f"SELECT {', '.join([*keys, f'{b.count_expr(ds, distinct_on) } AS n'])} FROM {t} WHERE {num_where}"
        if group:
            num += f" GROUP BY {', '.join(group)}"

        den_ds = denominator.dataset if denominator else ds
        den_filters = denominator.filters if denominator else population
        den_distinct = (denominator.distinct_on if denominator else None) or distinct_on
        den_col = (denominator.col_by if denominator and denominator.col_by else col_key) if col_key else None
        dt = b.ds(den_ds)
        den_keys, den_group = self._keys(b, den_ds, None, den_col)
        den = (f"SELECT {', '.join([*den_keys, f'{b.count_expr(den_ds, den_distinct)} AS d'])} "
               f"FROM {dt} WHERE {b.where(den_ds, den_filters)}")
        if den_group:
            den += f" GROUP BY {', '.join(den_group)}"

        out_keys = [k for k in ("_row", "_col") if (k == "_row" and row_key) or (k == "_col" and col_key)]
        select_keys = [f"num.{k}" for k in out_keys]
        join = "LEFT JOIN den ON num._col IS NOT DISTINCT FROM den._col" if col_key else "CROSS JOIN den"
        return (f"WITH num AS ({num}), den AS ({den}) "
                f"SELECT {', '.join([*select_keys, 'num.n', 'den.d', 'CAST(num.n AS DOUBLE) * 100 / NULLIF(den.d, 0) AS pct'])} "
                f"FROM num {join}")

    # ---- chart data -------------------------------------------------------
    def chart(self, spec: ChartSpec, max_points: int) -> CompiledQuery:
        b = _Builder(self.catalog)
        d = spec.data
        t = b.ds(d.dataset)
        x = b.col(d.dataset, d.x)
        g = b.col(d.dataset, d.group) if d.group else None
        y = b.col(d.dataset, d.y) if d.y else None
        where = b.where(d.dataset, d.filters)
        sel = [f"{x} AS _x"] + ([f"{g} AS _g"] if g else [])
        if spec.chart in ("bar", "line") and d.agg:
            agg = {
                "count": b.count_expr(d.dataset, d.distinct_on),
                "sum": f"SUM({y})",
                "mean": f"AVG({y})",
                "median": f"MEDIAN({y})",
            }[d.agg]
            grp = [x] + ([g] if g else [])
            sql = (f"SELECT {', '.join([*sel, f'{agg} AS _y'])} FROM {t} WHERE {where} "
                   f"GROUP BY {', '.join(grp)} ORDER BY {', '.join(grp)}")
        else:
            if y:
                sel.append(f"{y} AS _y")
            sql = f"SELECT {', '.join(sel)} FROM {t} WHERE {where} ORDER BY 1"
        return CompiledQuery(sql, b.params, sorted(b.used), b.used,
                             pushdown_safe=d.agg != "median")

    # ---- LLM-written SQL ----------------------------------------------------
    def raw_sql(self, spec: SqlSpec) -> CompiledQuery:
        allowed = set(spec.datasets)
        unknown = allowed - self.catalog.names()
        if unknown:
            raise CompileError(f"unknown datasets: {sorted(unknown)}")
        sql = validate_select(spec.sql, allowed)
        used = {name: set() for name in tables_in(sql)}  # all columns: no projection info
        return CompiledQuery(sql, [], sorted(used), used, pushdown_safe=False,
                             shape="scalar" if spec.output == "fact" else "rows")
