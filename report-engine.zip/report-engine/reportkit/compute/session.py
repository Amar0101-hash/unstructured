"""One DuckDB connection per job, plus routing to Athena / RDS.

Routing rule per query:
  - every dataset is Athena-pushdown in one database and the query is exact
    in Trino (no median)                 -> run in Athena
  - every dataset is RDS-pushdown on one connection, query exact -> run in Postgres
  - otherwise                            -> run in DuckDB; non-file datasets are
    materialised first (only the columns the job's queries touch)
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass

import duckdb
import pyarrow as pa

from reportkit.compute.compiler import CompiledQuery
from reportkit.compute.duck import describe, new_connection, sql_str, timeout
from reportkit.connectors.athena import AthenaConnector
from reportkit.connectors.base import rows_to_arrow
from reportkit.connectors.rds import RdsConnector
from reportkit.models.catalog import AthenaSource, Catalog, FileSource, RdsSource
from reportkit.models.results import EngineName
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore

log = logging.getLogger(__name__)


class QueryError(RuntimeError):
    pass


class ResultTooLarge(QueryError):
    pass


@dataclass
class QueryResult:
    table: pa.Table
    engine: EngineName
    engine_version: str
    executed_sql: str


class ComputeSession:
    def __init__(self, settings: Settings, blob: BlobStore, catalog: Catalog, job_id: str):
        self.settings = settings
        self.blob = blob
        self.catalog = catalog
        self.job_id = job_id
        self.athena = AthenaConnector(settings)
        self.rds = RdsConnector(settings, blob)
        need_s3 = any(self._is_s3(e.dataset.source) for e in catalog.entries.values()) or \
            settings.blob_backend == "s3"
        self.con: duckdb.DuckDBPyConnection = new_connection(settings, need_s3=need_s3, lock=False)
        self._local: set[str] = set()
        self._lock = threading.RLock()  # one DuckDB connection; planner threads share it
        for name, entry in catalog.entries.items():
            if isinstance(entry.dataset.source, FileSource):
                self._register_file(name, entry.dataset.source)
        # Nothing after this point can change memory/threads/extensions.
        self.con.execute("SET lock_configuration=true")

    def close(self) -> None:
        self.con.close()

    def __enter__(self) -> "ComputeSession":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    @staticmethod
    def _is_s3(src) -> bool:
        return isinstance(src, FileSource) and src.uri.startswith("s3://")

    def _path(self, uri: str) -> str:
        return uri if uri.startswith("s3://") else self.blob.duckdb_path(uri)

    def _register_file(self, name: str, src: FileSource) -> None:
        reader = "read_parquet" if src.format == "parquet" else "read_csv"
        opts = "" if src.format == "parquet" else ", header=true"
        self.con.execute(f'CREATE OR REPLACE VIEW "{name}" AS SELECT * FROM {reader}({sql_str(self._path(src.uri))}{opts})')
        self._local.add(name)

    # ---- routing ----------------------------------------------------------
    def route(self, cq: CompiledQuery) -> EngineName:
        sources = [self.catalog.get(n).source for n in cq.datasets]
        if cq.pushdown_safe and sources and all(isinstance(s, AthenaSource) and s.mode == "pushdown" for s in sources):
            if len({s.database for s in sources}) == 1:  # type: ignore[union-attr]
                return "athena"
        if cq.pushdown_safe and sources and all(isinstance(s, RdsSource) and s.mode == "pushdown" for s in sources):
            if len({s.connection for s in sources}) == 1:  # type: ignore[union-attr]
                return "rds"
        return "duckdb"

    def prepare(self, queries: list[CompiledQuery]) -> None:
        """Materialise every non-file dataset that some DuckDB-routed query needs,
        with the union of columns all those queries touch."""
        needed: dict[str, set[str] | None] = {}
        for cq in queries:
            if self.route(cq) != "duckdb":
                continue
            for name in cq.datasets:
                if name in self._local:
                    continue
                cols = cq.columns_used.get(name)
                if not cols:  # raw SQL: no projection info -> all columns
                    needed[name] = None
                elif needed.get(name, set()) is not None:
                    needed[name] = (needed.get(name) or set()) | cols
        for name, cols in needed.items():
            self._materialize(name, cols)

    def _materialize(self, name: str, cols: set[str] | None) -> None:
        ds = self.catalog.get(name)
        src = ds.source
        log.info("materialising %s (%s columns)", name, "all" if cols is None else len(cols))
        if isinstance(src, AthenaSource):
            uri = self.athena.unload(src, cols)
            self.con.execute(f'CREATE OR REPLACE VIEW "{name}" AS SELECT * FROM read_parquet({sql_str(uri)})')
        elif isinstance(src, RdsSource):
            key = f"jobs/{self.job_id}/materialized/{name}.parquet"
            uri = self.rds.materialize(src, cols, key)
            self.con.execute(f'CREATE OR REPLACE VIEW "{name}" AS SELECT * FROM read_parquet({sql_str(self._path(uri))})')
        else:  # pragma: no cover
            raise QueryError(f"cannot materialise {name}")
        self._local.add(name)

    # ---- execution ----------------------------------------------------------
    def check(self, cq: CompiledQuery) -> None:
        """Bind and type-check without running (used to give the planner fast
        feedback). Only possible for datasets DuckDB can already see."""
        if all(n in self._local for n in cq.datasets):
            try:
                with self._lock:
                    self.con.execute(f"EXPLAIN {cq.sql}", cq.params)
            except duckdb.Error as e:
                raise QueryError(str(e).splitlines()[0]) from e

    def run(self, cq: CompiledQuery, max_rows: int | None = None) -> QueryResult:
        with self._lock:
            return self._run(cq, max_rows)

    def _run(self, cq: CompiledQuery, max_rows: int | None = None) -> QueryResult:
        max_rows = max_rows or self.settings.max_result_rows
        engine = self.route(cq)
        if engine == "athena":
            mapping = {n: self.catalog.get(n).source for n in cq.datasets}
            table = self.athena.query(cq.sql, cq.params, mapping)  # type: ignore[arg-type]
            executed, version = self.athena.athena_sql(cq.sql, cq.params, mapping), self.athena.engine_version  # type: ignore[arg-type]
        elif engine == "rds":
            mapping = {n: self.catalog.get(n).source for n in cq.datasets}
            table = self.rds.query(cq.sql, cq.params, mapping)  # type: ignore[arg-type]
            executed, version = cq.sql, self.rds.engine_version(next(iter(mapping.values())))  # type: ignore[arg-type]
        else:
            missing = [n for n in cq.datasets if n not in self._local]
            for n in missing:
                self._materialize(n, None)
            try:
                with timeout(self.con, self.settings.query_timeout_s):
                    # fetchmany keeps the query's own ORDER BY and stops at the cap
                    res = self.con.execute(cq.sql, cq.params)
                    cols = [d[0] for d in res.description]
                    table = rows_to_arrow(cols, res.fetchmany(max_rows + 1))
            except duckdb.InterruptException as e:
                raise QueryError(f"query exceeded {self.settings.query_timeout_s}s") from e
            except duckdb.Error as e:
                raise QueryError(str(e).splitlines()[0]) from e
            executed, version = cq.sql, f"duckdb-{duckdb.__version__}"
        if table.num_rows > max_rows:
            raise ResultTooLarge(f"result has more than {max_rows} rows; aggregate further for a report slot")
        return QueryResult(table=table, engine=engine, engine_version=version, executed_sql=executed)

    def describe_local(self, name: str) -> None:
        ds = self.catalog.get(name)
        cols, n = describe(self.con, f'"{name}"', sample_values=self.settings.catalog_sample_values,
                           max_cardinality=self.settings.catalog_sample_max_cardinality)
        ds.columns, ds.row_count = cols, n
