"""Number formatting with round-half-up (SAS convention).

Python's round() and f-strings use banker's rounding (2.25 -> 2.2). CSR
reviewers compare against SAS output, which rounds half away from zero
(2.25 -> 2.3), so all display values go through Decimal here.
"""

from __future__ import annotations

import math
from decimal import ROUND_HALF_UP, Decimal

from reportkit.models.compute import FactFormat


def round_half_up(value: float | int, decimals: int) -> Decimal:
    q = Decimal(1).scaleb(-decimals)  # 10**-decimals
    if isinstance(value, float):
        # Fuzz like SAS ROUND: 2.2499999999999996 (float noise from AVG) should
        # round as 2.25 does. Snap to 10 decimals before the half-up step.
        d = Decimal(str(round(value, 10)))
    else:
        d = Decimal(int(value))
    return d.quantize(q, rounding=ROUND_HALF_UP)


def fmt_number(value: float | int | None, decimals: int, thousands: bool = True) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "NE"  # not estimable
    d = round_half_up(value, decimals)
    return f"{d:,.{decimals}f}" if thousands else f"{d:.{decimals}f}"


def fmt_int(value: float | int | None, thousands: bool = True) -> str:
    if value is None:
        return "NE"
    return fmt_number(int(value), 0, thousands)


def fmt_n_pct(n: int | None, pct: float | None, fmt: FactFormat) -> str:
    if n is None:
        return "NE"
    if n == 0:
        return "0"  # CSR convention: no "(0.0%)"
    return f"{fmt_int(n, fmt.thousands)} ({fmt_number(pct, fmt.decimals, False)}%)"


def fmt_mean_sd(mean: float | None, sd: float | None, fmt: FactFormat) -> str:
    sd_txt = fmt_number(sd, fmt.decimals + 1, fmt.thousands) if sd is not None else "NE"
    return f"{fmt_number(mean, fmt.decimals, fmt.thousands)} ({sd_txt})"


def display(metric: str, components: dict[str, float | int | None], fmt: FactFormat) -> str:
    """Display string for one computed value. SD carries one more decimal than
    the mean, as in most CSR shells."""
    if metric == "n_pct":
        return fmt_n_pct(components.get("n"), components.get("pct"), fmt)
    if metric == "pct":
        return f"{fmt_number(components.get('pct'), fmt.decimals, False)}%"
    if metric == "mean_sd":
        return fmt_mean_sd(components.get("mean"), components.get("sd"), fmt)
    v = components.get("value")
    if metric in ("count", "count_distinct"):
        out = fmt_int(v, fmt.thousands)
    else:
        out = fmt_number(v, fmt.decimals, fmt.thousands)
    return f"{out} {fmt.unit}" if fmt.unit and out != "NE" else out
