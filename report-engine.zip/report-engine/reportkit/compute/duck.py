"""DuckDB connection setup and small helpers shared by ingest and compute."""

from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import Iterator

import duckdb
import pyarrow as pa

from reportkit.models.catalog import ColumnInfo
from reportkit.settings import Settings


def sql_str(value: str) -> str:
    """Single-quoted SQL string literal (for paths in read_parquet etc.)."""
    return "'" + value.replace("'", "''") + "'"


def new_connection(settings: Settings, *, need_s3: bool = False, lock: bool = False) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(database=":memory:")
    temp_dir = settings.scratch_subdir("duckdb")
    stmts = [
        f"SET memory_limit={sql_str(settings.duckdb_memory_limit)}",
        f"SET threads={int(settings.duckdb_threads)}",
        f"SET temp_directory={sql_str(str(temp_dir))}",
        "SET preserve_insertion_order=false",
        "SET enable_progress_bar=false",
    ]
    if settings.duckdb_extension_dir:
        stmts.append(f"SET extension_directory={sql_str(settings.duckdb_extension_dir)}")
    for s in stmts:
        con.execute(s)
    if need_s3:
        enable_s3(con, settings)
    if lock:
        con.execute("SET lock_configuration=true")
    return con


def enable_s3(con: duckdb.DuckDBPyConnection, settings: Settings) -> None:
    # Extensions are installed into the image at build time; LOAD only reads them,
    # so this works on a read-only root filesystem. The credential chain picks up
    # the ECS task role.
    con.execute("LOAD httpfs")
    con.execute("LOAD aws")
    con.execute(f"CREATE OR REPLACE SECRET rk_s3 (TYPE s3, PROVIDER credential_chain, "
                f"REGION {sql_str(settings.aws_region)})")


def to_arrow(rel: duckdb.DuckDBPyRelation) -> pa.Table:
    # DuckDB 1.x: .arrow(); 2.x: .to_arrow_table()
    fn = getattr(rel, "to_arrow_table", None) or rel.arrow
    out = fn()
    return out.read_all() if isinstance(out, pa.RecordBatchReader) else out


@contextmanager
def timeout(con: duckdb.DuckDBPyConnection, seconds: float) -> Iterator[None]:
    timer = threading.Timer(seconds, con.interrupt)
    timer.daemon = True
    timer.start()
    try:
        yield
    finally:
        timer.cancel()


def describe(con: duckdb.DuckDBPyConnection, relation: str, *, labels: dict[str, str] | None = None,
             sample_values: bool = True, max_cardinality: int = 20) -> tuple[list[ColumnInfo], int]:
    """Column names/types, row count and (optionally) the distinct values of
    low-cardinality text columns, for the planner's catalog view."""
    rows = con.execute(f"DESCRIBE SELECT * FROM {relation}").fetchall()
    n = con.execute(f"SELECT COUNT(*) FROM {relation}").fetchone()[0]
    cols: list[ColumnInfo] = []
    for name, typ, *_ in rows:
        info = ColumnInfo(name=name, type=str(typ), label=(labels or {}).get(name))
        if sample_values and str(typ) in ("VARCHAR", "BOOLEAN"):
            qn = '"' + name.replace('"', '""') + '"'
            card = con.execute(f"SELECT COUNT(DISTINCT {qn}) FROM {relation}").fetchone()[0]
            if 0 < card <= max_cardinality:
                vals = con.execute(f"SELECT DISTINCT {qn} FROM {relation} WHERE {qn} IS NOT NULL "
                                   f"ORDER BY 1 LIMIT {max_cardinality}").fetchall()
                info.sample_values = [str(v[0]) for v in vals]
        cols.append(info)
    return cols, int(n)
