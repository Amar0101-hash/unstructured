"""Job queue: SQS in prod, inline (in-process) in dev and tests."""

from __future__ import annotations

import json
import logging
import threading
from typing import Callable, Protocol

from reportkit.settings import Settings

log = logging.getLogger(__name__)


class JobQueue(Protocol):
    def enqueue(self, job_id: str) -> None: ...


class SqsJobQueue:
    def __init__(self, settings: Settings):
        import boto3  # noqa: PLC0415

        if not settings.sqs_queue_url:
            raise ValueError("RK_SQS_QUEUE_URL is required when RK_QUEUE_BACKEND=sqs")
        self.url = settings.sqs_queue_url
        self.sqs = boto3.client("sqs", region_name=settings.aws_region)

    def enqueue(self, job_id: str) -> None:
        kwargs = {"QueueUrl": self.url, "MessageBody": json.dumps({"job_id": job_id})}
        if self.url.endswith(".fifo"):
            kwargs.update(MessageGroupId=job_id, MessageDeduplicationId=job_id)
        self.sqs.send_message(**kwargs)


class InlineJobQueue:
    """Runs the job in a background thread of the API process (dev only), or
    synchronously when ``sync=True`` (tests)."""

    def __init__(self, runner: Callable[[str], None], sync: bool = False):
        self.runner = runner
        self.sync = sync

    def enqueue(self, job_id: str) -> None:
        if self.sync:
            self.runner(job_id)
        else:
            threading.Thread(target=self.runner, args=(job_id,), daemon=True, name=f"job-{job_id}").start()
