"""Metadata store (Postgres in prod, SQLite in tests).

Pydantic models are stored as JSON (JSONB on Postgres) next to a few indexed
columns. Use Alembic for migrations in real environments; ``create_all`` is
for dev and tests.
"""

from __future__ import annotations

import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Iterator

from sqlalchemy import (
    JSON,
    BigInteger,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    create_engine,
    func,
    select,
    update,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from reportkit.models.catalog import Dataset
from reportkit.models.inventory import InventoryElement
from reportkit.models.job import JobRequest, JobResult, JobStatus
from reportkit.models.results import Fact

JsonType = JSON().with_variant(JSONB(), "postgresql")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:20]}"


class Base(DeclarativeBase):
    pass


class FileRow(Base):
    __tablename__ = "rk_files"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    sha256: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    filename: Mapped[str] = mapped_column(String(512))
    content_type: Mapped[str] = mapped_column(String(128))
    size: Mapped[int] = mapped_column(BigInteger)
    uri: Mapped[str] = mapped_column(Text)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    parsed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    parser_version: Mapped[str | None] = mapped_column(String(64), nullable=True)


class ElementRow(Base):
    __tablename__ = "rk_inventory_elements"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    file_id: Mapped[str] = mapped_column(ForeignKey("rk_files.id"), index=True)
    order: Mapped[int] = mapped_column(Integer)
    type: Mapped[str] = mapped_column(String(32))
    payload: Mapped[dict] = mapped_column(JsonType)


class DatasetRow(Base):
    __tablename__ = "rk_datasets"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    base_name: Mapped[str] = mapped_column(String(64))
    origin_file_id: Mapped[str | None] = mapped_column(String(64), index=True, nullable=True)
    payload: Mapped[dict] = mapped_column(JsonType)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class JobRow(Base):
    __tablename__ = "rk_jobs"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    status: Mapped[str] = mapped_column(String(32), index=True)
    request: Mapped[dict] = mapped_column(JsonType)
    result: Mapped[dict | None] = mapped_column(JsonType, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    version: Mapped[int] = mapped_column(Integer, default=0)  # optimistic concurrency
    worker_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class JobEventRow(Base):
    __tablename__ = "rk_job_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("rk_jobs.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    stage: Mapped[str] = mapped_column(String(32))
    level: Mapped[str] = mapped_column(String(16), default="info")
    message: Mapped[str] = mapped_column(Text)
    data: Mapped[dict | None] = mapped_column(JsonType, nullable=True)


class FactRow(Base):
    __tablename__ = "rk_facts"
    job_id: Mapped[str] = mapped_column(ForeignKey("rk_jobs.id"), primary_key=True)
    fact_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    payload: Mapped[dict] = mapped_column(JsonType)


class ArtifactRow(Base):
    __tablename__ = "rk_artifacts"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("rk_jobs.id"), index=True)
    kind: Mapped[str] = mapped_column(String(32))  # docx | manifest | figure | snapshot
    name: Mapped[str] = mapped_column(String(256))
    uri: Mapped[str] = mapped_column(Text)
    sha256: Mapped[str] = mapped_column(String(64))
    content_type: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


Index("ix_rk_job_events_job_id_id", JobEventRow.job_id, JobEventRow.id)


class Repository:
    def __init__(self, database_url: str, pool_size: int = 5):
        kwargs: dict[str, Any] = {"pool_pre_ping": True}
        if database_url.startswith("sqlite"):
            kwargs["connect_args"] = {"check_same_thread": False}
        else:
            kwargs.update(pool_size=pool_size, max_overflow=pool_size)
        self.engine = create_engine(database_url, **kwargs)
        if database_url.startswith("sqlite"):
            from sqlalchemy import event  # noqa: PLC0415

            @event.listens_for(self.engine, "connect")
            def _fk_on(dbapi_conn, _record):  # enforce FKs like Postgres does
                dbapi_conn.execute("PRAGMA foreign_keys=ON")
        self._session = sessionmaker(self.engine, expire_on_commit=False)

    def create_all(self) -> None:
        Base.metadata.create_all(self.engine)

    @contextmanager
    def session(self) -> Iterator[Session]:
        s = self._session()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    # ---- files -------------------------------------------------------------
    def get_file_by_sha(self, sha: str) -> FileRow | None:
        with self.session() as s:
            return s.scalar(select(FileRow).where(FileRow.sha256 == sha))

    def add_file(self, *, sha256: str, filename: str, content_type: str, size: int, uri: str,
                 created_by: str | None) -> FileRow:
        row = FileRow(id=f"f_{sha256[:24]}", sha256=sha256, filename=filename, content_type=content_type,
                      size=size, uri=uri, created_by=created_by)
        with self.session() as s:
            s.add(row)
        return row

    def get_file(self, file_id: str) -> FileRow | None:
        with self.session() as s:
            return s.get(FileRow, file_id)

    def mark_parsed(self, file_id: str, parser_version: str) -> None:
        with self.session() as s:
            s.execute(update(FileRow).where(FileRow.id == file_id)
                      .values(parsed_at=utcnow(), parser_version=parser_version))

    # ---- inventory ---------------------------------------------------------
    def replace_inventory(self, file_id: str, elements: list[InventoryElement]) -> None:
        with self.session() as s:
            s.query(ElementRow).filter(ElementRow.file_id == file_id).delete()
            for el in elements:
                s.add(ElementRow(id=el.id, file_id=file_id, order=el.order, type=el.type,
                                 payload=el.model_dump(mode="json")))

    def inventory(self, file_id: str) -> list[InventoryElement]:
        with self.session() as s:
            rows = s.scalars(select(ElementRow).where(ElementRow.file_id == file_id).order_by(ElementRow.order))
            return [InventoryElement.model_validate(r.payload) for r in rows]

    # ---- datasets ----------------------------------------------------------
    def upsert_dataset(self, ds: Dataset, created_by: str | None = None) -> None:
        with self.session() as s:
            row = s.get(DatasetRow, ds.id)
            payload = ds.model_dump(mode="json")
            if row:
                row.payload, row.base_name = payload, ds.base_name
            else:
                s.add(DatasetRow(id=ds.id, base_name=ds.base_name, origin_file_id=ds.origin_file_id,
                                 payload=payload, created_by=created_by))

    def get_dataset(self, dataset_id: str) -> Dataset | None:
        with self.session() as s:
            row = s.get(DatasetRow, dataset_id)
            return Dataset.model_validate(row.payload) if row else None

    def datasets_for_file(self, file_id: str) -> list[Dataset]:
        with self.session() as s:
            rows = s.scalars(select(DatasetRow).where(DatasetRow.origin_file_id == file_id).order_by(DatasetRow.id))
            return [Dataset.model_validate(r.payload) for r in rows]

    def list_datasets(self, limit: int = 200) -> list[Dataset]:
        with self.session() as s:
            rows = s.scalars(select(DatasetRow).where(DatasetRow.origin_file_id.is_(None))
                             .order_by(DatasetRow.created_at.desc()).limit(limit))
            return [Dataset.model_validate(r.payload) for r in rows]

    # ---- jobs --------------------------------------------------------------
    def create_job(self, request: JobRequest, created_by: str | None) -> str:
        job_id = new_id("job")
        with self.session() as s:
            s.add(JobRow(id=job_id, status=JobStatus.queued.value, request=request.model_dump(mode="json"),
                         created_by=created_by))
            s.flush()  # no ORM relationship orders these inserts; the FK needs the job row first
            s.add(JobEventRow(job_id=job_id, stage="queued", message="Job queued"))
        return job_id

    def get_job(self, job_id: str) -> JobRow | None:
        with self.session() as s:
            return s.get(JobRow, job_id)

    def claim_job(self, job_id: str, worker_id: str, stale_after_s: int) -> bool:
        """Atomically take a job. A running job whose heartbeat went stale (its
        worker died) can be re-claimed; a fresh one cannot."""
        stale_before = utcnow() - timedelta(seconds=stale_after_s)
        with self.session() as s:
            res = s.execute(
                update(JobRow)
                .where(JobRow.id == job_id)
                .where(
                    (JobRow.status == JobStatus.queued.value)
                    | ((JobRow.status == JobStatus.running.value) & (JobRow.heartbeat_at < stale_before))
                )
                .values(status=JobStatus.running.value, worker_id=worker_id, heartbeat_at=utcnow(),
                        attempts=JobRow.attempts + 1, version=JobRow.version + 1)
            )
            return res.rowcount == 1

    def heartbeat(self, job_id: str, worker_id: str) -> None:
        with self.session() as s:
            s.execute(update(JobRow).where(JobRow.id == job_id, JobRow.worker_id == worker_id)
                      .values(heartbeat_at=utcnow()))

    def finish_job(self, job_id: str, status: JobStatus, result: JobResult | None = None,
                   error: str | None = None) -> None:
        with self.session() as s:
            s.execute(update(JobRow).where(JobRow.id == job_id).values(
                status=status.value, result=result.model_dump(mode="json") if result else None,
                error=error, version=JobRow.version + 1))

    def requeue_job(self, job_id: str, error: str) -> None:
        with self.session() as s:
            s.execute(update(JobRow).where(JobRow.id == job_id).values(
                status=JobStatus.queued.value, error=error, worker_id=None, version=JobRow.version + 1))

    def add_event(self, job_id: str, stage: str, message: str, level: str = "info",
                  data: dict | None = None) -> None:
        with self.session() as s:
            s.add(JobEventRow(job_id=job_id, stage=stage, level=level, message=message, data=data))

    def events_after(self, job_id: str, after_id: int, limit: int = 200) -> list[JobEventRow]:
        with self.session() as s:
            return list(s.scalars(select(JobEventRow).where(JobEventRow.job_id == job_id, JobEventRow.id > after_id)
                                  .order_by(JobEventRow.id).limit(limit)))

    # ---- facts & artifacts -------------------------------------------------
    def save_facts(self, job_id: str, facts: list[Fact]) -> None:
        with self.session() as s:
            s.query(FactRow).filter(FactRow.job_id == job_id).delete()
            for f in facts:
                s.add(FactRow(job_id=job_id, fact_id=f.id, payload=f.model_dump(mode="json")))

    def facts(self, job_id: str) -> list[Fact]:
        with self.session() as s:
            rows = s.scalars(select(FactRow).where(FactRow.job_id == job_id).order_by(FactRow.fact_id))
            return [Fact.model_validate(r.payload) for r in rows]

    def add_artifact(self, *, job_id: str, kind: str, name: str, uri: str, sha256: str,
                     content_type: str) -> str:
        art_id = new_id("art")
        with self.session() as s:
            s.add(ArtifactRow(id=art_id, job_id=job_id, kind=kind, name=name, uri=uri, sha256=sha256,
                              content_type=content_type))
        return art_id

    def artifacts(self, job_id: str) -> list[ArtifactRow]:
        with self.session() as s:
            return list(s.scalars(select(ArtifactRow).where(ArtifactRow.job_id == job_id)
                                  .order_by(ArtifactRow.created_at)))

    def get_artifact(self, artifact_id: str) -> ArtifactRow | None:
        with self.session() as s:
            return s.get(ArtifactRow, artifact_id)

    def ping(self) -> bool:
        with self.session() as s:
            return s.scalar(select(func.count()).select_from(JobRow).limit(1)) is not None
