"""Blob storage: S3 in prod, local directory in dev/tests.

URIs are ``s3://bucket/key`` or ``local://key``. DuckDB reads S3 URIs
directly (httpfs), so tables never need to be downloaded into the container.
"""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path
from typing import BinaryIO, Protocol

from reportkit.settings import Settings


class BlobStore(Protocol):
    def put_bytes(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str: ...
    def put_file(self, key: str, fileobj: BinaryIO, content_type: str = "application/octet-stream") -> str: ...
    def put_path(self, key: str, path: Path, content_type: str = "application/octet-stream") -> str: ...
    def get_bytes(self, uri: str) -> bytes: ...
    def exists(self, uri: str) -> bool: ...
    def duckdb_path(self, uri: str) -> str: ...
    def presign(self, uri: str, filename: str | None = None) -> str | None: ...
    def local_path(self, uri: str) -> Path | None: ...
    def uri_for(self, key: str) -> str: ...


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_fileobj(f: BinaryIO, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    for block in iter(lambda: f.read(chunk), b""):
        h.update(block)
    f.seek(0)
    return h.hexdigest()


class LocalBlobStore:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def uri_for(self, key: str) -> str:
        return f"local://{key}"

    def _path(self, uri_or_key: str) -> Path:
        key = uri_or_key.removeprefix("local://")
        p = (self.root / key).resolve()
        if self.root not in p.parents and p != self.root:
            raise ValueError("path escapes blob root")
        return p

    def put_bytes(self, key, data, content_type="application/octet-stream"):
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        return self.uri_for(key)

    def put_file(self, key, fileobj, content_type="application/octet-stream"):
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as out:
            shutil.copyfileobj(fileobj, out, 1 << 20)
        return self.uri_for(key)

    def put_path(self, key, path, content_type="application/octet-stream"):
        with open(path, "rb") as f:
            return self.put_file(key, f, content_type)

    def get_bytes(self, uri):
        return self._path(uri).read_bytes()

    def exists(self, uri):
        return self._path(uri).exists()

    def duckdb_path(self, uri):
        return str(self._path(uri))

    def presign(self, uri, filename=None):
        return None  # served by the API directly

    def local_path(self, uri):
        return self._path(uri)


class S3BlobStore:
    def __init__(self, bucket: str, prefix: str, region: str, presign_ttl_s: int = 900):
        import boto3
        from botocore.config import Config

        self.bucket = bucket
        self.prefix = prefix.strip("/")
        self.ttl = presign_ttl_s
        self.s3 = boto3.client("s3", region_name=region, config=Config(retries={"mode": "adaptive"}))

    def _key(self, key: str) -> str:
        return f"{self.prefix}/{key}" if self.prefix else key

    def uri_for(self, key: str) -> str:
        return f"s3://{self.bucket}/{self._key(key)}"

    @staticmethod
    def _split(uri: str) -> tuple[str, str]:
        rest = uri.removeprefix("s3://")
        bucket, _, key = rest.partition("/")
        return bucket, key

    def put_bytes(self, key, data, content_type="application/octet-stream"):
        self.s3.put_object(Bucket=self.bucket, Key=self._key(key), Body=data, ContentType=content_type)
        return self.uri_for(key)

    def put_file(self, key, fileobj, content_type="application/octet-stream"):
        # upload_fileobj streams in multipart chunks; the file never sits in memory
        self.s3.upload_fileobj(fileobj, self.bucket, self._key(key), ExtraArgs={"ContentType": content_type})
        return self.uri_for(key)

    def put_path(self, key, path, content_type="application/octet-stream"):
        self.s3.upload_file(str(path), self.bucket, self._key(key), ExtraArgs={"ContentType": content_type})
        return self.uri_for(key)

    def get_bytes(self, uri):
        b, k = self._split(uri)
        return self.s3.get_object(Bucket=b, Key=k)["Body"].read()

    def exists(self, uri):
        b, k = self._split(uri)
        try:
            self.s3.head_object(Bucket=b, Key=k)
            return True
        except self.s3.exceptions.ClientError:
            return False

    def duckdb_path(self, uri):
        return uri

    def presign(self, uri, filename=None):
        b, k = self._split(uri)
        params = {"Bucket": b, "Key": k}
        if filename:
            params["ResponseContentDisposition"] = f'attachment; filename="{filename}"'
        return self.s3.generate_presigned_url("get_object", Params=params, ExpiresIn=self.ttl)

    def local_path(self, uri):
        return None


def make_blobstore(settings: Settings) -> BlobStore:
    if settings.blob_backend == "s3":
        if not settings.s3_bucket:
            raise ValueError("RK_S3_BUCKET is required when RK_BLOB_BACKEND=s3")
        return S3BlobStore(settings.s3_bucket, settings.s3_prefix, settings.aws_region, settings.presign_ttl_s)
    return LocalBlobStore(settings.local_blob_dir)
