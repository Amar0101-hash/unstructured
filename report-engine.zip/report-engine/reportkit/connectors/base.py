"""Shared helpers for external connectors."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

import pyarrow as pa
import pyarrow.parquet as pq
import sqlglot
from sqlglot import exp


def rewrite_tables(tree: exp.Expression, mapping: dict[str, exp.Expression]) -> exp.Expression:
    """Point catalog names at the real tables, e.g. ``adsl`` ->
    ``clinical_db.adsl_v3`` or ``(SELECT ...) AS adsl``."""
    ctes = {c.alias for c in tree.find_all(exp.CTE)}

    def _sub(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Table) and node.name in mapping and node.name not in ctes:
            target = mapping[node.name].copy()
            alias = node.alias or node.name
            if isinstance(target, exp.Table):
                target.set("alias", exp.TableAlias(this=exp.to_identifier(alias)))
                return target
            return exp.Subquery(this=target, alias=exp.TableAlias(this=exp.to_identifier(alias)))
        return node

    return tree.transform(_sub)


def table_ref(table: str, db: str | None = None) -> exp.Table:
    return exp.Table(this=exp.to_identifier(table), db=exp.to_identifier(db) if db else None)


def parse_select(sql: str, dialect: str) -> exp.Expression:
    return sqlglot.parse_one(sql, read=dialect)


def rows_to_arrow(columns: list[str], rows: Iterable[tuple]) -> pa.Table:
    rows = list(rows)
    data = {c: [r[i] for r in rows] for i, c in enumerate(columns)}
    return pa.table(data)


def stream_to_parquet(path: Path, columns: list[str], batches: Iterable[list[tuple]]) -> int:
    """Write row batches to Parquet without holding the whole result in memory."""
    writer: pq.ParquetWriter | None = None
    n = 0
    try:
        for batch in batches:
            if not batch:
                continue
            table = rows_to_arrow(columns, batch)
            if writer is None:
                writer = pq.ParquetWriter(str(path), table.schema)
            else:
                table = table.cast(writer.schema, safe=False)
            writer.write_table(table)
            n += table.num_rows
    finally:
        if writer is not None:
            writer.close()
    if writer is None:  # empty result: still write a file so the view resolves
        pq.write_table(pa.table({c: pa.array([], pa.string()) for c in columns}), str(path))
    return n


def fingerprint(*parts: Any) -> str:
    return hashlib.sha256(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()
