"""Postgres (RDS) connector via SQLAlchemy.

``connection`` on the source names an env var ``RK_RDS_<NAME>_URL`` holding
the SQLAlchemy URL. On ECS, map it from Secrets Manager in the task
definition's ``secrets`` block so credentials never live in the image or the
database. Use a read-only database role.
"""

from __future__ import annotations

import os
from functools import lru_cache

import pyarrow as pa
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlglot import exp

from reportkit.connectors.base import (
    fingerprint,
    parse_select,
    rewrite_tables,
    rows_to_arrow,
    stream_to_parquet,
    table_ref,
)
from reportkit.models.catalog import ColumnInfo, RdsSource
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore


@lru_cache(maxsize=16)
def _engine(connection: str) -> Engine:
    var = f"RK_RDS_{connection.upper()}_URL"
    url = os.environ.get(var)
    if not url:
        raise RuntimeError(f"RDS connection {connection!r} not configured: set {var}")
    return create_engine(url, pool_pre_ping=True, pool_size=2, max_overflow=2)


class RdsConnector:
    def __init__(self, settings: Settings, blob: BlobStore):
        self.settings = settings
        self.blob = blob

    def _source_expr(self, src: RdsSource) -> exp.Expression:
        if src.query:
            return parse_select(src.query, "postgres")
        return table_ref(src.table or "", src.db_schema)

    def _select_sql(self, src: RdsSource, columns: set[str] | None) -> str:
        cols = ", ".join(f'"{c}"' for c in sorted(columns)) if columns else "*"
        inner = f"({src.query}) AS _src" if src.query else f'"{src.db_schema}"."{src.table}"'
        return f"SELECT {cols} FROM {inner}"

    def engine_version(self, src: RdsSource) -> str:
        with _engine(src.connection).connect() as c:
            return "postgres-" + str(c.execute(text("SHOW server_version")).scalar())

    def describe(self, src: RdsSource) -> tuple[list[ColumnInfo], int | None, str]:
        with _engine(src.connection).connect() as c:
            res = c.execute(text(self._select_sql(src, None) + " LIMIT 0"))
            cols = [ColumnInfo(name=k, type="UNKNOWN") for k in res.keys()]
        return cols, None, fingerprint(src.connection, src.db_schema, src.table, src.query)

    def query(self, duck_sql: str, params: list, mapping: dict[str, RdsSource]) -> pa.Table:
        from reportkit.compute.sql_guard import inline_params  # noqa: PLC0415

        tree = inline_params(duck_sql, params)
        tree = rewrite_tables(tree, {name: self._source_expr(s) for name, s in mapping.items()})
        sql = tree.sql(dialect="postgres")
        conn_name = next(iter(mapping.values())).connection
        with _engine(conn_name).connect() as c:
            c.execute(text("SET TRANSACTION READ ONLY"))
            res = c.execute(text(sql))
            return rows_to_arrow(list(res.keys()), res.fetchall())

    def materialize(self, src: RdsSource, columns: set[str] | None, key: str) -> str:
        """Stream the projected rows into Parquet in batches, upload, return the URI."""
        path = self.settings.scratch_subdir("materialize") / (key.replace("/", "_") + ".parquet")
        with _engine(src.connection).connect().execution_options(stream_results=True) as c:
            res = c.execute(text(self._select_sql(src, columns)))
            cols = list(res.keys())
            stream_to_parquet(path, cols, iter(lambda: res.fetchmany(50_000), []))
        try:
            return self.blob.put_path(key, path, "application/vnd.apache.parquet")
        finally:
            path.unlink(missing_ok=True)
