"""Athena / Glue connector (needs the optional ``awswrangler`` dependency).

Two ways to use a Glue table:
  pushdown     exact aggregates are transpiled to Athena SQL and run there;
               only the (small) result comes back to the container.
  materialize  the needed columns are UNLOADed by Athena straight to S3 as
               Parquet; DuckDB then reads them from S3. No rows pass through
               the container's memory during the copy.
"""

from __future__ import annotations

import uuid

import pyarrow as pa
from sqlglot import exp

from reportkit.connectors.base import fingerprint, parse_select, rewrite_tables, table_ref
from reportkit.models.catalog import AthenaSource, ColumnInfo
from reportkit.settings import Settings


def _wr():
    try:
        import awswrangler as wr  # noqa: PLC0415
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("Athena datasets need `pip install reportkit[aws]` (awswrangler)") from e
    return wr


class AthenaConnector:
    engine_version = "athena-engine-v3"

    def __init__(self, settings: Settings):
        self.settings = settings

    def _source_expr(self, src: AthenaSource) -> exp.Expression:
        if src.query:
            return parse_select(src.query, "athena")
        return table_ref(src.table or "", src.database)

    def describe(self, src: AthenaSource) -> tuple[list[ColumnInfo], int | None, str]:
        wr = _wr()
        if src.table and not src.query:
            types = wr.catalog.get_table_types(database=src.database, table=src.table)
            cols = [ColumnInfo(name=k, type=str(v).upper()) for k, v in (types or {}).items()]
            meta = wr.catalog.get_table_parameters(database=src.database, table=src.table) or {}
            return cols, None, fingerprint(src.database, src.table, meta.get("transient_lastDdlTime"))
        df = wr.athena.read_sql_query(f"SELECT * FROM ({src.query}) LIMIT 0", database=src.database,
                                      workgroup=self.settings.athena_workgroup, ctas_approach=False)
        cols = [ColumnInfo(name=c, type=str(t).upper()) for c, t in df.dtypes.items()]
        return cols, None, fingerprint(src.database, src.query)

    def query(self, duck_sql: str, params: list, mapping: dict[str, AthenaSource]) -> pa.Table:
        from reportkit.compute.sql_guard import inline_params  # noqa: PLC0415

        wr = _wr()
        tree = inline_params(duck_sql, params)
        tree = rewrite_tables(tree, {name: self._source_expr(s) for name, s in mapping.items()})
        database = next(iter(mapping.values())).database
        df = wr.athena.read_sql_query(tree.sql(dialect="athena"), database=database,
                                      workgroup=self.settings.athena_workgroup, ctas_approach=False)
        return pa.Table.from_pandas(df, preserve_index=False)

    def athena_sql(self, duck_sql: str, params: list, mapping: dict[str, AthenaSource]) -> str:
        from reportkit.compute.sql_guard import inline_params  # noqa: PLC0415

        tree = inline_params(duck_sql, params)
        tree = rewrite_tables(tree, {name: self._source_expr(s) for name, s in mapping.items()})
        return tree.sql(dialect="athena")

    def unload(self, src: AthenaSource, columns: set[str] | None) -> str:
        """UNLOAD the needed columns to S3 Parquet; returns a glob DuckDB can read."""
        if not self.settings.athena_unload_prefix:
            raise RuntimeError("RK_ATHENA_UNLOAD_PREFIX must be set to materialise Athena datasets")
        wr = _wr()
        cols = ", ".join(f'"{c}"' for c in sorted(columns)) if columns else "*"
        inner = f"({src.query})" if src.query else f'"{src.database}"."{src.table}"'
        path = f"{self.settings.athena_unload_prefix.rstrip('/')}/{uuid.uuid4().hex}/"
        wr.athena.unload(sql=f"SELECT {cols} FROM {inner}", path=path, database=src.database,
                         workgroup=self.settings.athena_workgroup, file_format="PARQUET")
        return f"{path}*.parquet"
