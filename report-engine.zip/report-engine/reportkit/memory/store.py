"""Postgres (or SQLite) persistence for the memory tiers.

Tables share the metadata of reportkit.storage.repository so one
``create_all`` / one Alembic history covers everything. Every state change on
a long-term item is also written to ``rk_memory_audit``.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Iterable

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
    select,
    update,
)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Mapped, mapped_column

from reportkit.memory.models import (
    BriefVersion,
    Episode,
    MemoryItem,
    Procedure,
    SessionBrief,
    SessionEvent,
)
from reportkit.storage.repository import Base, JsonType, Repository


def now() -> datetime:
    return datetime.now(timezone.utc)


def _id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:20]}"


class SessionRow(Base):
    __tablename__ = "rk_sessions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(256), index=True)
    project_id: Mapped[str | None] = mapped_column(String(128), index=True, nullable=True)
    title: Mapped[str | None] = mapped_column(String(512), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="open")
    last_consolidated_event_id: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SessionEventRow(Base):
    __tablename__ = "rk_session_events"
    __table_args__ = (UniqueConstraint("session_id", "seq", name="uq_rk_session_events_seq"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(64), index=True)
    seq: Mapped[int] = mapped_column(Integer)
    kind: Mapped[str] = mapped_column(String(32))
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str] = mapped_column(Text)
    ref: Mapped[dict] = mapped_column(JsonType, default=dict)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class SessionBriefRow(Base):
    __tablename__ = "rk_session_briefs"
    session_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    covers_through_event_id: Mapped[int] = mapped_column(Integer)
    brief: Mapped[dict] = mapped_column(JsonType)
    method: Mapped[str] = mapped_column(String(16))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class EpisodeRow(Base):
    __tablename__ = "rk_episodes"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    kind: Mapped[str] = mapped_column(String(16))
    user_id: Mapped[str | None] = mapped_column(String(256), nullable=True)
    project_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    template_key: Mapped[str | None] = mapped_column(String(128), nullable=True)
    session_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    job_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    title: Mapped[str] = mapped_column(String(512))
    summary: Mapped[str] = mapped_column(Text)
    outcome: Mapped[str] = mapped_column(String(64))
    importance: Mapped[float] = mapped_column(Float)
    feedback: Mapped[list] = mapped_column(JsonType, default=list)
    refs: Mapped[dict] = mapped_column(JsonType, default=dict)
    embedding: Mapped[list | None] = mapped_column(JsonType, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class MemoryItemRow(Base):
    __tablename__ = "rk_memory_items"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)
    kind: Mapped[str] = mapped_column(String(32))
    scope_type: Mapped[str] = mapped_column(String(16))
    scope_id: Mapped[str] = mapped_column(String(256))
    content: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16))
    source: Mapped[str] = mapped_column(String(32))
    source_refs: Mapped[dict] = mapped_column(JsonType, default=dict)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    supersedes: Mapped[str | None] = mapped_column(String(96), nullable=True)
    possible_duplicate_of: Mapped[str | None] = mapped_column(String(96), nullable=True)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    valid_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(256), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    embedding: Mapped[list | None] = mapped_column(JsonType, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class MemoryAuditRow(Base):
    __tablename__ = "rk_memory_audit"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    item_id: Mapped[str] = mapped_column(String(64), index=True)
    version: Mapped[int] = mapped_column(Integer)
    action: Mapped[str] = mapped_column(String(32))  # proposed|created|approved|rejected|edited|superseded|retired|erased
    actor: Mapped[str | None] = mapped_column(String(256), nullable=True)
    detail: Mapped[dict | None] = mapped_column(JsonType, nullable=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class ProcedureRow(Base):
    __tablename__ = "rk_procedures"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    template_key: Mapped[str] = mapped_column(String(128))
    slot_id: Mapped[str] = mapped_column(String(64))
    binding: Mapped[dict] = mapped_column(JsonType)
    job_id: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


Index("ix_rk_memory_items_scope", MemoryItemRow.scope_type, MemoryItemRow.scope_id, MemoryItemRow.status,
      MemoryItemRow.is_current)
Index("ix_rk_episodes_scope", EpisodeRow.project_id, EpisodeRow.user_id, EpisodeRow.created_at)
Index("ix_rk_procedures_slot", ProcedureRow.template_key, ProcedureRow.slot_id, ProcedureRow.status)

ERASED = "[erased]"


def _event(r: SessionEventRow) -> SessionEvent:
    return SessionEvent(id=r.id, session_id=r.session_id, seq=r.seq, kind=r.kind, role=r.role, content=r.content,
                        ref=r.ref or {}, created_at=r.created_at, created_by=r.created_by)


def _item(r: MemoryItemRow) -> MemoryItem:
    return MemoryItem(id=r.id, version=r.version, kind=r.kind, scope_type=r.scope_type, scope_id=r.scope_id,
                      content=r.content, status=r.status, source=r.source, source_refs=r.source_refs or {},
                      confidence=r.confidence, supersedes=r.supersedes, possible_duplicate_of=r.possible_duplicate_of,
                      valid_from=r.valid_from, valid_to=r.valid_to, created_at=r.created_at, created_by=r.created_by,
                      reviewed_by=r.reviewed_by, reviewed_at=r.reviewed_at, embedding=r.embedding)


def _episode(r: EpisodeRow) -> Episode:
    return Episode(id=r.id, kind=r.kind, user_id=r.user_id, project_id=r.project_id, template_key=r.template_key,
                   session_id=r.session_id, job_id=r.job_id, title=r.title, summary=r.summary, outcome=r.outcome,
                   importance=r.importance, feedback=r.feedback or [], refs=r.refs or {}, created_at=r.created_at,
                   embedding=r.embedding)


class MemoryStore:
    def __init__(self, repo: Repository):
        self.repo = repo

    # ---- sessions (working memory) ----------------------------------------------
    def create_session(self, user_id: str, project_id: str | None, title: str | None) -> SessionRow:
        row = SessionRow(id=_id("ses"), user_id=user_id, project_id=project_id, title=title)
        with self.repo.session() as s:
            s.add(row)
        return row

    def get_session(self, session_id: str) -> SessionRow | None:
        with self.repo.session() as s:
            return s.get(SessionRow, session_id)

    def close_session(self, session_id: str) -> None:
        with self.repo.session() as s:
            s.execute(update(SessionRow).where(SessionRow.id == session_id).values(status="closed", closed_at=now()))

    def mark_consolidated(self, session_id: str, through_event_id: int) -> None:
        with self.repo.session() as s:
            s.execute(update(SessionRow).where(SessionRow.id == session_id)
                      .values(last_consolidated_event_id=through_event_id))

    def append_event(self, session_id: str, kind: str, role: str, content: str, ref: dict | None = None,
                     created_by: str | None = None) -> SessionEvent:
        for _ in range(5):  # seq is unique per session; retry on a concurrent append
            try:
                with self.repo.session() as s:
                    seq = (s.scalar(select(func.max(SessionEventRow.seq))
                                    .where(SessionEventRow.session_id == session_id)) or 0) + 1
                    row = SessionEventRow(session_id=session_id, seq=seq, kind=kind, role=role, content=content,
                                          ref=ref or {}, created_by=created_by)
                    s.add(row)
                    s.flush()
                    return _event(row)
            except IntegrityError:
                continue
        raise RuntimeError("could not append session event")

    def events(self, session_id: str, after_id: int = 0, limit: int = 1000) -> list[SessionEvent]:
        with self.repo.session() as s:
            rows = s.scalars(select(SessionEventRow).where(SessionEventRow.session_id == session_id,
                                                           SessionEventRow.id > after_id)
                             .order_by(SessionEventRow.id).limit(limit))
            return [_event(r) for r in rows]

    def latest_brief(self, session_id: str) -> BriefVersion | None:
        with self.repo.session() as s:
            r = s.scalar(select(SessionBriefRow).where(SessionBriefRow.session_id == session_id)
                         .order_by(SessionBriefRow.version.desc()).limit(1))
            if r is None:
                return None
            return BriefVersion(session_id=r.session_id, version=r.version,
                                covers_through_event_id=r.covers_through_event_id,
                                brief=SessionBrief.model_validate(r.brief), created_at=r.created_at, method=r.method)

    def add_brief(self, session_id: str, brief: SessionBrief, covers_through: int, method: str) -> BriefVersion:
        prev = self.latest_brief(session_id)
        version = (prev.version if prev else 0) + 1
        with self.repo.session() as s:
            s.add(SessionBriefRow(session_id=session_id, version=version, covers_through_event_id=covers_through,
                                  brief=brief.model_dump(mode="json"), method=method))
        return BriefVersion(session_id=session_id, version=version, covers_through_event_id=covers_through,
                            brief=brief, created_at=now(), method=method)

    # ---- episodes ---------------------------------------------------------------
    def add_episode(self, ep: Episode) -> Episode:
        with self.repo.session() as s:
            s.add(EpisodeRow(**ep.model_dump(exclude={"created_at"}), created_at=ep.created_at))
        return ep

    def episodes(self, *, user_id: str | None = None, project_id: str | None = None,
                 template_key: str | None = None, limit: int = 500) -> list[Episode]:
        """Candidates for ranking: the user's own episodes plus the project's."""
        with self.repo.session() as s:
            q = select(EpisodeRow)
            conds = []
            if user_id:
                conds.append(EpisodeRow.user_id == user_id)
            if project_id:
                conds.append(EpisodeRow.project_id == project_id)
            if template_key:
                conds.append(EpisodeRow.template_key == template_key)
            if conds:
                from sqlalchemy import or_  # noqa: PLC0415

                q = q.where(or_(*conds))
            rows = s.scalars(q.order_by(EpisodeRow.created_at.desc()).limit(limit))
            return [_episode(r) for r in rows]

    # ---- long-term items (semantic) -------------------------------------------------
    def _audit(self, s, item_id: str, version: int, action: str, actor: str | None, detail: dict | None = None):
        s.add(MemoryAuditRow(item_id=item_id, version=version, action=action, actor=actor, detail=detail))

    def add_item(self, item: MemoryItem) -> MemoryItem:
        with self.repo.session() as s:
            s.add(MemoryItemRow(**item.model_dump(exclude={"created_at"}), is_current=True, created_at=item.created_at))
            self._audit(s, item.id, item.version, "proposed" if item.status == "proposed" else "created",
                        item.created_by, {"source": item.source})
        return item

    def get_item(self, item_id: str) -> MemoryItem | None:
        with self.repo.session() as s:
            r = s.scalar(select(MemoryItemRow).where(MemoryItemRow.id == item_id, MemoryItemRow.is_current.is_(True)))
            return _item(r) if r else None

    def history(self, item_id: str) -> tuple[list[MemoryItem], list[dict]]:
        with self.repo.session() as s:
            versions = [_item(r) for r in s.scalars(select(MemoryItemRow).where(MemoryItemRow.id == item_id)
                                                     .order_by(MemoryItemRow.version))]
            audit = [{"version": a.version, "action": a.action, "actor": a.actor, "detail": a.detail,
                      "at": a.at.isoformat()}
                     for a in s.scalars(select(MemoryAuditRow).where(MemoryAuditRow.item_id == item_id)
                                        .order_by(MemoryAuditRow.id))]
        return versions, audit

    def items(self, *, scopes: Iterable[tuple[str, str]] | None = None, statuses: Iterable[str] = ("active",),
              limit: int = 2000) -> list[MemoryItem]:
        from sqlalchemy import and_, or_  # noqa: PLC0415

        with self.repo.session() as s:
            q = select(MemoryItemRow).where(MemoryItemRow.is_current.is_(True),
                                            MemoryItemRow.status.in_(list(statuses)))
            scopes = list(scopes or [])
            if scopes:
                q = q.where(or_(*[and_(MemoryItemRow.scope_type == t, MemoryItemRow.scope_id == i) for t, i in scopes]))
            rows = s.scalars(q.order_by(MemoryItemRow.created_at.desc()).limit(limit))
            return [_item(r) for r in rows]

    def set_status(self, item_id: str, status: str, actor: str | None, *, detail: dict | None = None,
                   valid_to: datetime | None = None, reviewed: bool = False) -> MemoryItem:
        with self.repo.session() as s:
            r = s.scalar(select(MemoryItemRow).where(MemoryItemRow.id == item_id, MemoryItemRow.is_current.is_(True)))
            if r is None:
                raise KeyError(item_id)
            r.status = status
            if valid_to is not None:
                r.valid_to = valid_to
            if reviewed:
                r.reviewed_by, r.reviewed_at = actor, now()
            self._audit(s, r.id, r.version, status if status != "active" else "approved", actor, detail)
            s.flush()
            return _item(r)

    def new_version(self, item_id: str, *, content: str, actor: str | None, status: str = "active",
                    detail: dict | None = None) -> MemoryItem:
        """Edit = a new version. The old version keeps its content, gets valid_to."""
        with self.repo.session() as s:
            old = s.scalar(select(MemoryItemRow).where(MemoryItemRow.id == item_id, MemoryItemRow.is_current.is_(True)))
            if old is None:
                raise KeyError(item_id)
            old.is_current = False
            old.valid_to = now()
            if old.status == "active":
                old.status = "superseded"
            new = MemoryItemRow(
                id=old.id, version=old.version + 1, is_current=True, kind=old.kind, scope_type=old.scope_type,
                scope_id=old.scope_id, content=content, status=status, source=old.source,
                source_refs=old.source_refs, confidence=old.confidence, supersedes=f"{old.id}@v{old.version}",
                valid_from=now(), created_by=actor, reviewed_by=actor, reviewed_at=now(), embedding=None)
            s.add(new)
            self._audit(s, old.id, new.version, "edited", actor, detail)
            s.flush()
            return _item(new)

    def erase(self, item_id: str, actor: str | None, reason: str) -> None:
        """Tombstone every version's content (right to erasure); the audit trail stays."""
        with self.repo.session() as s:
            rows = list(s.scalars(select(MemoryItemRow).where(MemoryItemRow.id == item_id)))
            if not rows:
                raise KeyError(item_id)
            for r in rows:
                r.content, r.embedding = ERASED, None
                if r.is_current:
                    r.status, r.valid_to = "erased", now()
            cur = max(rows, key=lambda r: r.version)
            self._audit(s, item_id, cur.version, "erased", actor, {"reason": reason})

    def set_embedding(self, table: str, key: tuple, embedding: list[float]) -> None:
        with self.repo.session() as s:
            if table == "item":
                s.execute(update(MemoryItemRow).where(MemoryItemRow.id == key[0], MemoryItemRow.version == key[1])
                          .values(embedding=embedding))
            else:
                s.execute(update(EpisodeRow).where(EpisodeRow.id == key[0]).values(embedding=embedding))

    # ---- procedures ---------------------------------------------------------------
    def record_procedure(self, template_key: str, slot_id: str, binding: dict, job_id: str) -> Procedure:
        p = Procedure(id=_id("proc"), template_key=template_key, slot_id=slot_id, binding=binding, job_id=job_id,
                      created_at=now())
        with self.repo.session() as s:
            s.execute(update(ProcedureRow).where(ProcedureRow.template_key == template_key,
                                                 ProcedureRow.slot_id == slot_id, ProcedureRow.status == "active")
                      .values(status="retired"))
            s.add(ProcedureRow(**p.model_dump(exclude={"created_at"}), created_at=p.created_at))
        return p

    def procedure(self, template_key: str, slot_id: str) -> Procedure | None:
        with self.repo.session() as s:
            r = s.scalar(select(ProcedureRow).where(ProcedureRow.template_key == template_key,
                                                    ProcedureRow.slot_id == slot_id, ProcedureRow.status == "active")
                         .order_by(ProcedureRow.created_at.desc()).limit(1))
            return Procedure(id=r.id, template_key=r.template_key, slot_id=r.slot_id, binding=r.binding,
                             job_id=r.job_id, created_at=r.created_at, status=r.status) if r else None

    def procedures(self, template_key: str) -> list[Procedure]:
        with self.repo.session() as s:
            rows = s.scalars(select(ProcedureRow).where(ProcedureRow.template_key == template_key,
                                                        ProcedureRow.status == "active").order_by(ProcedureRow.slot_id))
            return [Procedure(id=r.id, template_key=r.template_key, slot_id=r.slot_id, binding=r.binding,
                              job_id=r.job_id, created_at=r.created_at, status=r.status) for r in rows]
