"""Memory tiers (CoALA-style): working, episodic, semantic, procedural.

Design rules (from the agent-memory literature, tightened for GxP):
- Raw records are never rewritten: session events are append-only; briefs,
  items and procedures are versioned.
- User statements outrank model inferences: the LLM may only *propose*
  long-term items, each citing the user events it came from; a person
  approves them (configurable per kind).
- Nothing is hard-deleted: contradicted items are superseded (valid_to set),
  retired items stay for audit, "erase" tombstones the content.
- Every item injected into a prompt is recorded with its id and version.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

EventKind = Literal["user_message", "assistant_message", "feedback", "job_started", "job_finished", "note"]
ItemKind = Literal["preference", "style_rule", "glossary", "fact", "correction"]
ScopeType = Literal["user", "project", "template", "org"]
ItemStatus = Literal["proposed", "active", "rejected", "superseded", "retired", "erased"]
ItemSource = Literal["user_authored", "consolidation"]


class SessionEvent(BaseModel):
    id: int
    session_id: str
    seq: int
    kind: EventKind
    role: Literal["user", "assistant", "system"]
    content: str
    ref: dict = Field(default_factory=dict)  # e.g. {"job_id": ..., "slot_id": ...}
    created_at: datetime
    created_by: str | None = None


class Decision(BaseModel):
    text: str
    event_ids: list[int] = Field(default_factory=list)


class SessionBrief(BaseModel):
    """Rolling summary of a session's working memory (versioned)."""

    goals: list[str] = Field(default_factory=list)
    decisions: list[Decision] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    open_items: list[str] = Field(default_factory=list)
    summary: str = ""


class BriefVersion(BaseModel):
    session_id: str
    version: int
    covers_through_event_id: int
    brief: SessionBrief
    created_at: datetime
    method: Literal["llm", "extractive"]


class Episode(BaseModel):
    id: str
    kind: Literal["job", "session"]
    user_id: str | None
    project_id: str | None
    template_key: str | None
    session_id: str | None
    job_id: str | None
    title: str
    summary: str
    outcome: str
    importance: float  # 0..1, computed deterministically
    feedback: list[str] = Field(default_factory=list)  # user corrections during the episode
    refs: dict = Field(default_factory=dict)
    created_at: datetime
    embedding: list[float] | None = None


class MemoryItem(BaseModel):
    id: str  # stable across versions
    version: int
    kind: ItemKind
    scope_type: ScopeType
    scope_id: str
    content: str
    status: ItemStatus
    source: ItemSource
    source_refs: dict = Field(default_factory=dict)  # {"event_ids": [...], "episode_id": ...}
    confidence: float = 1.0
    supersedes: str | None = None  # "id@version" this one replaced
    possible_duplicate_of: str | None = None
    valid_from: datetime
    valid_to: datetime | None = None
    created_at: datetime
    created_by: str | None
    reviewed_by: str | None = None
    reviewed_at: datetime | None = None
    embedding: list[float] | None = None

    @property
    def ref(self) -> str:
        return f"{self.id}@v{self.version}"


class Procedure(BaseModel):
    """A plan that worked: the accepted SlotBinding for one template slot."""

    id: str
    template_key: str
    slot_id: str
    binding: dict
    job_id: str
    created_at: datetime
    status: Literal["active", "retired"] = "active"


class MemoryRef(BaseModel):
    tier: Literal["working", "episodic", "semantic", "procedural"]
    ref: str  # item id@version, episode id, brief session@version, procedure id
    score: float | None = None


class ContextPack(BaseModel):
    """What the context manager hands to a prompt, plus the audit trail."""

    working: str = ""
    semantic: str = ""
    episodic: str = ""
    procedural: str = ""
    refs: list[MemoryRef] = Field(default_factory=list)
    tokens: dict[str, int] = Field(default_factory=dict)
    vocabulary: str = ""  # approved memory text, allowed in the writer's number check

    def text(self) -> str:
        parts = [
            ("CURRENT SESSION", self.working),
            ("APPROVED MEMORY (house rules, preferences, glossary, facts - follow these)", self.semantic),
            ("RELEVANT PAST WORK (for context; do not copy numbers)", self.episodic),
        ]
        return "\n\n".join(f"{h}\n{b}" for h, b in parts if b.strip())

    def is_empty(self) -> bool:
        return not any([self.working, self.semantic, self.episodic, self.procedural])
