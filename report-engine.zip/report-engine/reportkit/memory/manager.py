"""Context manager: reads all four memory tiers into a token-budgeted pack,
and writes new memories after work is done.

Read path (every job / slot)
  working     latest session brief + recent events verbatim; compacts first
              when unsummarised history exceeds the budget
  semantic    active items for user, project, template and org scopes
  episodic    top-k past episodes by relevance + recency + importance
  procedural  last accepted plan for this template slot (planner only)

Write path (after a job, or when a session closes)
  episode     deterministic record of the job: inputs, outcome, issues, feedback
  procedures  bindings of slots that finished without issues
  proposals   LLM extracts candidate long-term items from USER events only;
              each must cite those events; people approve them
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from pydantic import BaseModel, Field

from reportkit.llm.client import LLMClient, LLMError
from reportkit.llm.retrieval import tokens
from reportkit.memory.embeddings import Embedder
from reportkit.memory.models import (
    BriefVersion,
    ContextPack,
    Decision,
    Episode,
    ItemKind,
    MemoryItem,
    MemoryRef,
    SessionBrief,
    SessionEvent,
)
from reportkit.memory.ranking import Weights, bm25, rank
from reportkit.memory.store import MemoryStore
from reportkit.settings import Settings

log = logging.getLogger(__name__)

SCOPE_ORDER = {"template": 0, "project": 1, "user": 2, "org": 3}  # most specific first


def est_tokens(text: str) -> int:
    return (len(text) + 3) // 4


def _now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class ContextRequest:
    user_id: str
    session_id: str | None = None
    project_id: str | None = None
    template_key: str | None = None
    query: str = ""

    def scopes(self, org_id: str) -> list[tuple[str, str]]:
        out = [("user", self.user_id), ("org", org_id)]
        if self.project_id:
            out.append(("project", self.project_id))
        if self.template_key:
            out.append(("template", self.template_key))
        return out


# ---- LLM schemas ----------------------------------------------------------------

COMPACT_SYSTEM = """You maintain the working-memory brief of a report-authoring session.
Merge the previous brief with the new events. Keep every decision that still holds; drop ones the
user reversed. Each decision must cite the event ids (numbers in [e..]) it comes from.
Keep it short: goals, decisions, constraints, open items, and a 2-4 sentence summary.
Return JSON matching the schema: {"goals": [], "decisions": [{"text": "", "event_ids": []}],
"constraints": [], "open_items": [], "summary": ""}"""


class Proposal(BaseModel):
    kind: ItemKind
    scope_type: str = Field(pattern="^(user|project|template)$")
    content: str = Field(max_length=400)
    event_ids: list[int] = Field(min_length=1)
    confidence: float = Field(0.8, ge=0, le=1)
    replaces_item_id: str | None = None


class ProposalSet(BaseModel):
    items: list[Proposal] = Field(default_factory=list)


CONSOLIDATE_SYSTEM = """You extract durable memories from a report-authoring session, for human review.

Only propose something the USER stated or corrected (events marked "user"), that will still matter in
future sessions: a preference about output, a house style rule, a glossary term, a stable fact about the
project, or a correction of a previous mistake. Do not propose one-off instructions for this report,
numbers or results, or anything inferred from assistant messages.
- kind: preference | style_rule | glossary | fact | correction
- scope_type: user (personal preference), project (applies to this study/project), template (only for
  this template)
- content: one self-contained sentence, written as an instruction or fact
- event_ids: the user events it comes from
- replaces_item_id: the id of an existing memory this one contradicts or updates, if any
Propose nothing if nothing qualifies. Return {"items": [...]}"""


class MemoryManager:
    def __init__(self, settings: Settings, store: MemoryStore, embedder: Embedder | None = None,
                 weights: Weights | None = None):
        self.settings, self.store, self.embedder = settings, store, embedder
        self.weights = weights or Weights(half_life_days=settings.memory_half_life_days)

    # ======================= READ PATH ==============================================
    def build(self, req: ContextRequest, llm: LLMClient | None, budget_tokens: int | None = None) -> ContextPack:
        budget = budget_tokens or self.settings.memory_context_tokens
        pack = ContextPack()
        shares = {"working": 0.4, "semantic": 0.35, "episodic": 0.25}
        left = budget
        if req.session_id:
            pack.working, refs = self.working(req.session_id, int(budget * shares["working"]), llm)
            pack.refs += refs
            left -= est_tokens(pack.working)
        sem_budget = max(int(budget * shares["semantic"]), left - int(budget * shares["episodic"]))
        pack.semantic, refs, pack.vocabulary = self.semantic(req, sem_budget)
        pack.refs += refs
        left -= est_tokens(pack.semantic)
        pack.episodic, refs = self.episodic(req, max(0, left))
        pack.refs += refs
        pack.tokens = {k: est_tokens(getattr(pack, k)) for k in ("working", "semantic", "episodic")}
        return pack

    # ---- working ------------------------------------------------------------------
    def working(self, session_id: str, budget: int, llm: LLMClient | None) -> tuple[str, list[MemoryRef]]:
        brief = self.store.latest_brief(session_id)
        tail = self.store.events(session_id, after_id=brief.covers_through_event_id if brief else 0)
        if tail and est_tokens(self._render_events(tail)) > self.settings.memory_compact_after_tokens:
            brief = self.compact(session_id, llm)
            tail = self.store.events(session_id, after_id=brief.covers_through_event_id)
        keep = tail[-self.settings.memory_keep_recent_events:] if brief else tail
        parts, refs = [], []
        if brief:
            parts.append(self._render_brief(brief.brief))
            refs.append(MemoryRef(tier="working", ref=f"{session_id}@brief-v{brief.version}"))
        recent = self._render_events(keep)
        while keep and est_tokens("\n".join(parts + [recent])) > budget:  # trim oldest first
            keep = keep[1:]
            recent = self._render_events(keep)
        if recent:
            parts.append("Recent events:\n" + recent)
            refs += [MemoryRef(tier="working", ref=f"{session_id}#e{e.id}") for e in keep]
        return "\n".join(parts), refs

    @staticmethod
    def _render_events(events: list[SessionEvent]) -> str:
        return "\n".join(f"[e{e.id} {e.role} {e.kind}] {' '.join(e.content.split())[:1500]}" for e in events)

    @staticmethod
    def _render_brief(b: SessionBrief) -> str:
        lines = []
        if b.summary:
            lines.append(f"Summary: {b.summary}")
        for label, xs in (("Goals", b.goals), ("Constraints", b.constraints), ("Open items", b.open_items)):
            if xs:
                lines.append(f"{label}: " + "; ".join(xs))
        if b.decisions:
            lines.append("Decisions: " + "; ".join(f"{d.text} (e{', e'.join(map(str, d.event_ids))})"
                                                    for d in b.decisions))
        return "\n".join(lines)

    def compact(self, session_id: str, llm: LLMClient | None) -> BriefVersion:
        prev = self.store.latest_brief(session_id)
        events = self.store.events(session_id, after_id=prev.covers_through_event_id if prev else 0)
        if not events:
            return prev  # type: ignore[return-value]
        through = events[-1].id
        valid_ids = {e.id for e in events} | ({i for d in prev.brief.decisions for i in d.event_ids} if prev else set())
        if llm is not None:
            user = (f"PREVIOUS BRIEF\n{self._render_brief(prev.brief) if prev else '(none)'}\n\n"
                    f"NEW EVENTS\n{self._render_events(events)}")

            def check(obj) -> list[str]:
                b: SessionBrief = obj
                return [f"decision cites unknown event e{i}" for d in b.decisions for i in d.event_ids
                        if i not in valid_ids]

            try:
                brief = llm.complete_json(system=COMPACT_SYSTEM, user=user, schema=SessionBrief,
                                          purpose=f"compact:{session_id}", check=check)
                return self.store.add_brief(session_id, brief, through, "llm")
            except LLMError as e:
                log.warning("brief compaction failed for %s, using extractive brief: %s", session_id, e)
        # Extractive fallback: keep prior decisions, add user feedback verbatim as decisions.
        base = prev.brief.model_copy(deep=True) if prev else SessionBrief()
        for e in events:
            if e.role == "user" and e.kind in ("feedback", "user_message"):
                base.decisions.append(Decision(text=" ".join(e.content.split())[:300], event_ids=[e.id]))
        base.decisions = base.decisions[-20:]
        return self.store.add_brief(session_id, base, through, "extractive")

    # ---- semantic -----------------------------------------------------------------
    def semantic(self, req: ContextRequest, budget: int) -> tuple[str, list[MemoryRef], str]:
        items = self.store.items(scopes=req.scopes(self.settings.org_id), statuses=("active",))
        if not items:
            return "", [], ""
        items.sort(key=lambda i: (SCOPE_ORDER[i.scope_type], i.kind, i.created_at))
        lines = [self._item_line(i) for i in items]
        chosen = list(range(len(items)))
        if est_tokens("\n".join(lines)) > budget:  # over budget: keep the most relevant
            scores = rank(req.query, [i.content for i in items], [i.created_at for i in items],
                          [i.confidence for i in items], *self._query_vectors(req.query, items), w=self.weights)
            chosen, used = [], 0
            for idx in sorted(range(len(items)), key=lambda k: -scores[k]):
                t = est_tokens(lines[idx])
                if used + t > budget:
                    continue
                chosen.append(idx)
                used += t
            chosen.sort()
        text = "\n".join(lines[k] for k in chosen)
        refs = [MemoryRef(tier="semantic", ref=items[k].ref) for k in chosen]
        return text, refs, "\n".join(items[k].content for k in chosen)

    @staticmethod
    def _item_line(i: MemoryItem) -> str:
        return f"- [{i.kind}, {i.scope_type}] {i.content} ({i.ref})"

    def _query_vectors(self, query: str, rows) -> tuple[list | None, list | None]:
        if self.embedder is None or not query:
            return None, None
        q = self.embedder.embed([query])
        return ([r.embedding for r in rows], q[0]) if q else (None, None)

    # ---- episodic -----------------------------------------------------------------
    def episodic(self, req: ContextRequest, budget: int) -> tuple[str, list[MemoryRef]]:
        if budget <= 0:
            return "", []
        cands = [e for e in self.store.episodes(user_id=req.user_id, project_id=req.project_id,
                                                template_key=req.template_key)
                 if e.user_id == req.user_id or (req.project_id and e.project_id == req.project_id)]
        if not cands:
            return "", []
        texts = [f"{e.title} {e.summary} {' '.join(e.feedback)}" for e in cands]
        scores = rank(req.query, texts, [e.created_at for e in cands], [e.importance for e in cands],
                      *self._query_vectors(req.query, cands), w=self.weights)
        order = sorted(range(len(cands)), key=lambda k: -scores[k])[: self.settings.memory_episodes_k]
        lines, refs, used = [], [], 0
        for k in order:
            e = cands[k]
            # Raw feedback from other sessions is NOT shown: unreviewed corrections must not act as
            # rules outside their own session. They reach future work only as approved items.
            line = f"- {e.created_at:%Y-%m-%d} {e.title} [{e.outcome}]: {e.summary}"
            if used + est_tokens(line) > budget:
                break
            lines.append(line)
            refs.append(MemoryRef(tier="episodic", ref=e.id, score=round(scores[k], 4)))
            used += est_tokens(line)
        return "\n".join(lines), refs

    # ---- procedural ---------------------------------------------------------------
    def procedure_text(self, template_key: str | None, slot_id: str) -> tuple[str, MemoryRef | None]:
        if not template_key:
            return "", None
        p = self.store.procedure(template_key, slot_id)
        if p is None:
            return "", None
        return json.dumps(p.binding, separators=(",", ":")), MemoryRef(tier="procedural", ref=p.id)

    # ======================= WRITE PATH =============================================
    def _embed_one(self, text: str) -> list[float] | None:
        if self.embedder is None:
            return None
        out = self.embedder.embed([text])
        return out[0] if out else None

    def record_job_episode(self, *, job_id: str, user_id: str | None, project_id: str | None,
                           template_key: str | None, session_id: str | None, title: str, n_slots: int,
                           n_facts: int, issues: list, inputs: list[str]) -> Episode:
        feedback = []
        if session_id:
            feedback = [" ".join(e.content.split())[:300] for e in self.store.events(session_id)
                        if e.role == "user" and e.kind == "feedback"][-5:]
        errors = [i for i in issues if i.severity == "error"]
        outcome = "succeeded_with_issues" if errors else "succeeded"
        codes = sorted({i.code for i in issues})
        summary = (f"Generated '{title}' from {len(inputs)} input file(s) ({', '.join(inputs[:4])}): "
                   f"{n_slots} slots, {n_facts} computed values"
                   + (f"; issues: {', '.join(codes)}" if codes else "; no issues") + ".")
        importance = min(1.0, 0.3 + 0.1 * len(feedback) + (0.2 if errors else 0.0))
        ep = Episode(id=f"epi_{uuid.uuid4().hex[:20]}", kind="job", user_id=user_id, project_id=project_id,
                     template_key=template_key, session_id=session_id, job_id=job_id, title=title, summary=summary,
                     outcome=outcome, importance=importance, feedback=feedback,
                     refs={"job_id": job_id, "issue_codes": codes}, created_at=_now())
        ep.embedding = self._embed_one(f"{title} {summary} {' '.join(feedback)}")
        return self.store.add_episode(ep)

    def record_session_episode(self, session_id: str, user_id: str, project_id: str | None,
                               llm: LLMClient | None) -> Episode | None:
        events = self.store.events(session_id)
        if not events:
            return None
        brief = self.compact(session_id, llm)
        b = brief.brief
        feedback = [" ".join(e.content.split())[:300] for e in events if e.role == "user" and e.kind == "feedback"]
        title = (self.store.get_session(session_id).title or f"Session {session_id}")
        summary = b.summary or "; ".join(d.text for d in b.decisions[:5]) or "Session without decisions."
        ep = Episode(id=f"epi_{uuid.uuid4().hex[:20]}", kind="session", user_id=user_id, project_id=project_id,
                     template_key=None, session_id=session_id, job_id=None, title=title, summary=summary,
                     outcome="closed", importance=min(1.0, 0.2 + 0.1 * len(feedback)), feedback=feedback[-5:],
                     refs={"brief": f"{session_id}@brief-v{brief.version}"}, created_at=_now())
        ep.embedding = self._embed_one(f"{title} {summary}")
        return self.store.add_episode(ep)

    def record_procedures(self, template_key: str, bindings: dict[str, dict], job_id: str) -> list[str]:
        return [self.store.record_procedure(template_key, slot_id, b, job_id).id for slot_id, b in bindings.items()]

    # ---- long-term items -------------------------------------------------------------
    def _duplicate_of(self, content: str, scope_type: str, scope_id: str) -> MemoryItem | None:
        existing = self.store.items(scopes=[(scope_type, scope_id)], statuses=("active", "proposed"))
        if not existing:
            return None
        sims = bm25(content, [e.content for e in existing])
        a = set(tokens(content))
        for e, s in sorted(zip(existing, sims), key=lambda x: -x[1]):
            b = set(tokens(e.content))
            jacc = len(a & b) / len(a | b) if a | b else 0
            if s >= 0.99 and jacc >= 0.6:
                return e
        return None

    def remember(self, *, kind: ItemKind, scope_type: str, scope_id: str, content: str, actor: str,
                 event_ids: list[int] | None = None) -> MemoryItem:
        """User-authored: active immediately (the user is the reviewer)."""
        dup = self._duplicate_of(content, scope_type, scope_id)
        item = MemoryItem(id=f"mem_{uuid.uuid4().hex[:20]}", version=1, kind=kind, scope_type=scope_type,
                          scope_id=scope_id, content=content.strip(), status="active", source="user_authored",
                          source_refs={"event_ids": event_ids or []}, confidence=1.0,
                          possible_duplicate_of=dup.ref if dup else None, valid_from=_now(), created_at=_now(),
                          created_by=actor, reviewed_by=actor, reviewed_at=_now(),
                          embedding=self._embed_one(content))
        return self.store.add_item(item)

    def consolidate(self, session_id: str, llm: LLMClient, *, user_id: str, project_id: str | None,
                    template_key: str | None, episode_id: str | None = None) -> list[MemoryItem]:
        """Propose long-term items from the user's own words since the last consolidation."""
        sess = self.store.get_session(session_id)
        events = self.store.events(session_id, after_id=sess.last_consolidated_event_id if sess else 0)
        user_events = [e for e in events if e.role == "user" and e.kind in ("user_message", "feedback")]
        if not user_events:
            return []
        scope_ids = {"user": user_id, "project": project_id, "template": template_key}
        existing = self.store.items(scopes=[(t, i) for t, i in scope_ids.items() if i], statuses=("active",))
        user_ids = {e.id for e in user_events}
        existing_ids = {i.id for i in existing}
        prompt = (f"SESSION EVENTS\n{self._render_events(events)}\n\n"
                  f"EXISTING MEMORIES\n" + ("\n".join(f"- {i.id}: [{i.kind}, {i.scope_type}] {i.content}"
                                                     for i in existing) or "(none)") +
                  f"\n\nAvailable scopes: user{', project' if project_id else ''}{', template' if template_key else ''}")

        def check(obj) -> list[str]:
            ps: ProposalSet = obj
            errs = []
            for n, p in enumerate(ps.items, 1):
                bad = [i for i in p.event_ids if i not in user_ids]
                if bad:
                    errs.append(f"item {n}: event ids {bad} are not user events; cite only {sorted(user_ids)}")
                if scope_ids.get(p.scope_type) is None:
                    errs.append(f"item {n}: scope {p.scope_type} is not available")
                if p.replaces_item_id and p.replaces_item_id not in existing_ids:
                    errs.append(f"item {n}: unknown replaces_item_id {p.replaces_item_id}")
            return errs

        try:
            proposals = llm.complete_json(system=CONSOLIDATE_SYSTEM, user=prompt, schema=ProposalSet,
                                          purpose=f"consolidate:{session_id}", check=check).items
        except LLMError as e:
            log.warning("consolidation failed for %s: %s", session_id, e)
            return []
        out = []
        for p in proposals:
            sid = scope_ids[p.scope_type]
            replaced = next((i for i in existing if i.id == p.replaces_item_id), None)
            dup = replaced or self._duplicate_of(p.content, p.scope_type, sid)
            status = "active" if p.kind in self.settings.memory_auto_approve_kinds and not dup else "proposed"
            item = MemoryItem(id=f"mem_{uuid.uuid4().hex[:20]}", version=1, kind=p.kind, scope_type=p.scope_type,
                              scope_id=sid, content=p.content.strip(), status=status, source="consolidation",
                              source_refs={"event_ids": p.event_ids, "session_id": session_id,
                                           "episode_id": episode_id, "replaces": p.replaces_item_id},
                              confidence=p.confidence, possible_duplicate_of=dup.ref if dup else None,
                              valid_from=_now(), created_at=_now(), created_by="consolidation",
                              embedding=self._embed_one(p.content))
            out.append(self.store.add_item(item))
        self.store.mark_consolidated(session_id, events[-1].id)
        return out

    def approve(self, item_id: str, actor: str, supersede: bool = False) -> MemoryItem:
        item = self.store.get_item(item_id)
        if item is None:
            raise KeyError(item_id)
        if item.status != "proposed":
            raise ValueError(f"item is {item.status}, not proposed")
        if supersede and item.possible_duplicate_of:
            old_id = item.possible_duplicate_of.split("@", 1)[0]
            self.store.set_status(old_id, "superseded", actor, valid_to=_now(),
                                  detail={"superseded_by": item.ref})
        return self.store.set_status(item_id, "active", actor, reviewed=True,
                                     detail={"supersede": supersede})

    def reject(self, item_id: str, actor: str, reason: str | None = None) -> MemoryItem:
        return self.store.set_status(item_id, "rejected", actor, reviewed=True, detail={"reason": reason})

    def retire(self, item_id: str, actor: str, reason: str | None = None) -> MemoryItem:
        return self.store.set_status(item_id, "retired", actor, valid_to=_now(), detail={"reason": reason})

    def edit(self, item_id: str, content: str, actor: str) -> MemoryItem:
        return self.store.new_version(item_id, content=content.strip(), actor=actor)
