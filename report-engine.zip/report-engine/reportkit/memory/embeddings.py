"""Optional embeddings through the LiteLLM hub (e.g. a Bedrock Titan/Cohere model).

Off by default: memory retrieval works on BM25 + recency + importance alone.
Turn on with RK_MEMORY_EMBEDDING_MODEL. Vectors are stored with the row
(JSON) and compared in Python over the metadata-filtered candidates, which is
plenty for per-user/per-project memory. For very large stores, add a pgvector
column + HNSW index (see deploy/sql/pgvector_memory.sql).
"""

from __future__ import annotations

import logging
from typing import Protocol

from reportkit.settings import Settings

log = logging.getLogger(__name__)


class Embedder(Protocol):
    model: str

    def embed(self, texts: list[str]) -> list[list[float]] | None: ...


class LiteLLMEmbedder:
    def __init__(self, settings: Settings):
        from openai import OpenAI  # noqa: PLC0415

        self.model = settings.memory_embedding_model or ""
        self.client = OpenAI(base_url=settings.llm_base_url, api_key=settings.llm_api_key,
                             timeout=settings.llm_timeout_s, max_retries=3)

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        try:
            resp = self.client.embeddings.create(model=self.model, input=texts)
            return [d.embedding for d in resp.data]
        except Exception as e:  # noqa: BLE001 - retrieval degrades to lexical, never fails the job
            log.warning("embedding call failed (%s); falling back to lexical ranking", type(e).__name__)
            return None


def make_embedder(settings: Settings) -> Embedder | None:
    return LiteLLMEmbedder(settings) if settings.memory_embedding_model else None
