"""Scoring for memory retrieval: relevance + recency + importance.

Generative-Agents style composite score, with fixed weights recorded in the
manifest so the same inputs always rank the same way:

    score = w_rel * relevance + w_rec * recency + w_imp * importance

relevance  = BM25 over the candidate set (normalised to 0..1), blended with
             cosine similarity when embeddings are configured
recency    = 0.5 ** (age_days / half_life_days)
importance = stored 0..1 value (computed deterministically when written)
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone

from reportkit.llm.retrieval import tokens


@dataclass(frozen=True)
class Weights:
    relevance: float = 3.0
    recency: float = 1.0
    importance: float = 2.0
    half_life_days: float = 30.0
    vector_share: float = 0.5  # share of relevance from cosine when embeddings exist


def bm25(query: str, docs: list[str], k1: float = 1.2, b: float = 0.75) -> list[float]:
    q = tokens(query)
    toks = [tokens(d) for d in docs]
    if not q or not docs:
        return [0.0] * len(docs)
    n = len(docs)
    avg = sum(len(t) for t in toks) / n or 1.0
    df = Counter(t for d in toks for t in set(d))
    out = []
    for d in toks:
        tf = Counter(d)
        s = 0.0
        for t in q:
            if t not in tf:
                continue
            idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
            s += idf * tf[t] * (k1 + 1) / (tf[t] + k1 * (1 - b + b * len(d) / avg))
        out.append(s)
    top = max(out) or 1.0
    return [x / top for x in out]


def cosine(a: list[float] | None, b: list[float] | None) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return max(0.0, dot / (na * nb)) if na and nb else 0.0


def recency(ts: datetime, half_life_days: float, at: datetime | None = None) -> float:
    at = at or datetime.now(timezone.utc)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    age = max(0.0, (at - ts).total_seconds() / 86400)
    return 0.5 ** (age / half_life_days)


def rank(query: str, texts: list[str], times: list[datetime], importance: list[float],
         embeddings: list[list[float] | None] | None = None, query_embedding: list[float] | None = None,
         w: Weights = Weights()) -> list[float]:
    lex = bm25(query, texts)
    vec = [cosine(query_embedding, e) for e in (embeddings or [None] * len(texts))] if query_embedding else None
    scores = []
    for i in range(len(texts)):
        rel = lex[i] if vec is None else (1 - w.vector_share) * lex[i] + w.vector_share * vec[i]
        scores.append(w.relevance * rel + w.recency * recency(times[i], w.half_life_days)
                      + w.importance * importance[i])
    return scores
