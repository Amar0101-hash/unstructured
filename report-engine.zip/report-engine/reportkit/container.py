"""Wires settings into concrete services. API and worker both build one."""

from __future__ import annotations

import logging
import socket
import traceback
import uuid
from dataclasses import dataclass, field
from typing import Callable

from reportkit.assembly.docx_renderer import DocumentRenderer, SdtDocxRenderer
from reportkit.ingest.parser import BasicParser, DocumentParser
from reportkit.ingest.service import IngestService
from reportkit.llm.client import LiteLLMClient, LLMClient
from reportkit.memory.embeddings import make_embedder
from reportkit.memory.manager import MemoryManager
from reportkit.memory.store import MemoryStore
from reportkit.models.job import JobStatus
from reportkit.pipeline import ReportPipeline
from reportkit.queue import InlineJobQueue, JobQueue, SqsJobQueue
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore, make_blobstore
from reportkit.storage.repository import Repository

log = logging.getLogger(__name__)


def make_renderer(settings: Settings) -> DocumentRenderer:
    if settings.renderer == "docx_engine":
        from reportkit.assembly.docx_engine_adapter import DocxEngineRenderer  # noqa: PLC0415

        return DocxEngineRenderer()
    return SdtDocxRenderer()


@dataclass
class Container:
    settings: Settings
    repo: Repository
    blob: BlobStore
    parser: DocumentParser
    llm_factory: Callable[[], LLMClient]
    renderer: DocumentRenderer
    queue: JobQueue | None = None
    memory: MemoryManager | None = None
    worker_id: str = field(default_factory=lambda: f"{socket.gethostname()}-{uuid.uuid4().hex[:6]}")

    @property
    def ingest(self) -> IngestService:
        return IngestService(self.settings, self.repo, self.blob, self.parser)

    def pipeline(self, on_heartbeat: Callable[[], None] | None = None) -> ReportPipeline:
        return ReportPipeline(self.settings, self.repo, self.blob, self.ingest, self.llm_factory, self.renderer,
                              on_heartbeat=on_heartbeat, memory=self.memory)

    def run_job(self, job_id: str, on_heartbeat: Callable[[], None] | None = None) -> bool:
        """Claim and run one job. Returns False if another worker holds it."""
        if not self.repo.claim_job(job_id, self.worker_id, self.settings.job_stale_after_s):
            log.info("job %s not claimable (done or held elsewhere)", job_id)
            return False

        def beat() -> None:
            self.repo.heartbeat(job_id, self.worker_id)
            if on_heartbeat:
                on_heartbeat()

        try:
            result = self.pipeline(on_heartbeat=beat).run(job_id)
            status = JobStatus.succeeded_with_issues if result.n_errors else JobStatus.succeeded
            self.repo.finish_job(job_id, status, result)
            return True
        except Exception as e:  # noqa: BLE001
            log.exception("job %s failed", job_id)
            job = self.repo.get_job(job_id)
            msg = f"{type(e).__name__}: {e}"
            self.repo.add_event(job_id, "error", msg, level="error",
                                data={"trace": traceback.format_exc()[-4000:]})
            if (self.settings.queue_backend == "sqs" and job and job.attempts < self.settings.job_max_attempts
                    and _retryable(e)):
                self.repo.requeue_job(job_id, msg)
                raise  # let the queue redeliver
            self.repo.finish_job(job_id, JobStatus.failed, error=msg)
            return True


def _retryable(e: Exception) -> bool:
    """Infrastructure hiccups are retried; bad input is not."""
    from reportkit.template.compiler import TemplateError  # noqa: PLC0415

    return not isinstance(e, (TemplateError, KeyError, ValueError))


def build_container(settings: Settings, *, llm_factory: Callable[[], LLMClient] | None = None,
                    parser: DocumentParser | None = None, inline_sync: bool = False,
                    with_queue: bool = True) -> Container:
    import reportkit.memory.store  # noqa: F401, PLC0415 - registers the memory tables on the shared metadata

    repo = Repository(settings.database_url, settings.db_pool_size)
    if settings.env != "prod":
        repo.create_all()
    if llm_factory is None and settings.llm_backend == "demo":
        from reportkit.devtools.demo_llm import demo_llm  # noqa: PLC0415

        llm_factory = demo_llm
    c = Container(
        settings=settings, repo=repo, blob=make_blobstore(settings), parser=parser or BasicParser(),
        llm_factory=llm_factory or (lambda: LiteLLMClient(settings)), renderer=make_renderer(settings),
        memory=MemoryManager(settings, MemoryStore(repo), make_embedder(settings)))
    if with_queue:
        if settings.queue_backend == "sqs":
            c.queue = SqsJobQueue(settings)
        else:
            def _run_inline(job_id: str) -> None:
                try:
                    c.run_job(job_id)
                except Exception:  # noqa: BLE001 - logged and recorded inside run_job
                    pass
            c.queue = InlineJobQueue(_run_inline, sync=inline_sync)
    return c
