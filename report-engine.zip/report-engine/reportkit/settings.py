"""Runtime configuration shared by the API and the worker.

Every value comes from an environment variable prefixed with ``RK_`` so the
same image runs as API or worker on ECS with only env changes.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RK_", env_file=".env", extra="ignore")

    env: Literal["dev", "test", "prod"] = "dev"
    git_sha: str = "unknown"  # baked in at image build; recorded in every run manifest

    # Metadata store. Postgres in prod: postgresql+psycopg://user:pass@host/db
    database_url: str = "sqlite:///./reportkit.db"
    db_pool_size: int = 5

    # Blob store for uploads, Parquet snapshots, figures, outputs
    blob_backend: Literal["s3", "local"] = "local"
    s3_bucket: str | None = None
    s3_prefix: str = "reportkit"
    local_blob_dir: str = "./.blobs"
    presign_ttl_s: int = 900

    # Job queue
    queue_backend: Literal["sqs", "inline"] = "inline"
    sqs_queue_url: str | None = None
    sqs_visibility_timeout_s: int = 300
    job_max_attempts: int = 3
    job_stale_after_s: int = 900  # a running job with no heartbeat for this long can be re-claimed

    aws_region: str = "us-east-1"

    # LLM (corporate LiteLLM hub, OpenAI-compatible). "demo" = scripted responses for the sample template.
    llm_backend: Literal["litellm", "demo"] = "litellm"
    llm_base_url: str = "http://localhost:4000"
    llm_api_key: str = "sk-local"
    llm_model: str = "bedrock-claude"
    llm_timeout_s: float = 300.0
    llm_max_validation_retries: int = 2
    llm_temperature: float = 0.0
    llm_concurrency: int = 4  # slots planned/written in parallel

    # Document retrieval. "tree" = vectorless: the LLM navigates each document's
    # section tree (cached as JSON in the blob store). "keyword" = no LLM calls.
    retriever: Literal["tree", "keyword"] = "tree"
    tree_summaries: Literal["llm", "extractive"] = "llm"
    tree_summary_min_chars: int = 500  # shorter sections get an extractive summary, no LLM call
    tree_outline_chars: int = 16_000  # outline budget per navigation step
    tree_context_chars: int = 30_000  # max text handed on from the selected sections
    tree_nav_rounds: int = 3  # select/expand rounds before the navigator must commit

    # Memory / context manager
    memory_enabled: bool = True
    memory_context_tokens: int = 6_000  # budget for the memory section of each prompt
    memory_compact_after_tokens: int = 3_000  # unsummarised session history before a new brief
    memory_keep_recent_events: int = 8  # always shown verbatim after the brief
    memory_episodes_k: int = 3
    memory_auto_approve_kinds: list[str] = Field(default_factory=list)  # e.g. ["preference"]; [] = review all
    memory_embedding_model: str | None = None  # LiteLLM embedding model name; None = lexical only
    memory_half_life_days: float = 30.0
    org_id: str = "default"
    memory_admins: list[str] = Field(default_factory=list)  # may write org-scope memory

    # Writable scratch (the ECS bind mount; root filesystem is read-only)
    scratch_dir: str = "./.scratch"

    # DuckDB
    duckdb_memory_limit: str = "2GB"  # ~60-70% of task memory
    duckdb_threads: int = 2  # = task vCPU
    duckdb_extension_dir: str | None = None  # pre-baked into the image, e.g. /opt/duckdb_ext
    query_timeout_s: int = 120
    max_result_rows: int = 10_000
    max_chart_points: int = 50_000

    # Catalog: send low-cardinality sample values to the LLM? Off for PHI-heavy data.
    catalog_sample_values: bool = True
    catalog_sample_max_cardinality: int = 20

    # Athena
    athena_workgroup: str = "primary"
    athena_unload_prefix: str | None = None  # s3://bucket/prefix for UNLOAD materialisation

    # API
    max_upload_mb: int = 200
    cors_origins: list[str] = Field(default_factory=list)
    allowed_extensions: list[str] = Field(
        default_factory=lambda: [".pdf", ".docx", ".xlsx", ".xlsm", ".csv"]
    )

    # Rendering
    renderer: Literal["builtin", "docx_engine"] = "builtin"

    @property
    def scratch(self) -> Path:
        p = Path(self.scratch_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    def scratch_subdir(self, name: str) -> Path:
        p = self.scratch / name
        p.mkdir(parents=True, exist_ok=True)
        return p


@lru_cache
def get_settings() -> Settings:
    return Settings()
