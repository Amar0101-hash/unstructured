"""The report pipeline: ingest -> catalog -> plan -> compute -> write -> assemble.

LLM steps decide WHAT (planner) and HOW TO SAY IT (writer). Everything that
produces a number, a table cell or a chart is deterministic code with lineage.
A slot that fails is flagged visibly in the document and in the manifest;
the job then ends as succeeded_with_issues instead of silently dropping it.
"""

from __future__ import annotations

import csv
import io
import logging
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

from reportkit.assembly.docx_renderer import DocumentRenderer
from reportkit.assembly.manifest import DatasetRecord, InputRecord, RunManifest, environment
from reportkit.assembly.numbers import resolve_paragraph
from reportkit.compute.engine import ComputeEngine
from reportkit.compute.session import ComputeSession
from reportkit.figures.render import ColorRegistry, render_chart
from reportkit.ingest.service import IngestService
from reportkit.llm.client import LLMClient, LLMError
from reportkit.llm.planner import Planner
from reportkit.llm.retrieval import KeywordRetriever, Retriever
from reportkit.llm.writer import Writer
from reportkit.memory.manager import ContextRequest, MemoryManager
from reportkit.memory.models import MemoryRef
from reportkit.models.blocks import FigureBlock, FlagBlock, ParagraphBlock, Run, SlotContent, TableBlock
from reportkit.models.catalog import Catalog
from reportkit.models.compute import SlotBinding, SqlSpec, TableSpec
from reportkit.models.inventory import InventoryElement
from reportkit.models.job import JobRequest, JobResult
from reportkit.models.plan import ReportPlan, Slot
from reportkit.models.results import Fact, FigureResult, TableResult, ValidationIssue
from reportkit.settings import Settings
from reportkit.storage.blobstore import BlobStore, sha256_bytes
from reportkit.storage.repository import Repository
from reportkit.template.compiler import attach_style_examples, compile_template
from reportkit.tree.forest import DocumentForest
from reportkit.tree.models import DocumentTree
from reportkit.tree.retriever import TreeRetriever
from reportkit.tree.service import TreeService

log = logging.getLogger(__name__)
DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
MAX_COPIED_ROWS = 500


@dataclass
class SlotState:
    slot: Slot
    binding: SlotBinding | None = None
    facts: list[Fact] = field(default_factory=list)
    table: TableResult | None = None
    figure: FigureResult | None = None
    content: SlotContent | None = None


class ReportPipeline:
    def __init__(self, settings: Settings, repo: Repository, blob: BlobStore, ingest: IngestService,
                 llm_factory: Callable[[], LLMClient], renderer: DocumentRenderer,
                 retriever: Retriever | None = None, on_heartbeat: Callable[[], None] | None = None,
                 memory: MemoryManager | None = None):
        self.settings, self.repo, self.blob, self.ingest = settings, repo, blob, ingest
        self.memory = memory if settings.memory_enabled else None
        self._memory_text = ""
        self.llm_factory, self.renderer = llm_factory, renderer
        self.retriever = retriever or KeywordRetriever()
        self.on_heartbeat = on_heartbeat or (lambda: None)

    # ---- helpers -------------------------------------------------------------
    def _emit(self, job_id: str, stage: str, message: str, level: str = "info", **data) -> None:
        log.info("[%s] %s: %s", job_id, stage, message)
        self.repo.add_event(job_id, stage, message, level=level, data=data or None)
        self.on_heartbeat()

    def _issue(self, issues: list[ValidationIssue], job_id: str, slot_id: str | None, code: str, msg: str,
               severity: str = "error") -> None:
        issues.append(ValidationIssue(slot_id=slot_id, severity=severity, code=code, message=msg))
        self._emit(job_id, "issue", f"{slot_id or '-'}: {msg}", level="warning" if severity == "warning" else "error",
                   code=code, slot_id=slot_id)

    # ---- entry point ---------------------------------------------------------
    def run(self, job_id: str) -> JobResult:
        started = datetime.now(timezone.utc)
        job = self.repo.get_job(job_id)
        if job is None:
            raise KeyError(job_id)
        req = JobRequest.model_validate(job.request)
        issues: list[ValidationIssue] = []
        llm = self.llm_factory()

        # 1. ingest ------------------------------------------------------------
        inputs: list[InputRecord] = []
        elements: list[InventoryElement] = []
        trees: list[DocumentTree] = []
        catalog = Catalog()
        tree_service = TreeService(self.settings, self.repo, self.blob)
        for fid in req.input_file_ids:
            row = self.repo.get_file(fid)
            self._emit(job_id, "ingest", f"parsing {row.filename if row else fid}")
            els, datasets = self.ingest.ensure_parsed(fid)
            elements += els
            for ds in datasets:
                catalog.add(ds)
            inputs.append(InputRecord(role="input", file_id=fid, filename=row.filename, sha256=row.sha256))
            if self.settings.retriever == "tree" and any(e.type != "table" for e in els):
                tree = tree_service.ensure_tree(fid, els, self.ingest.parser.version, llm)
                trees.append(tree)
                self._emit(job_id, "index", f"document tree for {row.filename}: "
                           f"{sum(1 for _ in tree.nodes())} nodes ({tree.summarizer})", file_id=fid)
        forest = DocumentForest(trees)
        self._forest = forest
        example_elements: list[InventoryElement] = []
        for fid in req.example_file_ids:
            row = self.repo.get_file(fid)
            els, _ = self.ingest.ensure_parsed(fid)
            example_elements += els
            inputs.append(InputRecord(role="example", file_id=fid, filename=row.filename, sha256=row.sha256))
        for did in req.dataset_ids:
            ds = self.repo.get_dataset(did)
            if ds is None:
                raise KeyError(f"unknown dataset {did}")
            catalog.add(ds)
        element_index = {e.id: e for e in elements}
        self._vocabulary = "\n".join(v for e in catalog.entries.values() for col in e.dataset.columns
                                     for v in col.sample_values)
        self._emit(job_id, "catalog", f"{len(elements)} inventory elements, {len(catalog.entries)} datasets",
                   datasets=sorted(catalog.names()))

        # 2. template -------------------------------------------------------------
        trow = self.repo.get_file(req.template_file_id)
        template_bytes = self.blob.get_bytes(trow.uri)
        inputs.insert(0, InputRecord(role="template", file_id=trow.id, filename=trow.filename, sha256=trow.sha256))
        plan: ReportPlan = compile_template(template_bytes, trow.id)
        attach_style_examples(plan, example_elements)
        self._emit(job_id, "template", f"{len(plan.slots)} slots", slots=[s.id for s in plan.slots])
        states = [SlotState(slot=s) for s in plan.slots]

        # 2b. memory: working + semantic + episodic context for this job ------------
        template_key = req.template_key or f"tpl_{trow.sha256[:16]}"
        user_id = job.created_by or "unknown"
        memory_refs: list[MemoryRef] = []
        procedure_refs: dict[str, str] = {}
        if self.memory:
            if req.session_id:
                self.memory.store.append_event(req.session_id, "job_started", "system",
                                               f"Job {job_id} started from template {trow.filename}",
                                               ref={"job_id": job_id}, created_by=user_id)
            query = " ".join([req.instructions or "", *(f"{s.heading or ''} {s.instruction}" for s in plan.slots)])
            pack = self.memory.build(ContextRequest(user_id=user_id, session_id=req.session_id,
                                                    project_id=req.project_id, template_key=template_key,
                                                    query=query), llm)
            self._memory_text = pack.text()
            self._vocabulary += "\n" + pack.vocabulary
            memory_refs = pack.refs
            self._emit(job_id, "memory", f"context: {len(pack.refs)} memory refs ({pack.tokens})",
                       tokens=pack.tokens)

        with ComputeSession(self.settings, self.blob, catalog, job_id) as session:
            # 3. plan (parallel; ids de-duplicated afterwards) ----------------------
            retriever = TreeRetriever(forest, llm, self.settings) if self.settings.retriever == "tree" \
                else self.retriever
            planner = Planner(llm, retriever)

            def plan_one(st: SlotState) -> None:
                try:
                    proc, pref = self.memory.procedure_text(template_key, st.slot.id) if self.memory else ("", None)
                    if pref:
                        procedure_refs[st.slot.id] = pref.ref
                    st.binding = planner.plan_slot(st.slot, catalog=catalog, elements=elements, session=session,
                                                   used_ids=set(), instructions=req.instructions,
                                                   memory=self._memory_text, procedure=proc)
                    self._emit(job_id, "plan", f"planned {st.slot.id}", slot_id=st.slot.id)
                except LLMError as e:
                    self._issue(issues, job_id, st.slot.id, "plan_failed", str(e))

            with ThreadPoolExecutor(max_workers=self.settings.llm_concurrency) as pool:
                list(pool.map(plan_one, states))
            self._dedupe_ids([s.binding for s in states if s.binding])

            # 4. compute ------------------------------------------------------------
            engine = ComputeEngine(session, self.blob, job_id)
            bound = [s.binding for s in states if s.binding]
            session.prepare(engine.compile_all(
                [f for b in bound for f in b.facts],
                [b.table for b in bound if b.table is not None],
                [b.figure for b in bound if b.figure is not None]))
            colors = ColorRegistry()
            for i, st in enumerate(states, 1):
                if st.binding:
                    self._compute_slot(st, engine, element_index, colors, issues, job_id)
                    self._emit(job_id, "compute", f"computed {st.slot.id}", slot_id=st.slot.id, i=i, of=len(states))

        # 5. write ---------------------------------------------------------------
        writer = Writer(llm)

        def write_one(st: SlotState) -> None:
            st.content = self._content_for(st, writer, element_index, req, issues, job_id)

        with ThreadPoolExecutor(max_workers=self.settings.llm_concurrency) as pool:
            list(pool.map(write_one, states))
        self._emit(job_id, "write", "narratives written")

        # 6. assemble -------------------------------------------------------------
        contents = [s.content for s in states if s.content]
        images = {b.image_uri: self.blob.get_bytes(b.image_uri)
                  for c in contents for b in c.blocks if isinstance(b, FigureBlock)}
        docx_bytes, bookmarks = self.renderer.render(template_bytes, contents, images)
        out_sha = sha256_bytes(docx_bytes)
        name = (req.title or trow.filename.rsplit(".", 1)[0]) + "_generated.docx"
        uri = self.blob.put_bytes(f"jobs/{job_id}/output/{name}", docx_bytes, DOCX_MIME)
        docx_art = self.repo.add_artifact(job_id=job_id, kind="docx", name=name, uri=uri, sha256=out_sha,
                                          content_type=DOCX_MIME)

        all_facts = [f for s in states for f in s.facts]
        self.repo.save_facts(job_id, all_facts)
        for s in states:
            if s.figure and s.figure.lineage:
                self.repo.add_artifact(job_id=job_id, kind="figure", name=f"{s.figure.id}.png",
                                       uri=s.figure.image_uri, sha256=s.figure.image_sha256, content_type="image/png")

        # 6b. learn: episode, procedures, proposals (never fails the job) ------------
        memory_written: dict = {}
        n_err = sum(1 for i in issues if i.severity == "error")
        if self.memory:
            try:
                memory_written = self._learn(job_id, req, user_id, template_key, trow.filename, states, issues,
                                             inputs, all_facts, n_err, llm)
                self._emit(job_id, "memory", "memory updated", **{k: v for k, v in memory_written.items()
                                                                   if k != "procedure_ids"})
            except Exception as e:  # noqa: BLE001
                self._issue(issues, job_id, None, "memory_write_failed", str(e), "warning")

        manifest = RunManifest(
            job_id=job_id, created_by=job.created_by, started_at=started, finished_at=datetime.now(timezone.utc),
            environment=environment(self.settings.git_sha), llm_model=llm.model, inputs=inputs,
            datasets=[DatasetRecord(name=n, dataset_id=e.dataset.id, source_kind=e.dataset.source.kind,
                                    fingerprint=e.dataset.fingerprint) for n, e in sorted(catalog.entries.items())],
            bindings=[s.binding for s in states if s.binding], facts=all_facts,
            tables=[s.table for s in states if s.table], figures=[s.figure for s in states if s.figure],
            bookmarks=bookmarks, llm_calls=RunManifest.calls(llm.calls), issues=issues, output_sha256=out_sha,
            retrievals=[planner.traces[s.slot.id] for s in states if s.slot.id in planner.traces],
            document_trees=[{"file_id": t.file_id, "filename": t.filename, "summarizer": t.summarizer,
                             "nodes": sum(1 for _ in t.nodes()),
                             "key": tree_service.key(t.sha256, t.parser_version, t.summarizer)} for t in trees],
            memory_used=[r.model_dump() for r in memory_refs] +
                        [{"tier": "procedural", "ref": r, "slot_id": sid} for sid, r in sorted(procedure_refs.items())],
            memory_written=memory_written,
            memory_weights=self.memory.weights.__dict__ if self.memory else {})
        mbytes = manifest.model_dump_json(indent=2).encode()
        muri = self.blob.put_bytes(f"jobs/{job_id}/output/manifest.json", mbytes, "application/json")
        man_art = self.repo.add_artifact(job_id=job_id, kind="manifest", name="manifest.json", uri=muri,
                                         sha256=sha256_bytes(mbytes), content_type="application/json")
        n_err = sum(1 for i in issues if i.severity == "error")
        self._emit(job_id, "done", f"report generated with {n_err} error(s)", docx_artifact_id=docx_art)
        return JobResult(docx_artifact_id=docx_art, manifest_artifact_id=man_art, n_slots=len(states),
                         n_facts=len(all_facts), n_errors=n_err, n_warnings=len(issues) - n_err)

    # ---- learning ------------------------------------------------------------
    def _learn(self, job_id: str, req: JobRequest, user_id: str, template_key: str, template_name: str,
               states: list[SlotState], issues: list[ValidationIssue], inputs, facts, n_err: int,
               llm: LLMClient) -> dict:
        assert self.memory is not None
        failed = {i.slot_id for i in issues if i.severity == "error"}
        ep = self.memory.record_job_episode(
            job_id=job_id, user_id=user_id, project_id=req.project_id, template_key=template_key,
            session_id=req.session_id, title=req.title or template_name, n_slots=len(states), n_facts=len(facts),
            issues=issues, inputs=[i.filename for i in inputs if i.role == "input"])
        good = {s.slot.id: s.binding.model_dump(mode="json") for s in states
                if s.binding is not None and s.slot.id not in failed}
        procs = self.memory.record_procedures(template_key, good, job_id)
        proposed: list[str] = []
        if req.session_id:
            self.memory.store.append_event(req.session_id, "job_finished", "system",
                                           f"Job {job_id} finished with {n_err} error(s)", ref={"job_id": job_id},
                                           created_by=user_id)
            proposed = [i.ref for i in self.memory.consolidate(
                req.session_id, llm, user_id=user_id, project_id=req.project_id, template_key=template_key,
                episode_id=ep.id)]
        return {"episode_id": ep.id, "procedure_ids": procs, "proposed_items": proposed}

    # ---- stages --------------------------------------------------------------
    @staticmethod
    def _dedupe_ids(bindings: list[SlotBinding]) -> None:
        """Slots were planned in parallel, so ids may collide across slots. Ids are
        only referenced inside their own slot (the writer runs later and sees the
        final ids), so renaming here is safe."""
        seen: set[str] = set()

        def fresh(i: str) -> str:
            n, out = 2, i
            while out in seen:
                out = f"{i[:36]}_{n}"
                n += 1
            seen.add(out)
            return out

        for b in bindings:
            for f in b.facts:
                f.fact_id = fresh(f.fact_id)
            if isinstance(b.table, TableSpec):
                b.table.table_id = fresh(b.table.table_id)
            elif isinstance(b.table, SqlSpec):
                b.table.output_id = fresh(b.table.output_id)
            if b.figure:
                b.figure.figure_id = fresh(b.figure.figure_id)

    def _compute_slot(self, st: SlotState, engine: ComputeEngine, elements: dict[str, InventoryElement],
                      colors: ColorRegistry, issues: list[ValidationIssue], job_id: str) -> None:
        b = st.binding
        assert b is not None
        for spec in b.facts:
            try:
                st.facts.append(engine.fact(spec))
            except Exception as e:  # noqa: BLE001 - one bad fact must not sink the report
                self._issue(issues, job_id, st.slot.id, "fact_failed", f"{spec.fact_id}: {e}")
        if b.table is not None:
            try:
                res = engine.table(b.table) if isinstance(b.table, TableSpec) else engine.sql(b.table)
                if isinstance(res, Fact):
                    st.facts.append(res)
                else:
                    st.table = res
            except Exception as e:  # noqa: BLE001
                self._issue(issues, job_id, st.slot.id, "table_failed", str(e))
        if b.figure is not None:
            try:
                rows, lineage = engine.chart_data(b.figure)
                png = render_chart(b.figure, rows, colors)
                uri = self.blob.put_bytes(f"jobs/{job_id}/figures/{b.figure.figure_id}.png", png, "image/png")
                st.figure = FigureResult(id=b.figure.figure_id, title=b.figure.title, caption=b.figure.caption,
                                         image_uri=uri, image_sha256=sha256_bytes(png),
                                         spec=b.figure.model_dump(mode="json"), lineage=lineage)
            except Exception as e:  # noqa: BLE001
                self._issue(issues, job_id, st.slot.id, "figure_failed", str(e))
        if b.copy_element_id:
            el = elements.get(b.copy_element_id)
            if el and el.type == "table" and st.table is None:
                st.table = self._copy_table(el, issues, job_id, st.slot.id)
            elif el and el.type == "figure" and st.figure is None and el.figure:
                data = self.blob.get_bytes(el.figure.blob_uri)
                st.figure = FigureResult(id=el.id, title=el.figure.caption or "Figure", caption=None,
                                         image_uri=el.figure.blob_uri, image_sha256=sha256_bytes(data),
                                         source_element_id=el.id)

    def _copy_table(self, el: InventoryElement, issues, job_id, slot_id) -> TableResult | None:
        if not el.table or not el.table.raw_uri:
            self._issue(issues, job_id, slot_id, "copy_failed", f"element {el.id} has no raw table")
            return None
        raw = self.blob.get_bytes(el.table.raw_uri).decode("utf-8-sig")
        rows = list(csv.reader(io.StringIO(raw)))
        header = el.table.columns or (rows[0] if rows else [])
        body = rows[1:]
        if len(body) > MAX_COPIED_ROWS:
            self._issue(issues, job_id, slot_id, "copy_truncated",
                        f"table {el.id} has {len(body)} rows; copied the first {MAX_COPIED_ROWS}", "warning")
            body = body[:MAX_COPIED_ROWS]
        title = el.provenance.heading_path[-1] if el.provenance.heading_path else el.provenance.filename
        return TableResult(id=el.id, title=title, header=header, rows=body, source_element_id=el.id)

    def _content_for(self, st: SlotState, writer: Writer, elements: dict[str, InventoryElement],
                     req: JobRequest, issues: list[ValidationIssue], job_id: str) -> SlotContent:
        slot, b = st.slot, st.binding
        source_ids = self._source_ids(b) if b else []
        content = SlotContent(slot_id=slot.id, slot_type=slot.type, inline=slot.inline,
                              fact_ids=[f.id for f in st.facts], source_element_ids=source_ids)
        if b is None:
            content.blocks = [FlagBlock(message=f"NOT GENERATED: {slot.id} - planning failed")]
            return content
        facts = {f.id: f for f in st.facts}

        if slot.type == "fact":
            f = st.facts[0] if st.facts else None
            content.blocks = [ParagraphBlock(runs=[Run(text=f.display, fact_id=f.id)])] if f else \
                [FlagBlock(message=f"VALUE NOT COMPUTED: {slot.id}")]
        elif slot.type == "table":
            content.blocks = [TableBlock(table_id=st.table.id, title=st.table.title, header=st.table.header,
                                         rows=st.table.rows, footnote=st.table.footnote)] if st.table else \
                [FlagBlock(message=f"TABLE NOT GENERATED: {slot.id}")]
        elif slot.type == "figure":
            content.blocks = [FigureBlock(figure_id=st.figure.id, title=st.figure.title, caption=st.figure.caption,
                                          image_uri=st.figure.image_uri, image_sha256=st.figure.image_sha256)] \
                if st.figure else [FlagBlock(message=f"FIGURE NOT GENERATED: {slot.id}")]
        elif slot.type == "verbatim":
            content.blocks = self._verbatim_blocks(source_ids, elements, issues, job_id, slot.id)
        else:  # narrative
            sources = [elements[i] for i in source_ids if i in elements]
            try:
                out = writer.write(slot, facts=st.facts, sources=sources, instructions=req.instructions,
                                   vocabulary=self._vocabulary, memory=self._memory_text)
                for text in out.paragraphs:
                    para, unknown = resolve_paragraph(text, facts)
                    if unknown:
                        self._issue(issues, job_id, slot.id, "unknown_fact", f"unknown fact ids {unknown}")
                    content.blocks.append(para)
            except LLMError as e:
                self._issue(issues, job_id, slot.id, "write_failed", str(e))
                content.blocks = [FlagBlock(message=f"NARRATIVE NOT GENERATED: {slot.id}")]
            # A narrative slot may also carry a table/figure the planner attached
            if st.table:
                content.blocks.append(TableBlock(table_id=st.table.id, title=st.table.title, header=st.table.header,
                                                 rows=st.table.rows, footnote=st.table.footnote))
            if st.figure:
                content.blocks.append(FigureBlock(figure_id=st.figure.id, title=st.figure.title,
                                                  caption=st.figure.caption, image_uri=st.figure.image_uri,
                                                  image_sha256=st.figure.image_sha256))
        return content

    def _source_ids(self, b: SlotBinding) -> list[str]:
        """Element ids the planner chose, plus everything under the chosen sections,
        de-duplicated, in the order given."""
        out: list[str] = []
        for i in [*b.source_element_ids, *self._forest.expand(b.source_node_ids)]:
            if i not in out:
                out.append(i)
        return out

    def _verbatim_blocks(self, ids: list[str], elements: dict[str, InventoryElement], issues, job_id, slot_id):
        blocks = []
        for eid in ids:
            el = elements.get(eid)
            if el is None:
                continue
            if el.type == "list" and el.items:
                blocks += [ParagraphBlock(runs=[Run(text=f"• {item}")]) for item in el.items]
            elif el.type == "table":
                t = self._copy_table(el, issues, job_id, slot_id)
                if t:
                    blocks.append(TableBlock(table_id=t.id, title=t.title, header=t.header, rows=t.rows))
            elif el.type == "figure" and el.figure:
                data = self.blob.get_bytes(el.figure.blob_uri)
                blocks.append(FigureBlock(figure_id=el.id, title=el.figure.caption or "Figure",
                                          image_uri=el.figure.blob_uri, image_sha256=sha256_bytes(data)))
            elif el.text:
                blocks.append(ParagraphBlock(runs=[Run(text=el.text)]))
        return blocks or [FlagBlock(message="NOTHING TO COPY")]
