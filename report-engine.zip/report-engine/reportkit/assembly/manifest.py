"""Run manifest: the audit record stored next to every generated report."""

from __future__ import annotations

import platform
from datetime import datetime
from importlib import metadata
from typing import Any

from pydantic import BaseModel, Field

from reportkit.llm.client import LLMCallRecord
from reportkit.models.compute import SlotBinding
from reportkit.models.results import Fact, FigureResult, TableResult, ValidationIssue


def _ver(pkg: str) -> str:
    try:
        return metadata.version(pkg)
    except metadata.PackageNotFoundError:
        return "n/a"


def environment(git_sha: str) -> dict[str, str]:
    return {
        "git_sha": git_sha,
        "python": platform.python_version(),
        **{p: _ver(p) for p in ("duckdb", "sqlglot", "pyarrow", "matplotlib", "python-docx", "pydantic")},
    }


class InputRecord(BaseModel):
    role: str  # template | input | example
    file_id: str
    filename: str
    sha256: str


class DatasetRecord(BaseModel):
    name: str
    dataset_id: str
    source_kind: str
    fingerprint: str | None


class RunManifest(BaseModel):
    job_id: str
    created_by: str | None
    started_at: datetime
    finished_at: datetime
    environment: dict[str, str]
    llm_model: str
    inputs: list[InputRecord]
    datasets: list[DatasetRecord]
    bindings: list[SlotBinding]
    facts: list[Fact]
    tables: list[TableResult]
    figures: list[FigureResult]
    bookmarks: dict[str, str] = Field(default_factory=dict)  # bookmark name -> fact_id / slot_id
    llm_calls: list[dict[str, Any]]
    issues: list[ValidationIssue]
    output_sha256: str | None = None
    retrievals: list[dict[str, Any]] = Field(default_factory=list)  # why each source section was used
    document_trees: list[dict[str, Any]] = Field(default_factory=list)
    memory_used: list[dict[str, Any]] = Field(default_factory=list)  # every memory ref injected (id@version)
    memory_written: dict[str, Any] = Field(default_factory=dict)  # episode, procedures, proposals
    memory_weights: dict[str, Any] = Field(default_factory=dict)

    @staticmethod
    def calls(records: list[LLMCallRecord]) -> list[dict[str, Any]]:
        return [r.__dict__ for r in records]
