"""Built-in renderer: fills the template's rk: content controls in place.

Content controls are kept (only their content is replaced), so the output can
be re-rendered, and every slot and every computed value gets a bookmark
(``rk_<slot>``, ``f<n>_<fact_id>``) that the manifest maps back to lineage.

If you already have docx_engine, set RK_RENDERER=docx_engine and see
docx_engine_adapter.py - the SlotContent JSON is the contract.
"""

from __future__ import annotations

import copy
import io
from typing import Protocol

import docx
from docx.shared import Emu, Inches, Pt
from docx.oxml import OxmlElement
from lxml import etree

from reportkit.models.blocks import FigureBlock, FlagBlock, ParagraphBlock, SlotContent, TableBlock
from reportkit.template.compiler import NS, W, iter_slots

XP_BOOKMARK_IDS = etree.XPath("//w:bookmarkStart/@w:id", namespaces=NS)


def _q(tag: str) -> str:
    return f"{{{W}}}{tag}"


class DocumentRenderer(Protocol):
    def render(self, template: bytes, contents: list[SlotContent], images: dict[str, bytes]) -> tuple[bytes, dict[str, str]]:
        """Returns the document bytes and {bookmark_name: fact_id or slot_id}."""
        ...


class SdtDocxRenderer:
    def render(self, template, contents, images):
        doc = docx.Document(io.BytesIO(template))
        slots = {sid: (sdt, inline) for sdt, _t, sid, inline, _p in iter_slots(doc)}
        style_names = {s.name for s in doc.styles}
        ids = [int(i) for i in XP_BOOKMARK_IDS(doc.element) if str(i).lstrip("-").isdigit()]
        self._next_id = max(ids, default=0) + 1
        self._fact_seq = 0
        bookmarks: dict[str, str] = {}
        sec = doc.sections[0]
        usable = (sec.page_width or Inches(8.5)) - (sec.left_margin or 0) - (sec.right_margin or 0)
        self._img_width = Emu(min(int(usable), int(Inches(6.3))))

        for content in contents:
            if content.slot_id not in slots:
                continue
            sdt, inline = slots[content.slot_id]
            pr = sdt.find(_q("sdtPr"))
            if pr is not None:
                for el in pr.findall(_q("showingPlcHdr")):
                    pr.remove(el)
            body = sdt.find(_q("sdtContent"))
            if body is None:
                body = etree.SubElement(sdt, _q("sdtContent"))
            if inline:
                self._fill_inline(body, content, bookmarks)
            else:
                self._fill_block(doc, body, content, images, style_names, bookmarks)

        out = io.BytesIO()
        doc.save(out)
        return out.getvalue(), bookmarks

    # ---- bookmarks ----------------------------------------------------------
    def _bm(self, name: str) -> tuple[etree._Element, etree._Element]:
        bid = str(self._next_id)
        self._next_id += 1
        start = OxmlElement("w:bookmarkStart")
        start.set(_q("id"), bid)
        start.set(_q("name"), name[:40])
        end = OxmlElement("w:bookmarkEnd")
        end.set(_q("id"), bid)
        return start, end

    def _fact_bm(self, fact_id: str, bookmarks: dict[str, str]):
        self._fact_seq += 1
        name = f"f{self._fact_seq}_{fact_id}"[:40]
        bookmarks[name] = fact_id
        return self._bm(name)

    # ---- inline (inside a sentence) ---------------------------------------
    def _fill_inline(self, body, content: SlotContent, bookmarks) -> None:
        first_r = body.find(_q("r"))
        rpr = copy.deepcopy(first_r.find(_q("rPr"))) if first_r is not None and first_r.find(_q("rPr")) is not None else None
        if rpr is not None:
            for rs in rpr.findall(_q("rStyle")):
                rpr.remove(rs)  # drop the grey PlaceholderText style
        for ch in list(body):
            body.remove(ch)
        block = content.blocks[0] if content.blocks else FlagBlock(message="empty")
        runs = block.runs if isinstance(block, ParagraphBlock) else []
        text = block.message if isinstance(block, FlagBlock) else None
        if text is not None:
            body.append(self._run(f"[[{text}]]", rpr, highlight=True))
            return
        for run in runs:
            r = self._run(run.text, rpr)
            if run.fact_id:
                s, e = self._fact_bm(run.fact_id, bookmarks)
                body.extend([s, r, e])
            else:
                body.append(r)

    @staticmethod
    def _run(text: str, rpr=None, bold: bool = False, highlight: bool = False):
        r = OxmlElement("w:r")
        pr = copy.deepcopy(rpr) if rpr is not None else OxmlElement("w:rPr")
        if bold:
            pr.append(OxmlElement("w:b"))
        if highlight:
            hl = OxmlElement("w:highlight")
            hl.set(_q("val"), "yellow")
            pr.append(hl)
        if len(pr):
            r.append(pr)
        t = OxmlElement("w:t")
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
        t.text = text
        r.append(t)
        return r

    # ---- block-level --------------------------------------------------------
    def _fill_block(self, doc, body, content: SlotContent, images, style_names, bookmarks) -> None:
        first_p = body.find(_q("p"))
        ppr = copy.deepcopy(first_p.find(_q("pPr"))) if first_p is not None and first_p.find(_q("pPr")) is not None else None
        if ppr is not None:
            for rpr in ppr.findall(_q("rPr")):
                ppr.remove(rpr)
        for ch in list(body):
            body.remove(ch)

        start, end = self._bm(f"rk_{content.slot_id}")
        bookmarks[start.get(_q("name"))] = content.slot_id
        body.append(start)
        for block in content.blocks:
            if isinstance(block, ParagraphBlock):
                p = doc.add_paragraph()
                if ppr is not None:
                    p._p.insert(0, copy.deepcopy(ppr))
                for run in block.runs:
                    r = self._run(run.text)
                    if run.fact_id:
                        s, e = self._fact_bm(run.fact_id, bookmarks)
                        p._p.extend([s, r, e])
                    else:
                        p._p.append(r)
                body.append(p._p)
            elif isinstance(block, TableBlock):
                self._table(doc, body, block, style_names)
            elif isinstance(block, FigureBlock):
                self._figure(doc, body, block, images, style_names)
            elif isinstance(block, FlagBlock):
                p = doc.add_paragraph()
                p._p.append(self._run(f"[[{block.message}]]", bold=True, highlight=True))
                body.append(p._p)
        body.append(end)

    def _caption(self, doc, text: str, style_names):
        p = doc.add_paragraph(text, style="Caption" if "Caption" in style_names else None)
        if "Caption" not in style_names and p.runs:
            p.runs[0].bold = True
        return p

    def _table(self, doc, body, block: TableBlock, style_names) -> None:
        cap = self._caption(doc, block.title, style_names)
        cap.paragraph_format.keep_with_next = True
        body.append(cap._p)
        ncols = max(len(block.header), *(len(r) for r in block.rows)) if block.rows else len(block.header)
        t = doc.add_table(rows=1 + len(block.rows), cols=max(ncols, 1))
        if "Table Grid" in style_names:
            t.style = "Table Grid"
        for ci, h in enumerate(block.header):
            cell = t.rows[0].cells[ci]
            cell.text = h
            for r in cell.paragraphs[0].runs:
                r.bold = True
        tr_pr = t.rows[0]._tr.get_or_add_trPr()
        tr_pr.append(OxmlElement("w:tblHeader"))  # repeat header row on each page
        for ri, row in enumerate(block.rows, start=1):
            for ci, val in enumerate(row):
                t.rows[ri].cells[ci].text = val
        body.append(t._tbl)
        if block.footnote:
            fn = doc.add_paragraph(block.footnote)
            for r in fn.runs:
                r.font.size = Pt(8)
            body.append(fn._p)

    def _figure(self, doc, body, block: FigureBlock, images, style_names) -> None:
        data = images.get(block.image_uri)
        p = doc.add_paragraph()
        if data:
            p.add_run().add_picture(io.BytesIO(data), width=self._img_width)
        else:
            p._p.append(self._run(f"[[image missing: {block.figure_id}]]", bold=True, highlight=True))
        p.alignment = 1  # centre
        p.paragraph_format.keep_with_next = True  # never strand the caption on the next page
        body.append(p._p)
        cap = block.title + (f". {block.caption}" if block.caption else "")
        body.append(self._caption(doc, cap, style_names)._p)
