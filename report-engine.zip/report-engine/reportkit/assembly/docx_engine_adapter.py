"""Adapter for your existing docx_engine package.

docx_engine already takes validated JSON blocks and owns all OOXML, SDT
anchors, provenance bookmarks and numbering. The pipeline hands over the same
shape it gives the built-in renderer: a list of SlotContent (see
reportkit/models/blocks.py) plus the image bytes.

Wire ``_to_engine_blocks`` and the call in ``render`` to your engine's
actual API; everything else in the pipeline stays unchanged.
"""

from __future__ import annotations

from typing import Any

from reportkit.models.blocks import SlotContent


class DocxEngineRenderer:
    def __init__(self) -> None:
        try:
            import docx_engine  # type: ignore  # noqa: F401, PLC0415
        except ImportError as e:  # pragma: no cover
            raise RuntimeError("RK_RENDERER=docx_engine but the docx_engine package is not installed") from e

    @staticmethod
    def _to_engine_blocks(contents: list[SlotContent]) -> list[dict[str, Any]]:
        # Map our SlotContent to your engine's block schema here. As a start the
        # JSON is passed through unchanged: anchor = slot_id, blocks = typed list.
        return [c.model_dump(mode="json") for c in contents]

    def render(self, template: bytes, contents: list[SlotContent], images: dict[str, bytes]):
        import docx_engine  # type: ignore  # noqa: PLC0415

        blocks = self._to_engine_blocks(contents)
        result = docx_engine.render(template=template, blocks=blocks, images=images)  # adjust to your API
        if isinstance(result, tuple):
            return result
        return result, {}
