"""Fact placeholders and the "no unbacked numbers" check.

Narrative text from the LLM may contain digits only when they appear in the
slot's source material (study ids, visit names). Every computed value must
be a ``{{fact:<id>}}`` placeholder, resolved later by deterministic code.
"""

from __future__ import annotations

import re

from reportkit.models.blocks import ParagraphBlock, Run
from reportkit.models.results import Fact

PLACEHOLDER = re.compile(r"\{\{\s*fact:([a-z][a-z0-9_]*)\s*\}\}")
NUMBER = re.compile(r"(?<![A-Za-z0-9_.])\d+(?:[.,:/]\d+)*%?")


def number_tokens(text: str) -> set[str]:
    return {m.group(0).rstrip("%") for m in NUMBER.finditer(text)}


def unbacked_numbers(text: str, allowed_source: str) -> list[str]:
    stripped = PLACEHOLDER.sub(" ", text)
    allowed = number_tokens(allowed_source)
    return sorted({t for t in number_tokens(stripped) if t not in allowed})


def placeholder_ids(text: str) -> list[str]:
    return PLACEHOLDER.findall(text)


def resolve_paragraph(text: str, facts: dict[str, Fact]) -> tuple[ParagraphBlock, list[str]]:
    """Split text into runs, replacing placeholders with fact display values.
    Returns the paragraph and any unknown fact ids."""
    runs: list[Run] = []
    unknown: list[str] = []
    pos = 0
    for m in PLACEHOLDER.finditer(text):
        if m.start() > pos:
            runs.append(Run(text=text[pos:m.start()]))
        fid = m.group(1)
        fact = facts.get(fid)
        if fact is None:
            unknown.append(fid)
            runs.append(Run(text=f"[[MISSING FACT {fid}]]"))
        else:
            runs.append(Run(text=fact.display, fact_id=fid))
        pos = m.end()
    if pos < len(text):
        runs.append(Run(text=text[pos:]))
    return ParagraphBlock(runs=runs or [Run(text="")]), unknown
