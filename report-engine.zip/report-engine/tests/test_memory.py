"""Memory tiers and the context manager."""

from __future__ import annotations

import io
import json
from datetime import datetime, timedelta, timezone

import docx
import pytest

from reportkit.llm.client import ScriptedLLM
from reportkit.memory.manager import ContextRequest, MemoryManager
from reportkit.memory.models import Episode
from reportkit.memory.ranking import Weights, rank
from reportkit.memory.store import ERASED, MemoryStore
from reportkit.storage.repository import Repository


@pytest.fixture
def mm(settings):
    import reportkit.memory.store  # noqa: F401

    repo = Repository(settings.database_url)
    repo.create_all()
    return MemoryManager(settings, MemoryStore(repo))


def _upload(client, path):
    return client.post("/files", files={"file": (path.name, path.read_bytes())}).json()["id"]


def _job(client, ids, **extra):
    r = client.post("/jobs", json={"template_file_id": ids["template"],
                                   "input_file_ids": [ids["protocol"], ids["adsl"], ids["adae"]], **extra})
    assert r.status_code == 202, r.text
    job = client.get(f"/jobs/{r.json()['id']}").json()
    arts = {a["kind"]: a for a in client.get(f"/jobs/{job['id']}/artifacts").json()}
    manifest = json.loads(client.get(f"/artifacts/{arts['manifest']['id']}/download").content)
    doc = docx.Document(io.BytesIO(client.get(f"/artifacts/{arts['docx']['id']}/download").content))
    w = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    text = "\n".join("".join(t.text or "" for t in p.iter(w + "t")) for p in doc.element.body.iter(w + "p"))
    return job, manifest, text


# ---- end to end: short-term feedback -> proposal -> approval -> long-term effect --------------

def test_feedback_flows_from_session_to_long_term_memory(client, sample):
    ids = {k: _upload(client, p) for k, p in sample.items()}
    s1 = client.post("/sessions", json={"project_id": "rk-001", "title": "Synopsis draft"}).json()
    fb = client.post(f"/sessions/{s1['id']}/messages", json={
        "kind": "feedback", "content": "In the adverse event summary, say participants instead of subjects.",
        "ref": {"slot_id": "ae_summary"}}).json()

    # 1. short-term: the same session's next job follows the feedback immediately
    job1, m1, text1 = _job(client, ids, session_id=s1["id"])
    assert job1["status"] == "succeeded"
    assert "participants receiving Drug 10 mg" in text1
    assert any(r["ref"] == f"{s1['id']}#e{fb['id']}" for r in m1["memory_used"])

    # 2. consolidation proposed a long-term rule citing the user's event - not yet active
    proposed = m1["memory_written"]["proposed_items"]
    assert len(proposed) == 1
    item_id = proposed[0].split("@")[0]
    item = client.get(f"/memory/items/{item_id}").json()["item"]
    assert item["status"] == "proposed" and item["source_refs"]["event_ids"] == [fb["id"]]
    assert item["scope_type"] == "project" and item["scope_id"] == "rk-001"

    # a new session without the feedback does NOT use the unapproved rule
    s2 = client.post("/sessions", json={"project_id": "rk-001"}).json()
    _, m2, text2 = _job(client, ids, session_id=s2["id"])
    assert "subjects receiving Drug 10 mg" in text2
    assert not any(r["ref"].startswith(item_id) for r in m2["memory_used"])

    # 3. after approval, any new session in the project gets it
    assert client.post(f"/memory/items/{item_id}/approve", json={}).json()["status"] == "active"
    s3 = client.post("/sessions", json={"project_id": "rk-001"}).json()
    _, m3, text3 = _job(client, ids, session_id=s3["id"])
    assert "participants receiving Drug 10 mg" in text3
    assert f"{item_id}@v1" in [r["ref"] for r in m3["memory_used"]]

    # episodic + procedural memory from earlier jobs is used and logged
    tiers = {r["tier"] for r in m3["memory_used"]}
    assert {"semantic", "episodic", "procedural"} <= tiers
    eps = client.get("/memory/episodes", params={"project_id": "rk-001"}).json()
    assert len(eps) == 3 and eps[0]["kind"] == "job"
    assert m3["memory_weights"]["half_life_days"] == 30.0


def test_session_close_writes_episode_and_proposals(client):
    s = client.post("/sessions", json={"project_id": "p9"}).json()
    client.post(f"/sessions/{s['id']}/messages", json={"kind": "feedback",
                                                        "content": "Always report percentages with one decimal."})
    out = client.post(f"/sessions/{s['id']}/close").json()
    assert out["episode_id"] and len(out["proposed"]) == 1
    assert client.post(f"/sessions/{s['id']}/messages", json={"content": "late"}).status_code == 409


def test_user_scope_is_private_and_org_needs_admin(client, settings):
    mine = client.post("/memory/items", json={"kind": "preference", "content": "Use British spelling."}).json()
    assert mine["status"] == "active" and mine["source"] == "user_authored"
    other = {"x-dev-user": "someone-else"}
    assert client.get(f"/memory/items/{mine['id']}", headers=other).status_code == 404
    assert client.post("/memory/items", json={"kind": "style_rule", "scope_type": "org",
                                              "content": "Org rule"}).status_code == 403


# ---- unit: versioning, supersede, erase -------------------------------------------------

def test_edit_versions_and_erase_tombstones(mm):
    a = mm.remember(kind="glossary", scope_type="project", scope_id="p1", content="TEAE means treatment-emergent AE",
                    actor="u1")
    b = mm.edit(a.id, "TEAE: treatment-emergent adverse event", "u1")
    assert b.version == 2 and b.supersedes == f"{a.id}@v1"
    versions, audit = mm.store.history(a.id)
    assert [v.status for v in versions] == ["superseded", "active"] and versions[0].valid_to is not None
    assert [x["action"] for x in audit] == ["created", "edited"]
    mm.store.erase(a.id, "u1", "test")
    versions, audit = mm.store.history(a.id)
    assert all(v.content == ERASED for v in versions) and audit[-1]["action"] == "erased"
    assert mm.store.items(scopes=[("project", "p1")]) == []


def test_approve_with_supersede_retires_the_contradicted_item(mm):
    old = mm.remember(kind="style_rule", scope_type="project", scope_id="p1",
                      content="Place placebo as the first column", actor="u1")
    s = mm.store.create_session("u1", "p1", None)
    e = mm.store.append_event(s.id, "feedback", "user", "Placebo should be the last column, not first.")
    llm = ScriptedLLM(lambda p, m: {"items": [{"kind": "style_rule", "scope_type": "project",
                                               "content": "Place placebo as the last column",
                                               "event_ids": [e.id], "replaces_item_id": old.id}]})
    [new] = mm.consolidate(s.id, llm, user_id="u1", project_id="p1", template_key=None)
    assert new.status == "proposed" and new.possible_duplicate_of == old.ref
    mm.approve(new.id, "u2", supersede=True)
    assert mm.store.get_item(old.id).status == "superseded"
    assert [i.id for i in mm.store.items(scopes=[("project", "p1")])] == [new.id]


def test_consolidation_only_cites_user_events(mm):
    s = mm.store.create_session("u1", None, None)
    u = mm.store.append_event(s.id, "feedback", "user", "Never abbreviate adverse event in headings.")
    a = mm.store.append_event(s.id, "assistant_message", "assistant", "I think the user likes short tables.")
    answers = iter([
        {"items": [{"kind": "preference", "scope_type": "user", "content": "Likes short tables", "event_ids": [a.id]}]},
        {"items": [{"kind": "style_rule", "scope_type": "user", "content": "Never abbreviate adverse event",
                    "event_ids": [u.id]}]},
    ])
    llm = ScriptedLLM(lambda p, m: next(answers))
    out = mm.consolidate(s.id, llm, user_id="u1", project_id=None, template_key=None)
    assert [i.content for i in out] == ["Never abbreviate adverse event"]
    assert llm.calls[0].errors and "not user events" in llm.calls[0].errors[0]
    assert mm.consolidate(s.id, llm, user_id="u1", project_id=None, template_key=None) == []  # nothing new


# ---- unit: working memory compaction --------------------------------------------------------

def test_compaction_creates_brief_and_keeps_recent_events(mm, settings):
    settings.memory_compact_after_tokens = 200
    settings.memory_keep_recent_events = 3
    s = mm.store.create_session("u1", None, None)
    ids = [mm.store.append_event(s.id, "user_message", "user", f"message {i} " + "words " * 40).id for i in range(8)]
    llm = ScriptedLLM(lambda p, m: {"goals": ["draft synopsis"],
                                    "decisions": [{"text": "keep it short", "event_ids": [ids[2]]}],
                                    "summary": "User is drafting."})
    text, refs = mm.working(s.id, budget=2000, llm=llm)
    brief = mm.store.latest_brief(s.id)
    assert brief.version == 1 and brief.method == "llm" and brief.covers_through_event_id == ids[-1]
    assert "keep it short" in text and refs[0].ref == f"{s.id}@brief-v1"
    # raw events are never lost
    assert len(mm.store.events(s.id)) == 8


def test_compaction_falls_back_to_extractive_when_llm_cites_unknown_events(mm, settings):
    settings.memory_compact_after_tokens = 10
    s = mm.store.create_session("u1", None, None)
    e = mm.store.append_event(s.id, "feedback", "user", "Use the term 'study treatment' throughout.")
    llm = ScriptedLLM(lambda p, m: {"decisions": [{"text": "x", "event_ids": [999999]}]}, max_retries=1)
    mm.working(s.id, budget=1000, llm=llm)
    brief = mm.store.latest_brief(s.id)
    assert brief.method == "extractive" and brief.brief.decisions[0].event_ids == [e.id]


# ---- unit: ranking and the context pack ----------------------------------------------------

def test_ranking_prefers_relevant_recent_important():
    now = datetime.now(timezone.utc)
    texts = ["adverse events summary table", "adverse events summary table", "demographics by age"]
    times = [now - timedelta(days=90), now, now]
    s = rank("adverse events", texts, times, [0.3, 0.3, 0.3], w=Weights())
    assert s[1] > s[0] > s[2] or (s[1] > s[0] and s[1] > s[2])
    s2 = rank("adverse events", texts[:2], [now, now], [0.2, 0.9])
    assert s2[1] > s2[0]


def test_context_pack_respects_budget_and_logs_refs(mm):
    for i in range(40):
        mm.remember(kind="fact", scope_type="project", scope_id="p1",
                    content=f"Fact number {i} about visit windows and dosing schedule details", actor="u1")
    mm.store.add_episode(Episode(id="epi_x", kind="job", user_id="u1", project_id="p1", template_key="t",
                                 session_id=None, job_id="job_x", title="Old synopsis", summary="dosing schedule",
                                 outcome="succeeded", importance=0.9, created_at=datetime.now(timezone.utc)))
    pack = mm.build(ContextRequest(user_id="u1", project_id="p1", template_key="t", query="dosing schedule"),
                    llm=None, budget_tokens=300)
    assert pack.tokens["semantic"] <= 300
    sem = [r for r in pack.refs if r.tier == "semantic"]
    assert 0 < len(sem) < 40 and all("@v1" in r.ref for r in sem)
    assert any(r.ref == "epi_x" for r in pack.refs) or pack.tokens["episodic"] == 0
