import csv
import statistics

import duckdb
import pyarrow.parquet as pq
import pytest

from reportkit.compute.compiler import CompileError, SpecCompiler
from reportkit.compute.engine import ComputeEngine
from reportkit.compute.session import ComputeSession, QueryError, ResultTooLarge
from reportkit.models.compute import Denominator, Filter, MetricSpec, RowSpec, SqlSpec, TableSpec


def _adsl(sample):
    return list(csv.DictReader(sample["adsl"].open()))


def test_facts_match_independent_calculation(settings, blob, catalog, sample):
    rows = _adsl(sample)
    arm = [r for r in rows if r["TRT01A"] == "Placebo"]
    with ComputeSession(settings, blob, catalog, "j1") as s:
        eng = ComputeEngine(s, blob, "j1")
        mean_sd = eng.fact(MetricSpec(fact_id="age", label="age", dataset="adsl", metric="mean_sd", column="age",
                                      filters=[Filter(col="trt01a", op="=", value="Placebo")]))
        assert mean_sd.components["mean"] == pytest.approx(statistics.mean(int(r["AGE"]) for r in arm))
        assert mean_sd.components["sd"] == pytest.approx(statistics.stdev(int(r["AGE"]) for r in arm))
        compl = eng.fact(MetricSpec(fact_id="c", label="c", dataset="adsl", metric="n_pct", distinct_on="usubjid",
                                    numerator=[Filter(col="complfl", op="=", value="Y")]))
        n = sum(r["COMPLFL"] == "Y" for r in rows)
        assert compl.components["n"] == n and compl.components["d"] == len(rows)


def test_lineage_snapshot_is_the_result(settings, blob, catalog):
    with ComputeSession(settings, blob, catalog, "j1") as s:
        f = ComputeEngine(s, blob, "j1").fact(
            MetricSpec(fact_id="n", label="n", dataset="adsl", metric="count", distinct_on="usubjid"))
    snap = pq.read_table(blob.local_path(f.lineage.result_uri)).to_pylist()
    assert snap == [{"value": f.value}]
    assert f.lineage.engine == "duckdb" and f.lineage.datasets[0].fingerprint


def test_ae_table_uses_subject_denominator(settings, blob, catalog, sample):
    den = Denominator(dataset="adsl", distinct_on="usubjid", col_by="trt01a",
                      filters=[Filter(col="saffl", op="=", value="Y")])
    spec = TableSpec(table_id="ae", title="AE", dataset="adae", col_by="trta", include_total=True, header_n=den,
                     rows=[RowSpec(label="By term", metric="n_pct", row_by="aedecod", distinct_on="usubjid",
                                   denominator=den)])
    with ComputeSession(settings, blob, catalog, "j1") as s:
        t = ComputeEngine(s, blob, "j1").table(spec)
    assert t.header[1].endswith("(N=120)")
    adae = list(csv.DictReader(sample["adae"].open()))
    n = len({r["USUBJID"] for r in adae if r["TRTA"] == "Placebo" and r["AEDECOD"] == "Headache"})
    row = next(r for r in t.rows if r[0].strip() == "Headache")
    placebo_col = t.header.index("Placebo (N=120)")
    assert row[placebo_col].startswith(f"{n} (")


def test_unknown_column_is_a_compile_error(catalog):
    with pytest.raises(CompileError):
        SpecCompiler(catalog).metric(MetricSpec(fact_id="x", label="x", dataset="adsl", metric="mean", column="bmi"))


def test_row_cap_and_lock(settings, blob, catalog):
    settings.max_result_rows = 10
    with ComputeSession(settings, blob, catalog, "j1") as s:
        eng = ComputeEngine(s, blob, "j1")
        with pytest.raises(ResultTooLarge):
            eng.sql(SqlSpec(output_id="raw", title="raw", datasets=["adsl"], sql="SELECT * FROM adsl"))
        with pytest.raises(duckdb.Error):  # lock_configuration is on
            s.con.execute("SET memory_limit='100GB'")


def test_binder_errors_surface_for_planner(settings, blob, catalog):
    with ComputeSession(settings, blob, catalog, "j1") as s:
        cq = SpecCompiler(catalog).metric(MetricSpec(fact_id="x", label="x", dataset="adsl", metric="mean",
                                                     column="sex"))
        with pytest.raises(QueryError):
            s.check(cq)  # AVG of VARCHAR
