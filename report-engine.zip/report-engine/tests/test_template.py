import pytest

from reportkit.devtools.sample import make_template
from reportkit.template.compiler import TemplateError, compile_template


def test_slots_in_order_with_headings(tmp_path):
    p = tmp_path / "t.docx"
    make_template(p)
    plan = compile_template(p.read_bytes(), "f_t")
    assert [s.id for s in plan.slots][:3] == ["n_randomized", "study_population", "demographics"]
    first = plan.slots[0]
    assert first.type == "fact" and first.inline and first.heading == "1 Study Population"
    assert "completed" in plan.slot("study_population").instruction


def test_template_without_slots_is_rejected(tmp_path):
    import docx

    p = tmp_path / "empty.docx"
    docx.Document().save(str(p))
    with pytest.raises(TemplateError):
        compile_template(p.read_bytes(), "f")
