from reportkit.compute.formatting import display, fmt_number, round_half_up
from reportkit.models.compute import FactFormat


def test_half_up_not_bankers():
    assert str(round_half_up(2.25, 1)) == "2.3"  # Python's round() gives 2.2
    assert str(round_half_up(0.125, 2)) == "0.13"
    assert str(round_half_up(-2.25, 1)) == "-2.3"


def test_float_noise_is_fuzzed():
    assert fmt_number(2.2499999999999996, 1) == "2.3"


def test_n_pct_conventions():
    f = FactFormat(decimals=1)
    assert display("n_pct", {"n": 45, "d": 120, "pct": 37.5}, f) == "45 (37.5%)"
    assert display("n_pct", {"n": 0, "d": 120, "pct": 0.0}, f) == "0"
    assert display("mean_sd", {"n": 10, "mean": 52.25, "sd": 8.125}, f) == "52.3 (8.13)"
    assert display("mean", {"value": None}, f) == "NE"
    assert display("count", {"value": 1234}, f) == "1,234"
