"""End to end through the HTTP API with the scripted demo LLM."""

import io
import json

import docx

from reportkit.assembly.numbers import unbacked_numbers


def _upload(client, path):
    r = client.post("/files", files={"file": (path.name, path.read_bytes())})
    assert r.status_code == 201, r.text
    return r.json()["id"]


def _text(doc) -> str:
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    return "\n".join("".join(t.text or "" for t in p.iter(W + "t")) for p in doc.element.body.iter(W + "p"))


def test_full_report(client, sample):
    ids = {k: _upload(client, p) for k, p in sample.items()}
    r = client.post("/jobs", json={"template_file_id": ids["template"],
                                   "input_file_ids": [ids["protocol"], ids["adsl"], ids["adae"]],
                                   "example_file_ids": [ids["example"]]})
    assert r.status_code == 202
    job = client.get(f"/jobs/{r.json()['id']}").json()
    assert job["status"] == "succeeded", job
    arts = {a["kind"]: a for a in client.get(f"/jobs/{job['id']}/artifacts").json()}

    doc = docx.Document(io.BytesIO(client.get(f"/artifacts/{arts['docx']['id']}/download").content))
    text = _text(doc)
    assert "A total of 240 subjects were randomized." in text
    assert "Drug 10 mg (N=120)" in text
    assert "[[" not in text  # no flagged slots
    assert "Age 18 years or older" in text  # verbatim copy
    assert "Schirmer test, safety" in text  # copied table

    manifest = json.loads(client.get(f"/artifacts/{arts['manifest']['id']}/download").content)
    assert manifest["output_sha256"] == arts["docx"]["sha256"]
    retried = [c for c in manifest["llm_calls"] if c["attempt"] > 1]
    assert {c["purpose"] for c in retried} == {"plan:demographics", "write:ae_summary"}
    facts = {f["id"]: f for f in manifest["facts"]}
    assert facts["n_randomized"]["display"] == "240"
    assert set(manifest["bookmarks"].values()) >= {"n_randomized", "demographics"}

    retrievals = {r["slot_id"]: r for r in manifest["retrievals"]}
    assert retrievals["inclusion_criteria"]["method"] == "tree"
    assert retrievals["inclusion_criteria"]["selected_paths"] == ["protocol_synopsis.docx > Inclusion Criteria"]
    assert retrievals["demographics"]["selected"] == []  # data-only slot pulls no document text
    binding = next(b for b in manifest["bindings"] if b["slot_id"] == "inclusion_criteria")
    assert binding["source_node_ids"] and not binding["source_element_ids"]
    assert manifest["document_trees"][0]["key"].startswith("trees/")

    events = client.get(f"/jobs/{job['id']}/events").text
    assert "event: done" in events and "event: end" in events and "event: index" in events


def test_upload_dedup_and_validation(client, sample):
    a = client.post("/files", files={"file": ("adsl.csv", sample["adsl"].read_bytes())}).json()
    b = client.post("/files", files={"file": ("copy.csv", sample["adsl"].read_bytes())}).json()
    assert a["id"] == b["id"] and b["deduplicated"]
    bad = client.post("/files", files={"file": ("x.pdf", b"not a pdf at all")})
    assert bad.status_code == 415
    exe = client.post("/files", files={"file": ("x.exe", b"MZ")})
    assert exe.status_code == 415


def test_register_external_parquet_dataset(client, settings, sample, tmp_path):
    import duckdb

    # In prod this would be s3://bucket/key.parquet; locally the blob root stands in for S3.
    target = tmp_path / "blobs" / "ext" / "labs.parquet"
    target.parent.mkdir(parents=True, exist_ok=True)
    duckdb.sql(f"COPY (SELECT range AS id, range % 3 AS grp FROM range(50)) TO '{target}' (FORMAT parquet)")
    r = client.post("/datasets", json={"name": "labs", "source": {"kind": "file", "uri": "local://ext/labs.parquet"}})
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["row_count"] == 50 and [c["name"] for c in body["columns"]] == ["id", "grp"]
    # paths outside the blob root are refused
    bad = client.post("/datasets", json={"name": "etc", "source": {"kind": "file", "uri": "/etc/hosts", "format": "csv"}})
    assert bad.status_code == 422


def test_number_check():
    assert unbacked_numbers("Rates were {{fact:a}} and 30%.", "") == ["30"]
    assert unbacked_numbers("Study RK-001 at Week 12.", "Study RK-001 runs 12 weeks") == []
