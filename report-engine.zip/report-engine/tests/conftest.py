from __future__ import annotations

import os
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from reportkit.container import build_container
from reportkit.devtools.sample import make_all
from reportkit.ingest.tabular import csv_file_to_dataset
from reportkit.models.catalog import Catalog
from reportkit.settings import Settings
from reportkit.storage.blobstore import LocalBlobStore


@pytest.fixture
def database_url(tmp_path: Path):
    """SQLite by default. Set RK_TEST_PG to a Postgres server URL (e.g.
    postgresql+psycopg://postgres@/postgres?host=/tmp&port=55432) to run every
    test against a fresh Postgres database instead."""
    base = os.environ.get("RK_TEST_PG")
    if not base:
        yield f"sqlite:///{tmp_path}/rk.db"
        return
    import psycopg
    from sqlalchemy.engine import make_url

    url = make_url(base)
    name = f"rk_test_{uuid.uuid4().hex[:10]}"
    admin = url.set(drivername="postgresql").render_as_string(hide_password=False)
    with psycopg.connect(admin, autocommit=True) as conn:
        conn.execute(f'CREATE DATABASE "{name}"')
    yield url.set(database=name).render_as_string(hide_password=False)
    with psycopg.connect(admin, autocommit=True) as conn:
        conn.execute(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)')


@pytest.fixture
def settings(tmp_path: Path, database_url: str) -> Settings:
    return Settings(env="test", database_url=database_url, local_blob_dir=str(tmp_path / "blobs"),
                    scratch_dir=str(tmp_path / "scratch"), llm_backend="demo", duckdb_memory_limit="512MB",
                    duckdb_threads=1, query_timeout_s=20)


@pytest.fixture
def sample(tmp_path: Path) -> dict[str, Path]:
    return make_all(tmp_path / "sample")


@pytest.fixture
def blob(settings: Settings) -> LocalBlobStore:
    return LocalBlobStore(settings.local_blob_dir)


@pytest.fixture
def catalog(settings, blob, sample) -> Catalog:
    cat = Catalog()
    for name in ("adsl", "adae"):
        cat.add(csv_file_to_dataset(settings=settings, blob=blob, local_csv=sample[name], file_id=f"f_{name}",
                                    element_id=None, base_name=name))
    return cat


@pytest.fixture
def client(settings) -> TestClient:
    c = build_container(settings, inline_sync=True)
    with TestClient(create_app(c)) as cl:
        yield cl
