"""Vectorless document trees: building, caching and navigation."""

from __future__ import annotations

from reportkit.devtools.sample import make_protocol
from reportkit.ingest.parser import BasicParser
from reportkit.llm.client import ScriptedLLM
from reportkit.models.inventory import InventoryElement, Provenance
from reportkit.models.plan import Slot
from reportkit.storage.repository import Repository
from reportkit.tree.builder import PART_CHARS, build_tree, summarize_tree
from reportkit.tree.forest import DocumentForest
from reportkit.tree.retriever import TreeRetriever
from reportkit.tree.service import TreeService


def _protocol_tree(tmp_path):
    p = tmp_path / "protocol.docx"
    make_protocol(p)
    parsed = BasicParser().parse(p, p.name, "f_proto")
    tree = build_tree(parsed.elements, file_id="f_proto", filename=p.name, sha256="abc", parser_version="basic-1")
    return tree, parsed.elements


def _el(i: int, text: str, page: int | None = None, type_: str = "paragraph", level: int | None = None):
    return InventoryElement(id=f"el_{i:04d}", file_id="f", type=type_, order=i, text=text, level=level,
                            provenance=Provenance(file_id="f", filename="x.pdf", page=page))


def test_tree_follows_headings_and_tables_are_leaves(tmp_path):
    tree, _ = _protocol_tree(tmp_path)
    titles = [c.title for c in tree.root.children]
    assert titles == ["Protocol Synopsis - Study RK-001", "Study Design", "Inclusion Criteria",
                      "Schedule of Assessments"]
    sched = tree.root.children[-1]
    assert [c.kind for c in sched.children] == ["table"]
    incl = tree.root.children[2]
    assert len(incl.element_ids) == 1 and incl.n_chars > 0  # the list element


def test_flat_document_gets_page_nodes():
    els = [_el(i, f"text block {i} " * 20, page=1 + i // 4) for i in range(12)]
    tree = build_tree(els, file_id="f", filename="scan.pdf", sha256="s", parser_version="v")
    assert [c.title for c in tree.root.children] == ["Page 1", "Page 2", "Page 3"]
    assert all(c.kind == "part" for c in tree.root.children)


def test_long_section_is_split_into_parts():
    big = "x" * (PART_CHARS // 2)
    els = [_el(0, "Methods", type_="heading", level=1)] + [_el(i, big) for i in range(1, 8)]
    tree = build_tree(els, file_id="f", filename="d.docx", sha256="s", parser_version="v")
    methods = tree.root.children[0]
    assert methods.element_ids == [] and len(methods.children) >= 3
    assert methods.children[0].title == "Methods (part 1)"


def test_forest_expand_keeps_document_order(tmp_path):
    tree, _ = _protocol_tree(tmp_path)
    f = DocumentForest([tree])
    root_ids = f.subtree_element_ids(tree.root.node_id)
    sched = tree.root.children[-1].node_id
    incl = tree.root.children[2].node_id
    assert f.expand([sched, incl, sched]) == [*f.subtree_element_ids(sched), *f.subtree_element_ids(incl)]
    assert set(f.expand([tree.root.node_id])) == set(root_ids)
    text, shown = f.outline({tree.root.node_id: 99}, max_chars=200)
    assert len(text) <= 200 and len(shown) < len(f.nodes)  # budget respected


def test_navigation_expands_then_selects_and_rejects_bad_ids(tmp_path, settings):
    tree, elements = _protocol_tree(tmp_path)
    forest = DocumentForest([tree])
    sched = tree.root.children[-1]
    table_leaf = sched.children[0].node_id
    settings.tree_outline_chars = 10_000
    calls = {"n": 0}

    def responder(purpose, messages):
        calls["n"] += 1
        if calls["n"] == 1:
            return {"reasoning": "need to look inside", "select": ["nope.99"], "expand": []}  # rejected
        if calls["n"] == 2:
            return {"reasoning": "schedule section looks right", "select": [], "expand": [sched.node_id]}
        return {"reasoning": "the table itself", "select": [table_leaf], "expand": []}

    # Force the shallow start so expansion is needed: outline budget fits only part of the tree.
    settings.tree_outline_chars = len(DocumentForest([tree]).outline({tree.root.node_id: 2}, 10_000)[0]) + 5
    llm = ScriptedLLM(responder)
    res = TreeRetriever(forest, llm, settings).retrieve(
        Slot(id="visit_schedule", type="table", instruction="Visit schedule table"), elements)
    assert [n.node_id for n in res.nodes] == [table_leaf]
    assert [e.type for e in res.elements] == ["table"]
    assert [r["expand"] for r in res.trace["rounds"]] == [[sched.node_id], []]
    assert any(c.attempt == 2 for c in llm.calls)  # the bad id was sent back once


def test_navigation_failure_falls_back_to_keywords(tmp_path, settings):
    tree, elements = _protocol_tree(tmp_path)
    llm = ScriptedLLM(lambda p, m: {"select": ["missing.1"]}, max_retries=1)
    res = TreeRetriever(DocumentForest([tree]), llm, settings).retrieve(
        Slot(id="incl", type="verbatim", instruction="inclusion criteria"), elements)
    assert res.trace["method"] == "keyword_fallback" and res.elements


def test_tree_is_cached_in_blob_store_by_content_hash(settings, blob, tmp_path):
    repo = Repository(settings.database_url)
    repo.create_all()
    p = tmp_path / "protocol.docx"
    make_protocol(p)
    repo.add_file(sha256="d" * 64, filename=p.name, content_type="x", size=1, uri="local://x", created_by=None)
    elements = BasicParser().parse(p, p.name, f"f_{'d' * 24}").elements
    svc = TreeService(settings, repo, blob)
    llm = ScriptedLLM(lambda purpose, m: {"summary": "Overview of the protocol sections."})
    t1 = svc.ensure_tree(f"f_{'d' * 24}", elements, "basic-1", llm)
    n_calls = len(llm.calls)
    assert n_calls >= 1 and t1.summarizer == "llm-1:scripted"
    t2 = svc.ensure_tree(f"f_{'d' * 24}", elements, "basic-1", llm)
    assert len(llm.calls) == n_calls  # second use: no LLM calls
    assert t2.model_dump() == t1.model_dump()
    assert blob.exists(blob.uri_for(svc.key("d" * 64, "basic-1", "llm-1:scripted")))


def test_extractive_summaries_need_no_llm(tmp_path):
    tree, elements = _protocol_tree(tmp_path)
    summarize_tree(tree, elements, None)
    incl = tree.root.children[2]
    assert tree.summarizer == "extractive-1" and "Age 18" in incl.summary


def test_tree_endpoint(client, sample):
    fid = client.post("/files", files={"file": ("protocol_synopsis.docx", sample["protocol"].read_bytes())}).json()["id"]
    body = client.get(f"/files/{fid}/tree").json()
    assert body["summarizer"] == "extractive-1"
    assert [c["title"] for c in body["root"]["children"]][-1] == "Schedule of Assessments"
