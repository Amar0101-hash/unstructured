import pytest

from reportkit.compute.sql_guard import SqlRejected, transpile, validate_select

ALLOWED = {"adsl", "adae"}


@pytest.mark.parametrize("sql", [
    "DELETE FROM adsl",
    "SELECT 1; SELECT 2",
    "SELECT * FROM read_csv('/etc/passwd')",
    "SELECT read_text('/etc/passwd')",
    "SELECT * FROM secrets",
    "SELECT * FROM main.adsl",
    "SELECT current_setting('memory_limit')",
    "COPY adsl TO 's3://x/y.csv'",
    "ATTACH 'x.db' AS x",
])
def test_rejects(sql):
    with pytest.raises(SqlRejected):
        validate_select(sql, ALLOWED)


def test_accepts_cte_and_join():
    sql = ("WITH s AS (SELECT usubjid, trt01a FROM adsl) "
           "SELECT s.trt01a, COUNT(DISTINCT a.usubjid) FROM adae a JOIN s USING (usubjid) GROUP BY 1")
    assert "COUNT" in validate_select(sql, ALLOWED)


def test_transpile_inlines_params_safely():
    out = transpile("SELECT COUNT(*) FROM adsl WHERE sex = ? AND age > ?", ["F'; DROP TABLE x; --", 18], "athena")
    assert "'F''; DROP TABLE x; --'" in out
    assert "18" in out
