-- OPTIONAL: move memory similarity search into Postgres with pgvector.
-- Default behaviour needs none of this: embeddings (when RK_MEMORY_EMBEDDING_MODEL is set) are stored
-- as JSON and compared in Python over metadata-filtered candidates, which is enough for per-user and
-- per-project memory. Apply this only when one scope holds tens of thousands of items, and switch the
-- candidate query in reportkit/memory/store.py to ORDER BY embedding_vec <=> :query LIMIT :k.
-- Not exercised by the test suite (the test Postgres has no pgvector extension).
-- Set the dimension to your embedding model's output size.

CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE rk_memory_items ADD COLUMN IF NOT EXISTS embedding_vec vector(1024);
ALTER TABLE rk_episodes     ADD COLUMN IF NOT EXISTS embedding_vec vector(1024);

UPDATE rk_memory_items SET embedding_vec = (embedding::text)::vector
 WHERE embedding IS NOT NULL AND embedding_vec IS NULL;
UPDATE rk_episodes SET embedding_vec = (embedding::text)::vector
 WHERE embedding IS NOT NULL AND embedding_vec IS NULL;

CREATE INDEX IF NOT EXISTS ix_rk_memory_items_vec ON rk_memory_items USING hnsw (embedding_vec vector_cosine_ops);
CREATE INDEX IF NOT EXISTS ix_rk_episodes_vec     ON rk_episodes     USING hnsw (embedding_vec vector_cosine_ops);
