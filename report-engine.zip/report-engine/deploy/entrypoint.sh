#!/bin/sh
# Prepares the writable scratch mount, then starts the requested role.
set -eu

mkdir -p /scratch/tmp /scratch/mpl /scratch/home /scratch/duckdb
if [ -d /opt/mplcache ]; then
  cp -rn /opt/mplcache/. /scratch/mpl/ 2>/dev/null || true
fi

role="${1:-api}"
[ "$#" -gt 0 ] && shift

case "$role" in
  api)
    # --timeout-keep-alive must exceed the ALB idle timeout (60 s by default)
    exec uvicorn app.main:app \
      --host 0.0.0.0 --port "${PORT:-8000}" \
      --workers "${WEB_CONCURRENCY:-2}" \
      --proxy-headers --forwarded-allow-ips '*' \
      --timeout-keep-alive 75 --no-server-header "$@"
    ;;
  worker)
    exec python -m worker.main "$@"
    ;;
  *)
    exec "$role" "$@"
    ;;
esac
