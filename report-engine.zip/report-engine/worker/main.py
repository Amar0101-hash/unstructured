"""SQS worker: one job at a time per task; scale out with more ECS tasks.

  python -m worker.main

- Long-polls SQS (20 s), takes one message.
- While the job runs, a heartbeat thread extends the message's visibility and
  bumps rk_jobs.heartbeat_at, so a long GenAI job is never redelivered while
  alive - and is re-claimable if this task dies.
- SIGTERM (ECS stop/deploy): stops taking new messages; the running job
  continues until done or until ECS's stopTimeout, after which the message
  becomes visible again and another worker re-claims the stale job.
- Configure a redrive policy (maxReceiveCount ~3) with a DLQ on the queue.
"""

from __future__ import annotations

import json
import logging
import signal
import threading

from reportkit.container import build_container
from reportkit.settings import get_settings

log = logging.getLogger("worker")


class Heartbeat:
    def __init__(self, sqs, queue_url: str, receipt: str, visibility_s: int, beat):
        self.sqs, self.url, self.receipt = sqs, queue_url, receipt
        self.visibility_s, self.beat = visibility_s, beat
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._loop, daemon=True, name="heartbeat")

    def __enter__(self):
        self._t.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._t.join(timeout=5)

    def _loop(self) -> None:
        while not self._stop.wait(self.visibility_s / 3):
            try:
                self.sqs.change_message_visibility(QueueUrl=self.url, ReceiptHandle=self.receipt,
                                                   VisibilityTimeout=self.visibility_s)
                self.beat()
            except Exception:  # noqa: BLE001
                log.exception("heartbeat failed")


def main() -> None:
    import boto3  # noqa: PLC0415

    settings = get_settings()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    if settings.queue_backend != "sqs":
        raise SystemExit("worker needs RK_QUEUE_BACKEND=sqs (inline mode runs jobs inside the API)")
    c = build_container(settings, with_queue=False)
    sqs = boto3.client("sqs", region_name=settings.aws_region)
    stopping = threading.Event()

    def on_term(signum, _frame):
        log.info("signal %s: finishing current job, taking no new ones", signum)
        stopping.set()

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)
    log.info("worker %s polling %s", c.worker_id, settings.sqs_queue_url)

    while not stopping.is_set():
        resp = sqs.receive_message(QueueUrl=settings.sqs_queue_url, MaxNumberOfMessages=1, WaitTimeSeconds=20,
                                   VisibilityTimeout=settings.sqs_visibility_timeout_s)
        for msg in resp.get("Messages", []):
            receipt = msg["ReceiptHandle"]
            try:
                job_id = json.loads(msg["Body"])["job_id"]
            except (KeyError, ValueError):
                log.error("dropping malformed message %s", msg.get("MessageId"))
                sqs.delete_message(QueueUrl=settings.sqs_queue_url, ReceiptHandle=receipt)
                continue
            job_beat = lambda job_id=job_id: c.repo.heartbeat(job_id, c.worker_id)  # noqa: E731
            try:
                with Heartbeat(sqs, settings.sqs_queue_url, receipt, settings.sqs_visibility_timeout_s, job_beat):
                    c.run_job(job_id)
                sqs.delete_message(QueueUrl=settings.sqs_queue_url, ReceiptHandle=receipt)
            except Exception:  # noqa: BLE001 - retryable: leave the message for redelivery
                log.exception("job %s will be retried", job_id)
                sqs.change_message_visibility(QueueUrl=settings.sqs_queue_url, ReceiptHandle=receipt,
                                              VisibilityTimeout=30)
    log.info("worker stopped")


if __name__ == "__main__":
    main()
