# reportkit — template-driven report generation backend

FastAPI + uvicorn API, an SQS worker, and a reusable core library that turns
**input files + data sources + a Word template (+ an example report)** into a
generated `.docx` with a full audit manifest.

The core rule: **the LLM decides *what* to compute and *how to say it*; it
never produces a number.** Every value, table cell and chart comes from
deterministic code with lineage (SQL, parameters, engine version, dataset
fingerprints, and a Parquet snapshot of the exact result rows).

```
upload ──► ingest ──► index ──► catalog ──► LLM planner ──► compute engine ──► LLM writer ──► docx assembly
 (S3)     inventory  section    datasets    navigates tree   DuckDB / Athena    {{fact:id}}    SDT fill +
          + Parquet  trees (S3) + schemas   -> SlotBinding   / RDS + charts     placeholders   manifest.json
```

## Layout

```
reportkit/                 core library (no FastAPI dependency)
  models/                  Pydantic contracts: inventory, catalog, compute specs, results, blocks, plan
  ingest/                  parser protocol + reference parser, tables -> typed Parquet, IngestService
  connectors/              Athena/Glue (pushdown | UNLOAD), RDS/Postgres (pushdown | materialize)
  compute/                 spec compiler, SQL guard, DuckDB session + routing, engine, SAS-style rounding
  figures/render.py        ChartSpec -> PNG (matplotlib, fixed style, byte-stable output)
  tree/                    vectorless index: section trees, summaries, S3 cache, LLM navigator
  memory/                  context manager: working, episodic, semantic, procedural memory (Postgres)
  llm/                     LiteLLM client w/ validation retries, keyword retriever, planner, writer
  template/compiler.py     Word template content controls -> ReportPlan; example-report style matching
  assembly/                number check + fact resolution, docx renderer, docx_engine adapter, manifest
  pipeline.py              orchestration; failed slots are flagged, never silently dropped
  container.py, queue.py   wiring, job claiming/heartbeat/retry
app/                       FastAPI routes (files, datasets, jobs + SSE, artifacts)
worker/main.py             SQS consumer with visibility heartbeat and graceful SIGTERM
deploy/                    entrypoint, ECS task definitions (read-only root), IAM policy
tests/                     unit + end-to-end through the HTTP API
```

## Run it locally (no AWS, no GenAI hub)

```bash
pip install -e ".[dev]"
cp .env.example .env                      # SQLite, local blobs, inline queue, demo LLM
python -m reportkit.devtools.sample sample   # template + example report + protocol + ADSL/ADAE CSVs
uvicorn app.main:app --reload
pytest -q
# against Postgres instead of SQLite (a fresh database per test):
RK_TEST_PG="postgresql+psycopg://postgres@localhost:5432/postgres" pytest -q
```

Then:

```bash
for f in sample/*.docx sample/*.csv; do curl -s -F "file=@$f" localhost:8000/files; echo; done
curl -s -X POST localhost:8000/jobs -H 'content-type: application/json' -d '{
  "template_file_id": "f_...", "input_file_ids": ["f_protocol", "f_adsl", "f_adae"],
  "example_file_ids": ["f_example"] }'
curl -N localhost:8000/jobs/<job_id>/events          # live progress (SSE)
curl -s localhost:8000/jobs/<job_id>/artifacts       # docx, manifest.json, figures
curl -L -o out.docx localhost:8000/artifacts/<artifact_id>/download
```

`RK_LLM_BACKEND=demo` uses a scripted model that only knows the sample
template (it makes one deliberate mistake in planning and one in writing, so
the retry loop runs every time). Set `RK_LLM_BACKEND=litellm` plus
`RK_LLM_BASE_URL`/`RK_LLM_API_KEY`/`RK_LLM_MODEL` for the real hub.

## Authoring a template

Add content controls in Word (Developer tab → Rich Text Content Control →
Properties → **Tag**). The placeholder text is the instruction for that slot.

| Tag | Where | Filled with |
|---|---|---|
| `rk:narrative:<id>` | block | LLM prose; every number is a `{{fact:id}}` resolved by code |
| `rk:table:<id>` | block | computed summary table, or a table copied from the inputs |
| `rk:figure:<id>` | block | chart from a ChartSpec, or a figure copied from the inputs |
| `rk:fact:<id>` | inline or block | one computed value inside a sentence |
| `rk:verbatim:<id>` | block | text/lists/tables copied verbatim from the inputs |

The example report is matched to template slots by heading and used for tone
and structure only.

## The compute specs (what the planner fills)

- `MetricSpec` → one fact: `count`, `count_distinct`, `sum`, `mean`, `median`, `min`, `max`, `std`,
  `pct`, `n_pct`, `mean_sd`; `filters` (population), `numerator`, `distinct_on` (count subjects,
  not events), `denominator` (e.g. ADSL safety population for AE percentages).
- `TableSpec` → rows of metrics, optional `row_by` expansion (one row per term), `col_by` (arm),
  `include_total`, `header_n` for "(N=xx)" headers, `col_order`, `sort_expanded`.
- `ChartSpec` → `bar | line | scatter | box | hist`, data from a dataset with filters/agg.
- `SqlSpec` → fallback LLM-written SELECT, validated by `sql_guard` (one SELECT, catalog tables
  only, no file/system functions) and run on a connection with `lock_configuration=true`.

Before a binding is accepted, every spec is compiled and bound by DuckDB
(`EXPLAIN`); unknown columns, type errors and bad values go back to the model.

## Document retrieval: vectorless section trees (default)

No embeddings, no chunking, no vector store. Each input document becomes a
tree built from its headings:

```
protocol_synopsis.docx            [document]
├── Study Design                  [section]  summary: "Randomized, double-masked ..."
├── Inclusion Criteria            [section]  -> list element
└── Schedule of Assessments       [section]
    └── Table: Visit, Week, ...   [table]    -> table element
```

- **Build once, reuse:** the tree JSON lives in the blob store at
  `trees/<file sha256>/<parser version>/<summarizer>.json`. The same document in a later job (or
  from another user) costs no LLM calls. Changing the parser or summarizer creates a new key.
- **Summaries are for navigation only** (1–2 sentences, no numbers), never report content. Sections
  shorter than `RK_TREE_SUMMARY_MIN_CHARS` get an extractive summary with no LLM call;
  `RK_TREE_SUMMARIES=extractive` turns LLM summaries off entirely.
- **Navigation per slot:** the model sees the outline (id, kind, title, summary, size), selects the
  nodes it needs, and may expand coarse nodes for up to `RK_TREE_NAV_ROUNDS` rounds. Unknown or
  unseen ids are sent back for correction. Slots computed purely from data select nothing.
- **Sections, not chunks:** the planner can hand whole sections to the writer (`source_node_ids`),
  so a criteria list or a methods section is never cut mid-way. Text passed on is capped at
  `RK_TREE_CONTEXT_CHARS`.
- **Fallbacks:** documents without headings get page nodes (or fixed-size parts); sections over 12k
  characters are split into parts; if navigation fails the keyword retriever takes over and the
  manifest records `keyword_fallback`.
- **Audit:** `manifest.json` → `retrievals` lists, per slot, the outline rounds, the nodes chosen,
  their paths and the model's stated reason.
- **UI:** `GET /files/{id}/tree` returns the outline for a tree view (cached tree if a job already
  indexed the file, otherwise an extractive outline built on the fly with no LLM call).

Set `RK_RETRIEVER=keyword` to skip trees entirely (no LLM calls for retrieval).

## Memory and context manager

Built on the Postgres you already run; no external memory service. Four tiers, following the
taxonomy used by CoALA, LangMem and recent agent-memory surveys:

| Tier | What it holds | Written | Read into prompts |
|---|---|---|---|
| Working (short-term) | session events (append-only) + a versioned brief: goals, decisions (each citing event ids), constraints, open items | every message/feedback; brief compacted when unsummarised history > `RK_MEMORY_COMPACT_AFTER_TOKENS` | brief + recent events verbatim, for jobs in that session |
| Episodic | one record per job or closed session: inputs, outcome, issue codes, user feedback, importance | automatically after each job / on `POST /sessions/{id}/close` | top-k by relevance + recency + importance (summary and outcome only) |
| Semantic (long-term) | typed items (preference, style_rule, glossary, fact, correction) scoped to user, project, template or org; versioned, with valid-from/to | user-authored via `POST /memory/items` (active at once), or **proposed** by consolidation from the user's own feedback | all active items in scope, ranked only when over budget |
| Procedural | the last accepted plan (SlotBinding) for each template slot | slots that finished without errors | shown to the planner as a worked example; still compiled and checked |

Rules that make it safe for regulated output:

- **The model never writes long-term memory directly.** Consolidation may only propose items that cite
  user events (assistant text is rejected), and proposals need approval unless their kind is listed in
  `RK_MEMORY_AUTO_APPROVE_KINDS`. Raw feedback from other sessions is never injected; it reaches new work
  only as an approved item.
- **No silent rewrites.** Edits create a new version; contradicted items are superseded
  (`approve` with `supersede: true`), not deleted; every state change is logged in `rk_memory_audit`.
  `DELETE /memory/items/{id}` tombstones the content of every version (right to erasure) and keeps the audit row.
- **Reproducible context.** Ranking weights are fixed (`manifest.memory_weights`), and `manifest.memory_used`
  lists every brief, event, item (`id@version`), episode and procedure injected into the job;
  `manifest.memory_written` lists what the job added.
- **Scopes.** User-scoped items are private to that user; org scope needs `RK_MEMORY_ADMINS`; project and
  template scopes are open to authenticated users. Plug your project ACL into `app/api/memory.py::_check_write`.

Retrieval is metadata filter → BM25 + recency (half-life `RK_MEMORY_HALF_LIFE_DAYS`) + importance. Set
`RK_MEMORY_EMBEDDING_MODEL` to blend in cosine similarity from an embedding model on your hub;
`deploy/sql/pgvector_memory.sql` moves that into pgvector once a scope holds tens of thousands of items.

Endpoints: `POST /sessions`, `POST /sessions/{id}/messages` (kind `user_message` | `feedback` | `note`),
`GET /sessions/{id}/context` (preview the pack), `POST /sessions/{id}/close`, `GET|POST /memory/items`,
`POST /memory/items/{id}/approve|reject|retire`, `PUT|DELETE /memory/items/{id}`, `GET /memory/episodes`,
`GET /memory/procedures`. Pass `session_id` and `project_id` in `POST /jobs`.

## Data sources and scale

| Source | Registered via | How it runs |
|---|---|---|
| Uploaded CSV/XLSX, tables in DOCX/PDF | `POST /files` (parsed automatically) | streamed to CSV in scratch → DuckDB types it → Parquet in S3 |
| S3 Parquet/CSV | `POST /datasets` `{"kind":"file","uri":"s3://..."}` | DuckDB reads S3 directly (httpfs, task role) |
| Glue table via Athena | `{"kind":"athena","database":..,"table":..,"mode":"pushdown"}` | exact aggregates run in Athena; median etc. trigger an UNLOAD of only the used columns to Parquet |
| RDS Postgres | `{"kind":"rds","connection":"clinical","table":..}` | `RK_RDS_CLINICAL_URL` from Secrets Manager; streamed to Parquet in 50k-row batches, or pushdown |

DuckDB is capped by `RK_DUCKDB_MEMORY_LIMIT` (≈60–70 % of task memory) and
`RK_DUCKDB_THREADS` (= vCPU), and spills to `/scratch/duckdb`. Results are
capped at `RK_MAX_RESULT_ROWS`; queries are interrupted after
`RK_QUERY_TIMEOUT_S`. Report outputs are aggregates, so input size does not
drive memory.

## Deploying on ECS (read-only root filesystem)

- One image, two services: `command: ["api"]` and `command: ["worker"]` (see `deploy/`).
- `readonlyRootFilesystem: true` stays on. The task mounts a `scratch` volume at `/scratch`
  (Fargate ephemeral storage; worker gets 50 GiB). `TMPDIR`, `MPLCONFIGDIR`, `HOME` and DuckDB's temp
  dir all point there. DuckDB extensions (`httpfs`, `aws`, `postgres`) and the matplotlib font cache are
  built into the image, so nothing is written outside `/scratch` at runtime. If writes fail with
  permission denied, check that `/scratch` is owned by uid 10001 in the image.
- uvicorn runs with `--timeout-keep-alive 75` (> ALB idle timeout) and `--proxy-headers`.
- SQS: visibility timeout 300 s, redrive to a DLQ after ~3 receives. The worker extends visibility and
  heartbeats the job row while it runs; a job whose worker dies is re-claimed once its heartbeat is stale.
- Autoscale the worker service on `ApproximateNumberOfMessagesVisible`.
- The API role needs S3 put/get and SQS send (plus Glue/Athena read if users register Athena datasets);
  the worker policy is in `deploy/iam-worker-policy.json`.
- In prod (`RK_ENV=prod`) tables are not auto-created: run migrations (add Alembic against
  `reportkit/storage/repository.py`).

## Plugging in your own pieces

- **Parser:** implement `ingest.parser.DocumentParser` (return `InventoryElement`s, plus header/rows for
  each table) and pass it to `build_container(parser=...)`.
- **docx_engine:** set `RK_RENDERER=docx_engine` and map `SlotContent` in
  `assembly/docx_engine_adapter.py`. The built-in renderer fills the same content controls and adds a
  bookmark per slot and per computed value.
- **Retriever:** the tree retriever is built in; anything else implements `llm.retrieval.Retriever`
  (`retrieve(slot, elements, k) -> RetrievalResult`).

## GxP notes

- `manifest.json` per run: inputs with SHA-256, dataset fingerprints, every binding, every fact with
  its SQL/params/engine/snapshot hash, LLM calls (hashes and token counts, not prompts), validation
  issues, bookmarks → fact ids, output document hash, and library versions plus `RK_GIT_SHA`.
- Rounding is round-half-up (SAS convention), not Python's banker's rounding.
- Narrative digits must be facts or appear in the slot's sources; otherwise the writer is re-prompted
  and, if it still fails, the slot is flagged in yellow in the document.
- `RK_CATALOG_SAMPLE_VALUES=false` stops low-cardinality column values from being sent to the LLM.
- `current_user` reads the ALB OIDC identity header; verify the signed `x-amzn-oidc-data` JWT if the
  service can be reached other than through the ALB.
