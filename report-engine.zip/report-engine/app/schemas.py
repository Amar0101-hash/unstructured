from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from reportkit.models.catalog import ColumnInfo, Source


class FileOut(BaseModel):
    id: str
    filename: str
    sha256: str
    size: int
    content_type: str
    created_at: datetime
    deduplicated: bool = False


class DatasetCreate(BaseModel):
    name: str = Field(pattern=r"^[a-z_][a-z0-9_]{0,62}$")
    description: str | None = None
    source: Source


class DatasetOut(BaseModel):
    id: str
    name: str
    description: str | None
    source: dict[str, Any]
    columns: list[ColumnInfo]
    row_count: int | None
    fingerprint: str | None


class JobOut(BaseModel):
    id: str
    status: str
    request: dict[str, Any]
    result: dict[str, Any] | None
    error: str | None
    attempts: int
    created_by: str | None
    created_at: datetime
    updated_at: datetime


class ArtifactOut(BaseModel):
    id: str
    kind: str
    name: str
    sha256: str
    content_type: str
    created_at: datetime
