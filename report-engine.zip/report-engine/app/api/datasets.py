from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from app.deps import current_user, get_container
from app.schemas import DatasetCreate, DatasetOut
from reportkit.compute.duck import describe, new_connection, sql_str
from reportkit.connectors.athena import AthenaConnector
from reportkit.connectors.base import fingerprint
from reportkit.connectors.rds import RdsConnector
from reportkit.container import Container
from reportkit.models.catalog import AthenaSource, Dataset, FileSource, RdsSource
from reportkit.storage.repository import new_id

router = APIRouter(prefix="/datasets", tags=["datasets"])


def _out(ds: Dataset) -> DatasetOut:
    return DatasetOut(id=ds.id, name=ds.base_name, description=ds.description,
                      source=ds.source.model_dump(mode="json"), columns=ds.columns, row_count=ds.row_count,
                      fingerprint=ds.fingerprint)


@router.post("", response_model=DatasetOut, status_code=201)
def register(body: DatasetCreate, c: Container = Depends(get_container),
             user: str = Depends(current_user)) -> DatasetOut:
    """Register an external dataset (S3 Parquet/CSV, Athena/Glue, RDS). Its
    schema is read now so the planner sees real column names and types."""
    src = body.source
    s = c.settings
    try:
        if isinstance(src, FileSource):
            path = src.uri if src.uri.startswith("s3://") else c.blob.duckdb_path(src.uri)
            con = new_connection(s, need_s3=src.uri.startswith("s3://"))
            try:
                reader = "read_parquet" if src.format == "parquet" else "read_csv"
                cols, n = describe(con, f"{reader}({sql_str(path)})", sample_values=s.catalog_sample_values,
                                   max_cardinality=s.catalog_sample_max_cardinality)
            finally:
                con.close()
            fp = fingerprint(src.uri, n, [x.model_dump() for x in cols])
        elif isinstance(src, AthenaSource):
            cols, n, fp = AthenaConnector(s).describe(src)
        elif isinstance(src, RdsSource):
            cols, n, fp = RdsConnector(s, c.blob).describe(src)
        else:  # pragma: no cover
            raise HTTPException(400, "unknown source kind")
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"could not read dataset: {type(e).__name__}: {e}") from e
    ds = Dataset(id=new_id("ds"), base_name=body.name, description=body.description, source=src, columns=cols,
                 row_count=n, fingerprint=fp)
    c.repo.upsert_dataset(ds, created_by=user)
    return _out(ds)


@router.get("", response_model=list[DatasetOut])
def list_datasets(c: Container = Depends(get_container)) -> list[DatasetOut]:
    return [_out(d) for d in c.repo.list_datasets()]


@router.get("/{dataset_id}", response_model=DatasetOut)
def get_dataset(dataset_id: str, c: Container = Depends(get_container)) -> DatasetOut:
    ds = c.repo.get_dataset(dataset_id)
    if ds is None:
        raise HTTPException(404, "dataset not found")
    return _out(ds)
