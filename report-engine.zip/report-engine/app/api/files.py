from __future__ import annotations

import hashlib
import re
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, UploadFile

from app.deps import current_user, get_container
from app.schemas import FileOut
from reportkit.container import Container

router = APIRouter(prefix="/files", tags=["files"])

MAGIC = {
    ".pdf": [b"%PDF"],
    ".docx": [b"PK\x03\x04"],
    ".xlsx": [b"PK\x03\x04"],
    ".xlsm": [b"PK\x03\x04"],
}
MIME = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
    ".csv": "text/csv",
}
_SAFE = re.compile(r"[^A-Za-z0-9._ -]+")


def _out(row, dedup: bool = False) -> FileOut:
    return FileOut(id=row.id, filename=row.filename, sha256=row.sha256, size=row.size,
                   content_type=row.content_type, created_at=row.created_at, deduplicated=dedup)


@router.post("", response_model=FileOut, status_code=201)
def upload(file: UploadFile, c: Container = Depends(get_container), user: str = Depends(current_user)) -> FileOut:
    # Sync endpoint -> runs in the threadpool. Starlette has already spooled the
    # body to TMPDIR (the writable scratch mount), so nothing large sits in memory.
    name = _SAFE.sub("_", Path(file.filename or "upload").name)[:200]
    ext = Path(name).suffix.lower()
    if ext not in c.settings.allowed_extensions:
        raise HTTPException(415, f"unsupported file type {ext}; allowed: {c.settings.allowed_extensions}")

    limit = c.settings.max_upload_mb * 1024 * 1024
    h, size, head = hashlib.sha256(), 0, b""
    f = file.file
    while chunk := f.read(1 << 20):
        if not head:
            head = chunk[:8]
        size += len(chunk)
        if size > limit:
            raise HTTPException(413, f"file exceeds {c.settings.max_upload_mb} MB")
        h.update(chunk)
    if size == 0:
        raise HTTPException(400, "empty file")
    if ext in MAGIC and not any(head.startswith(m) for m in MAGIC[ext]):
        raise HTTPException(415, f"content does not look like a {ext} file")
    if ext == ".csv" and b"\x00" in head:
        raise HTTPException(415, "CSV looks binary")
    sha = h.hexdigest()

    existing = c.repo.get_file_by_sha(sha)
    if existing:
        return _out(existing, dedup=True)
    f.seek(0)
    uri = c.blob.put_file(f"files/{sha}/{name}", f, MIME.get(ext, "application/octet-stream"))
    row = c.repo.add_file(sha256=sha, filename=name, content_type=MIME.get(ext, "application/octet-stream"),
                          size=size, uri=uri, created_by=user)
    return _out(row)


@router.get("/{file_id}", response_model=FileOut)
def get_file(file_id: str, c: Container = Depends(get_container)) -> FileOut:
    row = c.repo.get_file(file_id)
    if row is None:
        raise HTTPException(404, "file not found")
    return _out(row)


@router.get("/{file_id}/inventory")
def inventory(file_id: str, c: Container = Depends(get_container)) -> list[dict]:
    """Parse on demand (cached by content hash) and return the inventory."""
    if c.repo.get_file(file_id) is None:
        raise HTTPException(404, "file not found")
    elements, _ = c.ingest.ensure_parsed(file_id)
    return [e.model_dump(mode="json") for e in elements]


@router.get("/{file_id}/tree")
def tree(file_id: str, c: Container = Depends(get_container)) -> dict:
    """The document's section tree (for an outline view in the UI).

    Returns the cached tree when a job has already indexed this file (with LLM
    summaries). Otherwise builds an outline with extractive summaries on the
    fly - no LLM call from the API - without caching it.
    """
    from reportkit.tree.builder import build_tree, summarize_tree  # noqa: PLC0415
    from reportkit.tree.service import TreeService  # noqa: PLC0415

    row = c.repo.get_file(file_id)
    if row is None:
        raise HTTPException(404, "file not found")
    elements, _ = c.ingest.ensure_parsed(file_id)
    svc = TreeService(c.settings, c.repo, c.blob)
    for llm in ([c.llm_factory()] if c.settings.tree_summaries == "llm" else []) + [None]:
        cached = svc.load(file_id, c.parser.version, llm)
        if cached is not None:
            return cached.model_dump(mode="json")
    t = build_tree(elements, file_id=file_id, filename=row.filename, sha256=row.sha256,
                   parser_version=c.parser.version)
    return summarize_tree(t, elements, None).model_dump(mode="json")
