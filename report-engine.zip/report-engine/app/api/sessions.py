"""Sessions = working memory. Messages and feedback are append-only events."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.deps import current_user, get_container
from reportkit.container import Container
from reportkit.memory.manager import ContextRequest
from reportkit.memory.models import ContextPack, SessionEvent

router = APIRouter(prefix="/sessions", tags=["sessions"])


class SessionCreate(BaseModel):
    project_id: str | None = None
    title: str | None = None


class SessionOut(BaseModel):
    id: str
    user_id: str
    project_id: str | None
    title: str | None
    status: str
    created_at: datetime
    brief: dict | None = None


class MessageIn(BaseModel):
    role: Literal["user", "assistant"] = "user"
    kind: Literal["user_message", "assistant_message", "feedback", "note"] = "user_message"
    content: str = Field(min_length=1, max_length=20_000)
    ref: dict = Field(default_factory=dict)  # e.g. {"job_id": "...", "slot_id": "ae_summary"}


def _own(c: Container, session_id: str, user: str):
    row = c.memory.store.get_session(session_id) if c.memory else None
    if row is None:
        raise HTTPException(404, "session not found")
    if row.user_id != user:
        raise HTTPException(403, "not your session")
    return row


def _out(c: Container, row) -> SessionOut:
    b = c.memory.store.latest_brief(row.id)
    return SessionOut(id=row.id, user_id=row.user_id, project_id=row.project_id, title=row.title, status=row.status,
                      created_at=row.created_at, brief=b.model_dump(mode="json") if b else None)


@router.post("", response_model=SessionOut, status_code=201)
def create_session(body: SessionCreate, c: Container = Depends(get_container), user: str = Depends(current_user)):
    if c.memory is None:
        raise HTTPException(503, "memory is disabled")
    return _out(c, c.memory.store.create_session(user, body.project_id, body.title))


@router.get("/{session_id}", response_model=SessionOut)
def get_session(session_id: str, c: Container = Depends(get_container), user: str = Depends(current_user)):
    return _out(c, _own(c, session_id, user))


@router.post("/{session_id}/messages", response_model=SessionEvent, status_code=201)
def add_message(session_id: str, body: MessageIn, c: Container = Depends(get_container),
                user: str = Depends(current_user)):
    row = _own(c, session_id, user)
    if row.status != "open":
        raise HTTPException(409, "session is closed")
    if body.role == "user" and body.kind == "assistant_message":
        raise HTTPException(422, "user messages cannot be assistant_message")
    return c.memory.store.append_event(session_id, body.kind, body.role, body.content, body.ref, created_by=user)


@router.get("/{session_id}/events", response_model=list[SessionEvent])
def list_events(session_id: str, after: int = 0, c: Container = Depends(get_container),
                user: str = Depends(current_user)):
    _own(c, session_id, user)
    return c.memory.store.events(session_id, after_id=after)


@router.get("/{session_id}/context", response_model=ContextPack)
def preview_context(session_id: str, query: str = "", template_key: str | None = None,
                    c: Container = Depends(get_container), user: str = Depends(current_user)):
    """The context the next job in this session would receive (may compact the brief)."""
    row = _own(c, session_id, user)
    return c.memory.build(ContextRequest(user_id=user, session_id=session_id, project_id=row.project_id,
                                         template_key=template_key, query=query), c.llm_factory())


@router.post("/{session_id}/close")
def close_session(session_id: str, c: Container = Depends(get_container), user: str = Depends(current_user)) -> dict:
    """Writes a session episode and proposes long-term memories for review."""
    row = _own(c, session_id, user)
    llm = c.llm_factory()
    ep = c.memory.record_session_episode(session_id, user, row.project_id, llm)
    proposed = c.memory.consolidate(session_id, llm, user_id=user, project_id=row.project_id, template_key=None,
                                    episode_id=ep.id if ep else None)
    c.memory.store.close_session(session_id)
    return {"episode_id": ep.id if ep else None, "proposed": [p.model_dump(mode="json") for p in proposed]}
