from __future__ import annotations

import asyncio
import json
from pathlib import Path

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import RedirectResponse, Response, StreamingResponse

from app.deps import current_user, get_container
from app.schemas import ArtifactOut, JobOut
from reportkit.container import Container
from reportkit.models.job import JobRequest, JobStatus

router = APIRouter(tags=["jobs"])


def _job_out(row) -> JobOut:
    return JobOut(id=row.id, status=row.status, request=row.request, result=row.result, error=row.error,
                  attempts=row.attempts, created_by=row.created_by, created_at=row.created_at,
                  updated_at=row.updated_at)


@router.post("/jobs", response_model=JobOut, status_code=202)
def create_job(body: JobRequest, c: Container = Depends(get_container), user: str = Depends(current_user)) -> JobOut:
    tmpl = c.repo.get_file(body.template_file_id)
    if tmpl is None or Path(tmpl.filename).suffix.lower() != ".docx":
        raise HTTPException(422, "template_file_id must reference an uploaded .docx")
    for fid in [*body.input_file_ids, *body.example_file_ids]:
        if c.repo.get_file(fid) is None:
            raise HTTPException(422, f"unknown file {fid}")
    for did in body.dataset_ids:
        if c.repo.get_dataset(did) is None:
            raise HTTPException(422, f"unknown dataset {did}")
    if body.session_id:
        sess = c.memory.store.get_session(body.session_id) if c.memory else None
        if sess is None or sess.user_id != user:
            raise HTTPException(422, "unknown session")
        if sess.status != "open":
            raise HTTPException(409, "session is closed")
        if body.project_id is None:
            body.project_id = sess.project_id
    job_id = c.repo.create_job(body, created_by=user)
    if c.queue is None:
        raise HTTPException(503, "no job queue configured")
    c.queue.enqueue(job_id)
    return _job_out(c.repo.get_job(job_id))


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job(job_id: str, c: Container = Depends(get_container)) -> JobOut:
    row = c.repo.get_job(job_id)
    if row is None:
        raise HTTPException(404, "job not found")
    return _job_out(row)


@router.get("/jobs/{job_id}/events")
async def job_events(job_id: str, request: Request, c: Container = Depends(get_container),
                     last_event_id: str | None = Header(default=None, alias="Last-Event-ID")):
    """Server-sent events. Events are read from Postgres, so any API task can
    serve any job's stream; reconnects resume from Last-Event-ID."""
    if await run_in_threadpool(c.repo.get_job, job_id) is None:
        raise HTTPException(404, "job not found")
    after = int(last_event_id) if last_event_id and last_event_id.isdigit() else 0

    async def stream():
        nonlocal after
        idle = 0.0
        yield "retry: 3000\n\n"
        while True:
            if await request.is_disconnected():
                return
            events = await run_in_threadpool(c.repo.events_after, job_id, after)
            for ev in events:
                after = ev.id
                payload = {"stage": ev.stage, "level": ev.level, "message": ev.message, "data": ev.data,
                           "ts": ev.ts.isoformat()}
                yield f"id: {ev.id}\nevent: {ev.stage}\ndata: {json.dumps(payload, default=str)}\n\n"
                idle = 0.0
            job = await run_in_threadpool(c.repo.get_job, job_id)
            if job and JobStatus(job.status).terminal and not events:
                yield f"event: end\ndata: {json.dumps({'status': job.status})}\n\n"
                return
            await asyncio.sleep(1.0)
            idle += 1.0
            if idle >= 15:  # keep the ALB connection alive (idle timeout is 60 s by default)
                yield ": ping\n\n"
                idle = 0.0

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/jobs/{job_id}/facts")
def job_facts(job_id: str, c: Container = Depends(get_container)) -> list[dict]:
    return [f.model_dump(mode="json") for f in c.repo.facts(job_id)]


@router.get("/jobs/{job_id}/artifacts", response_model=list[ArtifactOut])
def job_artifacts(job_id: str, c: Container = Depends(get_container)) -> list[ArtifactOut]:
    return [ArtifactOut(id=a.id, kind=a.kind, name=a.name, sha256=a.sha256, content_type=a.content_type,
                        created_at=a.created_at) for a in c.repo.artifacts(job_id)]


@router.get("/artifacts/{artifact_id}/download")
def download(artifact_id: str, c: Container = Depends(get_container)):
    a = c.repo.get_artifact(artifact_id)
    if a is None:
        raise HTTPException(404, "artifact not found")
    url = c.blob.presign(a.uri, filename=a.name)
    if url:
        return RedirectResponse(url, status_code=307)
    return Response(c.blob.get_bytes(a.uri), media_type=a.content_type,
                    headers={"Content-Disposition": f'attachment; filename="{a.name}"'})
