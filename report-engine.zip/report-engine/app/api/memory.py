"""Long-term memory review and management. Every change is audited."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.deps import current_user, get_container
from reportkit.container import Container
from reportkit.memory.models import Episode, ItemKind, MemoryItem, Procedure, ScopeType

router = APIRouter(prefix="/memory", tags=["memory"])


class RememberIn(BaseModel):
    kind: ItemKind
    scope_type: ScopeType = "user"
    scope_id: str | None = None  # defaults: your user id, or the org id
    content: str = Field(min_length=3, max_length=400)


class ReviewIn(BaseModel):
    supersede: bool = False  # approve: also supersede the item it duplicates/replaces
    reason: str | None = None


class EditIn(BaseModel):
    content: str = Field(min_length=3, max_length=400)


def _mm(c: Container):
    if c.memory is None:
        raise HTTPException(503, "memory is disabled")
    return c.memory


def _check_write(c: Container, item_scope: str, scope_id: str, user: str) -> None:
    """User scope: only the owner. Org scope: memory admins. Project/template:
    any authenticated user - plug your project ACL in here."""
    if item_scope == "user" and scope_id != user:
        raise HTTPException(403, "user-scoped memory belongs to another user")
    if item_scope == "org" and user not in c.settings.memory_admins:
        raise HTTPException(403, "org-scoped memory needs a memory admin")


def _get(c: Container, item_id: str, user: str) -> MemoryItem:
    item = _mm(c).store.get_item(item_id)
    if item is None or (item.scope_type == "user" and item.scope_id != user):
        raise HTTPException(404, "memory item not found")
    return item


@router.get("/items", response_model=list[MemoryItem])
def list_items(status: list[str] = Query(default=["active", "proposed"]), project_id: str | None = None,
               template_key: str | None = None, c: Container = Depends(get_container),
               user: str = Depends(current_user)):
    scopes = [("user", user), ("org", c.settings.org_id)]
    if project_id:
        scopes.append(("project", project_id))
    if template_key:
        scopes.append(("template", template_key))
    return _mm(c).store.items(scopes=scopes, statuses=status)


@router.post("/items", response_model=MemoryItem, status_code=201)
def remember(body: RememberIn, c: Container = Depends(get_container), user: str = Depends(current_user)):
    scope_id = body.scope_id or (user if body.scope_type == "user" else
                                 c.settings.org_id if body.scope_type == "org" else None)
    if not scope_id:
        raise HTTPException(422, f"scope_id is required for {body.scope_type} scope")
    _check_write(c, body.scope_type, scope_id, user)
    return _mm(c).remember(kind=body.kind, scope_type=body.scope_type, scope_id=scope_id, content=body.content,
                           actor=user)


@router.get("/items/{item_id}")
def get_item(item_id: str, c: Container = Depends(get_container), user: str = Depends(current_user)) -> dict:
    item = _get(c, item_id, user)
    versions, audit = _mm(c).store.history(item_id)
    return {"item": item.model_dump(mode="json"), "versions": [v.model_dump(mode="json") for v in versions],
            "audit": audit}


@router.post("/items/{item_id}/approve", response_model=MemoryItem)
def approve(item_id: str, body: ReviewIn, c: Container = Depends(get_container), user: str = Depends(current_user)):
    item = _get(c, item_id, user)
    _check_write(c, item.scope_type, item.scope_id, user)
    try:
        return _mm(c).approve(item_id, user, supersede=body.supersede)
    except ValueError as e:
        raise HTTPException(409, str(e)) from e


@router.post("/items/{item_id}/reject", response_model=MemoryItem)
def reject(item_id: str, body: ReviewIn, c: Container = Depends(get_container), user: str = Depends(current_user)):
    item = _get(c, item_id, user)
    _check_write(c, item.scope_type, item.scope_id, user)
    return _mm(c).reject(item_id, user, body.reason)


@router.post("/items/{item_id}/retire", response_model=MemoryItem)
def retire(item_id: str, body: ReviewIn, c: Container = Depends(get_container), user: str = Depends(current_user)):
    item = _get(c, item_id, user)
    _check_write(c, item.scope_type, item.scope_id, user)
    return _mm(c).retire(item_id, user, body.reason)


@router.put("/items/{item_id}", response_model=MemoryItem)
def edit(item_id: str, body: EditIn, c: Container = Depends(get_container), user: str = Depends(current_user)):
    item = _get(c, item_id, user)
    _check_write(c, item.scope_type, item.scope_id, user)
    return _mm(c).edit(item_id, body.content, user)


@router.delete("/items/{item_id}", status_code=204)
def erase(item_id: str, reason: str = "user request", c: Container = Depends(get_container),
          user: str = Depends(current_user)):
    """Right to erasure: content of every version is tombstoned; the audit trail stays."""
    item = _get(c, item_id, user)
    _check_write(c, item.scope_type, item.scope_id, user)
    _mm(c).store.erase(item_id, user, reason)


@router.get("/episodes", response_model=list[Episode])
def episodes(project_id: str | None = None, limit: int = 50, c: Container = Depends(get_container),
             user: str = Depends(current_user)):
    eps = _mm(c).store.episodes(user_id=user, project_id=project_id, limit=limit)
    return [e.model_copy(update={"embedding": None}) for e in eps
            if e.user_id == user or (project_id and e.project_id == project_id)]


@router.get("/procedures", response_model=list[Procedure])
def procedures(template_key: str, c: Container = Depends(get_container), user: str = Depends(current_user)):
    return _mm(c).store.procedures(template_key)
