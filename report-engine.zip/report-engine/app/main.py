"""FastAPI app. Run with uvicorn:

    uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2 \
        --proxy-headers --forwarded-allow-ips '*' --timeout-keep-alive 75

``--timeout-keep-alive`` must exceed the ALB idle timeout (60 s default) or
the ALB will occasionally reuse a connection uvicorn already closed (502s).
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import datasets, files, jobs, memory, sessions
from reportkit.container import Container, build_container
from reportkit.settings import get_settings


def create_app(container: Container | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if container is not None:
            app.state.container = container
        else:
            settings = get_settings()
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
            app.state.container = build_container(settings)
        yield

    app = FastAPI(title="Report engine", version="0.1.0", lifespan=lifespan)
    settings = container.settings if container else get_settings()
    if settings.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["*"],
                           allow_headers=["*"], allow_credentials=True)
    app.include_router(files.router)
    app.include_router(datasets.router)
    app.include_router(jobs.router)
    app.include_router(sessions.router)
    app.include_router(memory.router)

    @app.get("/healthz", tags=["health"])
    def healthz() -> dict:
        return {"ok": True}

    @app.get("/readyz", tags=["health"])
    def readyz() -> dict:
        app.state.container.repo.ping()
        return {"ok": True}

    return app


app = create_app()
