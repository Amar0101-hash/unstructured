from __future__ import annotations

from fastapi import Depends, HTTPException, Request

from reportkit.container import Container


def get_container(request: Request) -> Container:
    return request.app.state.container


def current_user(request: Request, c: Container = Depends(get_container)) -> str:
    """Identity for the audit trail.

    Behind an ALB with OIDC authentication the ALB sets ``x-amzn-oidc-identity``.
    That header is only trustworthy if the service accepts traffic from the ALB
    alone (security group) - for stronger guarantees verify the signed
    ``x-amzn-oidc-data`` JWT against the regional ALB public key.
    """
    user = request.headers.get("x-amzn-oidc-identity")
    if user:
        return user
    if c.settings.env != "prod":
        return request.headers.get("x-dev-user", "dev-user")
    raise HTTPException(status_code=401, detail="unauthenticated")
